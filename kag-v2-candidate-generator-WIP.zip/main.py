"""Kaggle archive entry point."""

from kag_agent.entrypoint import agent

__all__ = ["agent"]

