from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from kag_agent.domain.actions import ActionEnvelope, pass_envelope
from kag_agent.planning.obligations import build_obligations
from kag_agent.planning.policy import PolicyIntent, market_orders, policy_tasks, select_policy, select_policy_v2
from kag_agent.planning.scheduler import schedule
from kag_agent.planning.validation import maintenance_fallback, serialize, validate
from kag_agent.state.derive import derive_state
from kag_agent.state.history import MatchMemory, commit, needs_reset, new_memory
from kag_agent.state.normalize import normalize_observation
from kag_agent.economics.references import EXECUTABLE_REFERENCES


@dataclass(frozen=True, slots=True)
class DecisionDeadline:
    started_monotonic: float
    decision_deadline_monotonic: float
    hard_return_deadline_monotonic: float

    @classmethod
    def local(cls) -> "DecisionDeadline":
        now = time.monotonic()
        return cls(now, now + 0.80, now + 1.00)

    def decision_expired(self) -> bool:
        return time.monotonic() >= self.decision_deadline_monotonic


class AgentRuntime:
    def __init__(self, version: str = "V1") -> None:
        self.version = version
        self.memory: MatchMemory | None = None
        self.last_elapsed_seconds = 0.0
        self.last_fallback_level = 5
        self.last_trace: dict[str, object] = {}
        self.active_policy: PolicyIntent | None = None

    def decide_envelope(self, observation_raw: Any, configuration_raw: Any = None) -> ActionEnvelope:
        deadline = DecisionDeadline.local()
        observation = normalize_observation(observation_raw, configuration_raw)
        if needs_reset(self.memory, observation):
            self.memory = new_memory(observation)
            self.active_policy = None
        fallback = maintenance_fallback(observation)
        if deadline.decision_expired():
            self.last_fallback_level = 3
            return fallback
        try:
            state = derive_state(observation)
            obligations = build_obligations(state)
            if self.version == "V2":
                if self.active_policy is None or observation.hour == 0 or state.turns_remaining <= observation.config.turns_per_day:
                    self.active_policy = select_policy_v2(state)
                policy = self.active_policy
            elif self.version.startswith("REFERENCE:"):
                reference_id = self.version.partition(":")[2]
                policy = EXECUTABLE_REFERENCES[reference_id].intent(observation.turn, state.turns_remaining, observation.config.turns_per_day, observation.our_farm.money)
            else:
                policy = select_policy(state)
            tasks = policy_tasks(state, policy)
            scheduled = schedule(state, obligations, tasks)
            proposed = ActionEnvelope(scheduled.envelope.farmer, scheduled.envelope.hands, market_orders(state, policy))
            chosen = proposed if validate(proposed, observation).valid else fallback
        except Exception:
            proposed = None
            chosen = fallback
        if not validate(chosen, observation).valid:
            chosen = pass_envelope(len(observation.our_farm.hands))
        if self.memory is not None:
            commit(self.memory, observation, chosen)
        self.last_fallback_level = 0 if proposed is not None and chosen == proposed else 3
        self.last_elapsed_seconds = time.monotonic() - deadline.started_monotonic
        self.last_trace = {
            "turn": observation.turn,
            "player_id": observation.player_id,
            "fallback_level": self.last_fallback_level,
            "elapsed_seconds": self.last_elapsed_seconds,
            "observation_fingerprint": observation.observation_fingerprint,
            "decision_version": self.version,
            "policy_id": policy.policy_id if proposed is not None else None,
            "policy_model_version": policy.model_version if proposed is not None else None,
        }
        return chosen

    def __call__(self, observation_raw: Any, configuration_raw: Any = None) -> dict[str, list]:
        try:
            return serialize(self.decide_envelope(observation_raw, configuration_raw))
        except BaseException:
            # Production boundary: even malformed or unexpected input cannot leak
            # an exception to Kaggle. Hand count may be unavailable here.
            return {"farmer": ["PASS"], "hands": [], "market": []}


RUNTIME = AgentRuntime("V2")
V1_RUNTIME = AgentRuntime("V1")
REFERENCE_RUNTIMES = {key: AgentRuntime(f"REFERENCE:{key}") for key in EXECUTABLE_REFERENCES}
