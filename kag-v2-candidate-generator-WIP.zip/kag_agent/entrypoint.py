from __future__ import annotations

from typing import Any

from kag_agent.runtime import RUNTIME


def agent(observation: Any, configuration: Any = None) -> dict[str, list[Any]]:
    """Version 2 remaining-horizon economic agent with the V1 safety chassis."""
    return RUNTIME(observation, configuration)
