from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from typing import Any


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def fingerprint(value: Mapping[str, Any] | Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()

