from __future__ import annotations

from dataclasses import dataclass

from kag_agent.domain.observation import NormalizedObservation


@dataclass(frozen=True, slots=True)
class DerivedGameState:
    observation: NormalizedObservation
    turns_remaining: int
    days_remaining: float
    shed_used_capacity: int
    shed_free_capacity: int
    derivation_version: str = "v1.0.0"


def derive_state(observation: NormalizedObservation) -> DerivedGameState:
    turns = max(0, observation.config.episode_steps - 1 - observation.turn)
    used = sum(observation.private.shed.values())
    return DerivedGameState(observation, turns, turns / observation.config.turns_per_day, used, max(0, observation.config.shed_capacity - used))

