from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass, field

from kag_agent.config import fingerprint
from kag_agent.domain.actions import ActionEnvelope
from kag_agent.domain.observation import NormalizedObservation


MAX_HISTORY = 64


@dataclass(slots=True)
class MatchMemory:
    logical_match_id: str
    player_id: int
    config_fingerprint: str
    first_observation_fingerprint: str
    last_turn: int
    last_observation: NormalizedObservation | None
    transition_history: deque[tuple[int, int]] = field(default_factory=lambda: deque(maxlen=MAX_HISTORY))
    last_returned_action: ActionEnvelope | None = None
    rng: random.Random = field(default_factory=random.Random)


def config_fingerprint(observation: NormalizedObservation) -> str:
    config = observation.config
    return fingerprint({name: getattr(config, name) for name in config.__slots__})


def needs_reset(memory: MatchMemory | None, observation: NormalizedObservation) -> bool:
    if memory is None:
        return True
    return (
        (observation.turn == 0 and memory.last_turn > 0)
        or observation.turn <= memory.last_turn
        or observation.player_id != memory.player_id
        or config_fingerprint(observation) != memory.config_fingerprint
    )


def new_memory(observation: NormalizedObservation) -> MatchMemory:
    cfg = config_fingerprint(observation)
    logical_id = f"match-{fingerprint({'first': observation.observation_fingerprint, 'player': observation.player_id, 'config': cfg})[:20]}"
    rng = random.Random(int(observation.observation_fingerprint[:16], 16))
    return MatchMemory(logical_id, observation.player_id, cfg, observation.observation_fingerprint, observation.turn, observation, rng=rng)


def commit(memory: MatchMemory, observation: NormalizedObservation, action: ActionEnvelope) -> None:
    if memory.last_observation is not None and observation.turn > memory.last_turn:
        memory.transition_history.append((memory.last_turn, observation.turn))
    memory.last_turn = observation.turn
    memory.last_observation = observation
    memory.last_returned_action = action

