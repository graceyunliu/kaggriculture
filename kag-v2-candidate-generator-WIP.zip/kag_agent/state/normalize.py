from __future__ import annotations

import json
from typing import Any

from kag_agent.config import fingerprint
from kag_agent.domain.observation import GameConfig, NormalizedObservation
from kag_agent.domain.state import Position, PrivateFarmState, PublicFarmState, TileState, UnitState


class NormalizationError(ValueError):
    pass


def _plain(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    if hasattr(value, "items"):
        return {str(key): _plain(item) for key, item in value.items()}
    return value


def _money(value: Any) -> int:
    if not isinstance(value, (int, float)) or not float(value).is_integer():
        raise NormalizationError("money must be an integral number")
    return int(value)


def normalize_config(raw: Any) -> GameConfig:
    cfg = _plain(raw or {})
    return GameConfig(
        episode_steps=int(cfg.get("episodeSteps", 720)), board_size=int(cfg.get("boardSize", 10)),
        starting_money=int(cfg.get("startingMoney", 3000)), max_market_orders_per_turn=int(cfg.get("maxMarketOrdersPerTurn", 10)),
        turns_per_day=max(1, int(cfg.get("turnsPerDay", 24))), shed_capacity=int(cfg.get("shedCapacity", 100)),
        weed_spawn_chance=float(cfg.get("weedSpawnChance", 0.005)), town_shop_unlock_interval_days=int(cfg.get("townShopUnlockInterval", 3)),
        town_shop_sell_interval_turns=int(cfg.get("townShopSellInterval", 4)), town_center_sell_interval_turns=int(cfg.get("townCenterSellInterval", 12)),
        farm_hand_cost_mult=int(cfg.get("farmHandCostMult", 1)),
    )


def _tile(raw: Any, x: int, y: int) -> TileState:
    position = Position(x, y)
    if raw is None:
        return TileState(position, "EMPTY", {})
    if raw == "LOCKED":
        return TileState(position, "LOCKED", {})
    if not isinstance(raw, dict):
        raise NormalizationError(f"unknown tile at {x},{y}")
    kind = str(raw.get("kind", ""))
    if kind not in {"WEED", "PLANT", "COOP", "PASTURE"}:
        raise NormalizationError(f"unknown tile kind {kind!r}")
    return TileState(position, kind, _plain(raw))


def normalize_observation(raw_observation: Any, raw_configuration: Any = None) -> NormalizedObservation:
    raw = _plain(raw_observation)
    if not isinstance(raw, dict):
        raise NormalizationError("observation must be mapping-like")
    config = normalize_config(raw_configuration)
    player = int(raw.get("player", -1))
    if player not in (0, 1):
        raise NormalizationError("player must be 0 or 1")
    farms_raw = raw.get("farms")
    if not isinstance(farms_raw, list) or len(farms_raw) != 2:
        raise NormalizationError("exactly two farms required")
    private_raw = raw.get("private") or {}
    inventories = private_raw.get("inventories") or []
    our_hands = farms_raw[player].get("hands") or []
    if len(inventories) != 1 + len(our_hands):
        raise NormalizationError("private inventory count must match our units")
    farms = []
    for farm_id, source in enumerate(farms_raw):
        rows = source.get("tiles")
        if not isinstance(rows, list) or len(rows) != config.board_size or any(not isinstance(row, list) or len(row) != config.board_size for row in rows):
            raise NormalizationError("tile matrix must match board size")
        tiles = tuple(tuple(_tile(value, x, y) for x, value in enumerate(row)) for y, row in enumerate(rows))
        farmer_pos = source.get("farmer")
        if not isinstance(farmer_pos, list) or len(farmer_pos) != 2:
            raise NormalizationError("farmer position invalid")
        farmer_inventory = _plain(inventories[0]) if farm_id == player else None
        farmer = UnitState("farmer", Position(int(farmer_pos[0]), int(farmer_pos[1])), farmer_inventory)
        hands = []
        for index, pos in enumerate(source.get("hands") or []):
            inventory = _plain(inventories[index + 1]) if farm_id == player else None
            hands.append(UnitState(f"hand:{index}", Position(int(pos[0]), int(pos[1])), inventory))
        farms.append(PublicFarmState(farm_id, _money(source.get("money")), tiles, farmer, tuple(hands), frozenset(source.get("unlocked_quadrants") or []), int(source.get("hires_today", 0))))
    private = PrivateFarmState(_plain(private_raw.get("shed") or {}), _plain(private_raw.get("seeds") or {}), {"farmer": _plain(inventories[0]), **{f"hand:{i}": _plain(value) for i, value in enumerate(inventories[1:])}})
    turn = int(raw.get("step", 0)); day = int(raw.get("day", turn // config.turns_per_day)); hour = int(raw.get("hour", turn % config.turns_per_day))
    semantic = {"player": player, "turn": turn, "day": day, "hour": hour, "farms": farms_raw, "private": private_raw, "market": raw.get("market"), "town": raw.get("town"), "config": config.__dict__ if hasattr(config, "__dict__") else {name: getattr(config, name) for name in config.__slots__}}
    market = raw.get("market") or {}; town = raw.get("town") or {}
    return NormalizedObservation("1.0.0", player, turn, day, hour, config, (farms[0], farms[1]), private, _plain(market.get("inventory") or {}), _plain(market.get("prices") or {}), frozenset(town.get("unlocked_shops") or []), fingerprint(semantic), day == turn // config.turns_per_day and hour == turn % config.turns_per_day)

