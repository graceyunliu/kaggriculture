from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ConstantOpponentBelief:
    archetype: str = "UNKNOWN"
    confidence: float = 0.0
    model_version: str = "v1-constant-belief"

