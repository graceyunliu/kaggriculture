"""Fresh-build Kaggriculture agent."""

from .version import AGENT_VERSION

__all__ = ["AGENT_VERSION"]

