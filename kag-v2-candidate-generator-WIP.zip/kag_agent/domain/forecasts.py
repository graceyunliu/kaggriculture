from __future__ import annotations

from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True, slots=True)
class DiscreteDistribution:
    values: tuple[float, ...]
    probabilities: tuple[float, ...]

    def __post_init__(self) -> None:
        if not self.values or len(self.values) != len(self.probabilities):
            raise ValueError("distribution values and probabilities must align")
        if any(value < 0 for value in self.probabilities) or abs(sum(self.probabilities) - 1.0) > 1e-9:
            raise ValueError("probabilities must be nonnegative and sum to one")

    @classmethod
    def point_mass(cls, value: float) -> "DiscreteDistribution":
        return cls((value,), (1.0,))

    @property
    def expected_value(self) -> float:
        return sum(value * probability for value, probability in zip(self.values, self.probabilities))


@dataclass(frozen=True, slots=True)
class TerminalOutcomeForecast:
    our_terminal_cash: DiscreteDistribution
    opponent_terminal_cash: DiscreteDistribution
    win_probability: float
    tie_probability: float
    model_version: str
    assumptions: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Quantile:
    probability: float
    value: float


@dataclass(frozen=True, slots=True)
class ForecastDistribution:
    metric: str
    unit: str
    mean: float
    variance: float
    quantiles: tuple[Quantile, ...]
    minimum: float
    maximum: float
    scenario_count: int
    effective_sample_size: float
    model_version: str
    assumptions: tuple[str, ...]
    as_of_turn: int

    def __post_init__(self) -> None:
        probabilities = [item.probability for item in self.quantiles]
        values = [item.value for item in self.quantiles]
        if not all(isfinite(value) for value in (self.mean, self.variance, self.minimum, self.maximum)):
            raise ValueError("forecast values must be finite")
        if self.variance < 0 or self.scenario_count < 1 or self.effective_sample_size <= 0:
            raise ValueError("invalid forecast sample metadata")
        if any(not 0 < value < 1 for value in probabilities) or probabilities != sorted(set(probabilities)):
            raise ValueError("quantile probabilities must be strictly increasing in (0,1)")
        if values != sorted(values) or self.minimum > self.maximum or any(not self.minimum <= value <= self.maximum for value in values):
            raise ValueError("invalid forecast range or quantiles")
        if not self.model_version or not self.assumptions:
            raise ValueError("forecast provenance is required")

    @classmethod
    def point(cls, metric: str, unit: str, value: float, model_version: str, assumptions: tuple[str, ...], as_of_turn: int) -> "ForecastDistribution":
        return cls(metric, unit, value, 0.0, (Quantile(.5, value),), value, value, 1, 1.0, model_version, assumptions, as_of_turn)


@dataclass(frozen=True, slots=True)
class AssetCashFlow:
    asset_id: str
    product: str
    production_by_turn: dict[int, ForecastDistribution]
    cash_revenue_by_turn: dict[int, ForecastDistribution]
    explicit_cost_by_turn: dict[int, ForecastDistribution]
    required_actions_by_day: dict[int, ForecastDistribution]
    occupied_tile_days: float
    payback_turn: int | None
    liquidation_probability: float
    failure_loss: ForecastDistribution


@dataclass(frozen=True, slots=True)
class ProductionForecast:
    model_version: str
    policy_id: str
    asset_cash_flows: tuple[AssetCashFlow, ...]
    aggregate_required_actions_by_day: dict[int, ForecastDistribution]
    capacity_violation_probability_by_day: dict[int, float]


def v1_degenerate_forecast(our_cash: int, opponent_cash: int) -> TerminalOutcomeForecast:
    return TerminalOutcomeForecast(
        DiscreteDistribution.point_mass(float(our_cash)), DiscreteDistribution.point_mass(float(opponent_cash)),
        1.0 if our_cash > opponent_cash else 0.0, 1.0 if our_cash == opponent_cash else 0.0,
        "v1-degenerate-current-cash", ("future production excluded", "future market movement excluded"),
    )
