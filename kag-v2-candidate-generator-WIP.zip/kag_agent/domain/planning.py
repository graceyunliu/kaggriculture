from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from kag_agent.domain.actions import ActionEnvelope, MarketOp, UnitOp
from kag_agent.domain.state import Position


class ObligationKind(StrEnum):
    WATER = "WATER"
    FEED = "FEED"
    CARE = "CARE"
    HARVEST = "HARVEST"
    COLLECT_FERTILIZER = "COLLECT_FERTILIZER"
    LIQUIDATE = "LIQUIDATE"
    DROP_INVENTORY = "DROP_INVENTORY"
    PREVENT_OVERFLOW = "PREVENT_OVERFLOW"


@dataclass(frozen=True, slots=True)
class Obligation:
    obligation_id: str
    kind: ObligationKind
    target: Position | str
    earliest_turn: int
    deadline_turn: int
    required_unit_ops: int
    failure_terminal_value: int
    completion_terminal_value: int
    prerequisites: tuple[str, ...]
    hard: bool
    source_asset_id: str | None


@dataclass(frozen=True, slots=True)
class PlannedTask:
    task_id: str
    target: Position | str
    operation: UnitOp | MarketOp
    item: str | None
    quantity: int | None
    deadline_turn: int
    expected_terminal_value: int
    hard: bool = False
    source_obligation_id: str | None = None
    unit_id: str | None = None


@dataclass(frozen=True, slots=True)
class ScheduleResult:
    envelope: ActionEnvelope
    completed_task_ids: tuple[str, ...] = ()
    deferred_task_ids: tuple[str, ...] = ()
    infeasible_task_ids: tuple[str, ...] = ()
    fallback_level: int = 0
    reasons: tuple[str, ...] = ()
