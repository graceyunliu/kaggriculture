from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class UnitOp(StrEnum):
    NORTH = "NORTH"
    SOUTH = "SOUTH"
    EAST = "EAST"
    WEST = "WEST"
    PASS = "PASS"
    PICKUP = "PICKUP"
    PLACE = "PLACE"
    DROP = "DROP"
    PLANT = "PLANT"
    WATER = "WATER"
    HARVEST = "HARVEST"
    FERTILIZE = "FERTILIZE"
    FEED = "FEED"
    COLLECT_FERTILIZER = "COLLECT_FERTILIZER"
    CARE = "CARE"
    BUILD_COOP = "BUILD_COOP"
    BUILD_PASTURE = "BUILD_PASTURE"
    DIG = "DIG"


class MarketOp(StrEnum):
    BUY_SEED = "BUY_SEED"
    BUY_PRODUCT = "BUY_PRODUCT"
    BUY_ANIMAL = "BUY_ANIMAL"
    SELL = "SELL"
    HIRE = "HIRE"
    BUY_LAND = "BUY_LAND"


@dataclass(frozen=True, slots=True)
class UnitAction:
    op: UnitOp
    item: str | None = None
    quantity: int | None = None


@dataclass(frozen=True, slots=True)
class MarketOrder:
    op: MarketOp
    item: str | None = None
    quantity: int | None = None


@dataclass(frozen=True, slots=True)
class ActionEnvelope:
    farmer: UnitAction
    hands: tuple[UnitAction, ...] = ()
    market: tuple[MarketOrder, ...] = ()


@dataclass(frozen=True, slots=True)
class ValidationResult:
    valid: bool
    reasons: tuple[str, ...] = ()


PASS_ACTION = UnitAction(UnitOp.PASS)


def pass_envelope(hand_count: int = 0) -> ActionEnvelope:
    return ActionEnvelope(PASS_ACTION, tuple(PASS_ACTION for _ in range(hand_count)), ())

