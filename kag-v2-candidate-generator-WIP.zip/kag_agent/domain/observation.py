from __future__ import annotations

from dataclasses import dataclass

from kag_agent.domain.state import PrivateFarmState, PublicFarmState


@dataclass(frozen=True, slots=True)
class GameConfig:
    episode_steps: int = 720
    board_size: int = 10
    starting_money: int = 3000
    max_market_orders_per_turn: int = 10
    turns_per_day: int = 24
    shed_capacity: int = 100
    weed_spawn_chance: float = 0.005
    town_shop_unlock_interval_days: int = 3
    town_shop_sell_interval_turns: int = 4
    town_center_sell_interval_turns: int = 12
    farm_hand_cost_mult: int = 1


@dataclass(frozen=True, slots=True)
class NormalizedObservation:
    schema_version: str
    player_id: int
    turn: int
    day: int
    hour: int
    config: GameConfig
    farms: tuple[PublicFarmState, PublicFarmState]
    private: PrivateFarmState
    market_inventory: dict[str, int]
    market_prices: dict[str, int]
    unlocked_shops: frozenset[str]
    observation_fingerprint: str
    temporal_consistent: bool = True

    @property
    def our_farm(self) -> PublicFarmState:
        return self.farms[self.player_id]

    @property
    def opponent_farm(self) -> PublicFarmState:
        return self.farms[1 - self.player_id]

