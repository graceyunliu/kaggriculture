from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, TypeAlias


@dataclass(frozen=True, slots=True, order=True)
class Position:
    x: int
    y: int

    def on_board(self, board_size: int) -> bool:
        return 0 <= self.x < board_size and 0 <= self.y < board_size

    def manhattan(self, other: "Position") -> int:
        return abs(self.x - other.x) + abs(self.y - other.y)


@dataclass(frozen=True, slots=True)
class TileState:
    position: Position
    kind: Literal["EMPTY", "LOCKED", "WEED", "PLANT", "COOP", "PASTURE"]
    data: dict[str, Any]


@dataclass(frozen=True, slots=True)
class UnitState:
    unit_id: str
    position: Position
    inventory: dict[str, int] | None


@dataclass(frozen=True, slots=True)
class PublicFarmState:
    player_id: int
    money: int
    tiles: tuple[tuple[TileState, ...], ...]
    farmer: UnitState
    hands: tuple[UnitState, ...]
    unlocked_quadrants: frozenset[str]
    hires_today: int


@dataclass(frozen=True, slots=True)
class PrivateFarmState:
    shed: dict[str, int]
    seeds: dict[str, int]
    unit_inventories: dict[str, dict[str, int]]

