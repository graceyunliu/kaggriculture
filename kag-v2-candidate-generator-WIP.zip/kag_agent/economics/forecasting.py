from __future__ import annotations

from dataclasses import dataclass

from kag_agent.domain.forecasts import AssetCashFlow, ForecastDistribution, ProductionForecast, Quantile
from kag_agent.rules.constants import CROPS
from kag_agent.economics.scenarios import ScenarioSet

MODEL_VERSION = "v2-cashflow-1"


def _distribution(metric: str, unit: str, values: tuple[float, ...], probabilities: tuple[float, ...], assumptions: tuple[str, ...], turn: int) -> ForecastDistribution:
    mean = sum(value * probability for value, probability in zip(values, probabilities))
    variance = sum(probability * (value - mean) ** 2 for value, probability in zip(values, probabilities))
    ordered = sorted(zip(values, probabilities))
    def q(probability: float) -> float:
        cumulative = 0.0
        for value, weight in ordered:
            cumulative += weight
            if cumulative + 1e-12 >= probability:
                return value
        return ordered[-1][0]
    ess = 1.0 / sum(weight * weight for weight in probabilities)
    return ForecastDistribution(metric, unit, mean, variance, tuple(Quantile(p, q(p)) for p in (.1, .5, .9)), min(values), max(values), len(values), ess, MODEL_VERSION, assumptions, turn)


def forecast_crop_project(*, crop: str, plant_turn: int, episode_steps: int, turns_per_day: int, scenarios: ScenarioSet, asset_id: str = "candidate-crop", action_capacity_by_day: int = 1) -> ProductionForecast:
    if crop not in CROPS:
        raise ValueError(f"unknown crop {crop}")
    spec = CROPS[crop]
    plant_day = plant_turn // turns_per_day
    harvest_day = plant_day + int(spec["max_yield_day"])
    harvest_turn = harvest_day * turns_per_day
    assumptions = scenarios.assumptions + ("maximum documented crop yield with daily executable care", "sale occurs at harvest", "unsold terminal inventory has zero value")
    feasible = harvest_turn < episode_steps and action_capacity_by_day >= 1
    quantity = int(spec["max_yield"]) if feasible else 0
    prices = tuple(round(float(spec_price(crop)) * scenario.price_multiplier) for scenario in scenarios.scenarios)
    probabilities = tuple(scenario.probability for scenario in scenarios.scenarios)
    revenues = tuple(float(quantity * price) for price in prices)
    cost = int(spec["seed"])
    payback = harvest_turn if feasible and min(revenues) >= cost else None
    revenue = _distribution("cash_revenue", "coins", revenues, probabilities, assumptions, plant_turn)
    production = _distribution("production", "units", tuple(float(quantity) for _ in scenarios.scenarios), probabilities, assumptions, plant_turn)
    point_cost = ForecastDistribution.point("explicit_cost", "coins", float(cost), MODEL_VERSION, assumptions, plant_turn)
    actions = {day: ForecastDistribution.point("required_actions", "unit_actions", 1.0, MODEL_VERSION, assumptions, plant_turn) for day in range(plant_day, min(harvest_day + 1, (episode_steps - 1) // turns_per_day + 1))}
    failure = ForecastDistribution.point("failure_loss", "coins", float(cost if not feasible else 0), MODEL_VERSION, assumptions, plant_turn)
    flow = AssetCashFlow(asset_id, crop, {harvest_turn: production} if feasible else {}, {harvest_turn: revenue} if feasible else {}, {plant_turn: point_cost}, actions, float(max(0, harvest_day - plant_day)), payback, 1.0 if feasible else 0.0, failure)
    capacity = {day: 1.0 if distribution.mean > action_capacity_by_day else 0.0 for day, distribution in actions.items()}
    return ProductionForecast(MODEL_VERSION, asset_id, (flow,), actions, capacity)


def spec_price(crop: str) -> int:
    from kag_agent.rules.constants import MARKET_PARAMS
    return int(MARKET_PARAMS[crop]["base"])
