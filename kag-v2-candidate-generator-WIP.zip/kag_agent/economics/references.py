from __future__ import annotations

from dataclasses import dataclass

from kag_agent.planning.policy import PolicyIntent


@dataclass(frozen=True, slots=True)
class ExecutableReferenceSpec:
    reference_id: str
    crop: str
    target_assets: int
    daily_hires: int
    land_purchase_limit: int = 0
    animal: str | None = None
    animal_target: int = 0
    description: str = ""
    crop_targets: tuple[tuple[str, int], ...] = ()

    def intent(self, turn: int, turns_remaining: int, turns_per_day: int, money: int) -> PolicyIntent:
        phase = "LIQUIDATE" if turns_remaining <= turns_per_day else "OPERATE"
        return PolicyIntent(
            f"reference-{self.reference_id}", phase, self.crop, 250, money,
            f"v2-reference-{self.reference_id}-1", self.target_assets,
            self.daily_hires, self.land_purchase_limit, self.animal,
            self.animal_target, self.crop_targets,
        )


EXECUTABLE_REFERENCES = {
    item.reference_id: item for item in (
        ExecutableReferenceSpec("initial-crop-saturation", "CARROT", 20, 6, description="initial-quadrant crop saturation"),
        ExecutableReferenceSpec("crop-expansion-hands", "MELON", 25, 8, description="crop expansion with hired hands"),
        ExecutableReferenceSpec("crop-expansion-land", "MELON", 40, 8, 1, description="crop expansion with deterministic land purchase"),
        ExecutableReferenceSpec("goose-wheat", "WHEAT", 20, 8, 0, "GOOSE", 6, "goose and wheat production"),
        ExecutableReferenceSpec("cow-sheep-wheat", "WHEAT", 20, 8, 0, "SHEEP", 5, "pasture animal and wheat production"),
        ExecutableReferenceSpec("mixed-duration", "TOMATO", 25, 8, description="mixed early cash and ongoing production"),
        ExecutableReferenceSpec("reinvest-liquidate", "STRAWBERRY", 40, 8, 1, description="reinvestment followed by terminal liquidation"),
    )
}
