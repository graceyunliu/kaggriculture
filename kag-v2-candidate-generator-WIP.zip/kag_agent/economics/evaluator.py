from __future__ import annotations

from dataclasses import dataclass

from kag_agent.domain.forecasts import ProductionForecast
from kag_agent.economics.forecasting import forecast_crop_project
from kag_agent.economics.scenarios import ScenarioSet


@dataclass(frozen=True, slots=True)
class EconomicPolicy:
    policy_id: str
    crop: str
    project_count: int
    capital_cost: int = 0
    daily_capacity: int = 1
    assumptions: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class PolicyEvaluation:
    policy: EconomicPolicy
    feasibility: str
    infeasibility_reasons: tuple[str, ...]
    expected_terminal_value: float
    worst_case_terminal_value: float
    payback_turn: int | None
    production: ProductionForecast
    sensitivity: tuple[tuple[str, float], ...]
    completed: bool = True


def evaluate_policy(policy: EconomicPolicy, *, turn: int, episode_steps: int, turns_per_day: int, cash: int, scenarios: ScenarioSet) -> PolicyEvaluation:
    forecast = forecast_crop_project(crop=policy.crop, plant_turn=turn, episode_steps=episode_steps, turns_per_day=turns_per_day, scenarios=scenarios, asset_id=policy.policy_id, action_capacity_by_day=policy.daily_capacity)
    flow = forecast.asset_cash_flows[0]
    revenue = next(iter(flow.cash_revenue_by_turn.values()), None)
    total_cost = next(iter(flow.explicit_cost_by_turn.values())).mean * policy.project_count + policy.capital_cost
    reasons = []
    if total_cost > cash:
        reasons.append("insufficient_capital")
    if flow.payback_turn is None:
        reasons.append("cannot_pay_back_before_terminal_deadline")
    if any(value > 0 for value in forecast.capacity_violation_probability_by_day.values()) or policy.project_count > policy.daily_capacity:
        reasons.append("daily_obligations_exceed_capacity")
    scenario_values = tuple((value * policy.project_count) - total_cost for value in (revenue.quantiles[0].value, revenue.mean, revenue.quantiles[-1].value)) if revenue else (-total_cost,)
    sensitivity = tuple(zip(("LOW", "MEDIUM", "HIGH"), reversed(scenario_values))) if len(scenario_values) == 3 else (("TERMINAL", scenario_values[0]),)
    return PolicyEvaluation(policy, "FEASIBLE" if not reasons else "INFEASIBLE", tuple(reasons), cash + (revenue.mean * policy.project_count if revenue else 0) - total_cost, cash + min(scenario_values), flow.payback_turn, forecast, sensitivity)


def evaluate_policies(policies: tuple[EconomicPolicy, ...], **kwargs) -> tuple[PolicyEvaluation, ...]:
    evaluations = tuple(evaluate_policy(policy, **kwargs) for policy in policies)
    feasible = [item for item in evaluations if item.feasibility == "FEASIBLE" and item.completed]
    dominated = {candidate.policy.policy_id for candidate in feasible for other in feasible if other.policy.policy_id != candidate.policy.policy_id and other.expected_terminal_value >= candidate.expected_terminal_value and other.worst_case_terminal_value >= candidate.worst_case_terminal_value and (other.expected_terminal_value > candidate.expected_terminal_value or other.worst_case_terminal_value > candidate.worst_case_terminal_value)}
    return tuple(PolicyEvaluation(item.policy, "INFEASIBLE" if item.policy.policy_id in dominated else item.feasibility, item.infeasibility_reasons + (("dominated",) if item.policy.policy_id in dominated else ()), item.expected_terminal_value, item.worst_case_terminal_value, item.payback_turn, item.production, item.sensitivity, item.completed) for item in evaluations)


def select_best(evaluations: tuple[PolicyEvaluation, ...]) -> PolicyEvaluation:
    feasible = [item for item in evaluations if item.feasibility == "FEASIBLE" and item.completed]
    if not feasible:
        raise ValueError("no completed feasible policy")
    return max(feasible, key=lambda item: (item.worst_case_terminal_value, item.expected_terminal_value, item.policy.policy_id))
