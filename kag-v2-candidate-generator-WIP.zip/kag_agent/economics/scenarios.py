from __future__ import annotations

from dataclasses import dataclass

from kag_agent.config import fingerprint


@dataclass(frozen=True, slots=True)
class Scenario:
    scenario_id: str
    probability: float
    supply_level: str
    price_multiplier: float
    opponent_units_per_day: float
    product_supply_per_day: tuple[tuple[str, float], ...] = ()

    def supply_for(self, product: str) -> float:
        mapping = dict(self.product_supply_per_day)
        return mapping.get(product, self.opponent_units_per_day / 5.0)


@dataclass(frozen=True, slots=True)
class ScenarioSet:
    scenario_set_id: str
    generator_version: str
    as_of_turn: int
    scenarios: tuple[Scenario, ...]
    sampling_seed: int
    assumptions: tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.scenarios or abs(sum(item.probability for item in self.scenarios) - 1.0) > 1e-9:
            raise ValueError("scenario probabilities must sum to one")


def broad_scenarios(as_of_turn: int, sampling_seed: int = 0) -> ScenarioSet:
    rows = (("LOW", .25, 1.15, 2.0), ("MEDIUM", .50, 1.0, 8.0), ("HIGH", .25, .75, 20.0))
    mixes = {
        "LOW": (("WHEAT", .4), ("CARROT", .4), ("TOMATO", .4), ("STRAWBERRY", .2), ("MELON", .6)),
        "MEDIUM": (("WHEAT", 1.5), ("CARROT", 1.5), ("TOMATO", 1.2), ("STRAWBERRY", .8), ("MELON", 2.0)),
        "HIGH": (("WHEAT", 4.0), ("CARROT", 4.0), ("TOMATO", 3.0), ("STRAWBERRY", 2.0), ("MELON", 5.0)),
    }
    scenarios = tuple(Scenario(f"supply-{level.lower()}", probability, level, multiplier, units, mixes[level]) for level, probability, multiplier, units in rows)
    assumptions = ("opponent supply represented by fixed low/medium/high cases", "prices are provisional until V3 opponent inference")
    identity = fingerprint({"turn": as_of_turn, "seed": sampling_seed, "rows": rows, "mixes": mixes, "version": "v2-broad-scenarios-2"})[:20]
    return ScenarioSet(f"scenarios-{identity}", "v2-broad-scenarios-2", as_of_turn, scenarios, sampling_seed, assumptions)
