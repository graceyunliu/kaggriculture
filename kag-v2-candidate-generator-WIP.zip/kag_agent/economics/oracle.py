from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

from kag_agent.rules.constants import CROPS, MARKET_PARAMS


@dataclass(frozen=True, slots=True)
class OracleResult:
    oracle_version: str
    horizon_days: int
    tile_limit: int
    optimistic_terminal_cash: int
    best_activity: str
    assumptions: tuple[str, ...]


def _one_shot_profit(crop: str) -> int:
    return int(CROPS[crop]["max_yield"]) * int(MARKET_PARAMS[crop]["base"]) - int(CROPS[crop]["seed"])


def exact_single_tile_optimum(horizon_days: int, allowed_crops: tuple[str, ...] = ("WHEAT", "CARROT", "MELON")) -> tuple[int, tuple[str, ...]]:
    """Exact dynamic program for the declared reduced one-tile, one-shot fixture."""
    if horizon_days < 0 or any(crop not in CROPS or CROPS[crop]["ongoing"] for crop in allowed_crops):
        raise ValueError("reduced oracle requires nonnegative horizon and one-shot crops")

    @lru_cache(maxsize=None)
    def solve(day: int) -> tuple[int, tuple[str, ...]]:
        if day >= horizon_days:
            return 0, ()
        best = solve(day + 1)
        for crop in allowed_crops:
            duration = int(CROPS[crop]["max_yield_day"])
            if day + duration >= horizon_days:
                continue
            future, sequence = solve(day + duration)
            candidate = (_one_shot_profit(crop) + future, (crop, *sequence))
            if candidate[0] > best[0] or (candidate[0] == best[0] and candidate[1] < best[1]):
                best = candidate
        return best
    return solve(0)


def _ongoing_profit(crop: str, horizon_days: int) -> int:
    spec = CROPS[crop]
    first = int(spec["first_yield_day"])
    if first >= horizon_days:
        return -int(spec["seed"])
    production_days = 1 + (horizon_days - 1 - first) // int(spec["interval"])
    # The official refresh adds one unit per production interval; max_yield is
    # held inventory capacity, not production per interval.
    return production_days * int(MARKET_PARAMS[crop]["base"]) - int(spec["seed"])


def optimistic_self_economy_upper_bound(*, horizon_days: int = 30, tile_limit: int = 25, starting_cash: int = 3000) -> OracleResult:
    """A documented relaxation: perfect care, routing, prices, financing and liquidation."""
    one_shot, sequence = exact_single_tile_optimum(horizon_days)
    candidates = {"ONE_SHOT:" + ",".join(sequence): one_shot}
    for crop, spec in CROPS.items():
        if spec["ongoing"]:
            candidates[crop] = _ongoing_profit(crop, horizon_days)
    activity, per_tile_profit = max(candidates.items(), key=lambda item: (item[1], item[0]))
    assumptions = (
        "perfect future price knowledge at official base prices",
        "perfect care, harvest, routing, shed access, and liquidation",
        "each tile receives relaxed independent financing",
        "no weeds, congestion, market impact, or opponent interference",
        "therefore result is an upper bound, never an executable forecast",
    )
    return OracleResult("v2-optimistic-relaxation-1", horizon_days, tile_limit, starting_cash + tile_limit * max(0, per_tile_profit), activity, assumptions)


def oracle_gap(realized_cash: float, oracle: OracleResult) -> dict[str, float]:
    if realized_cash < 0 or oracle.optimistic_terminal_cash <= 0:
        raise ValueError("cash values must be nonnegative")
    return {"realized_cash": float(realized_cash), "upper_bound_cash": float(oracle.optimistic_terminal_cash), "attainment_ratio": float(realized_cash) / oracle.optimistic_terminal_cash, "absolute_gap": oracle.optimistic_terminal_cash - float(realized_cash)}
