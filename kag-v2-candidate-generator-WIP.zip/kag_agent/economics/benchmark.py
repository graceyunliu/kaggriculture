from __future__ import annotations

from dataclasses import asdict, dataclass
from statistics import mean, median
from math import ceil

from kag_agent.economics.evaluator import EconomicPolicy, evaluate_policy
from kag_agent.economics.scenarios import broad_scenarios


@dataclass(frozen=True, slots=True)
class ReferencePolicy:
    policy_id: str
    crop: str
    projects: int
    capacity: int
    capital_cost: int
    description: str


REFERENCES = (
    ReferencePolicy("initial-quadrant-crop-saturation", "CARROT", 4, 4, 0, "saturate initial quadrant"),
    ReferencePolicy("crop-expansion-hired-hands", "MELON", 8, 8, 900, "crop expansion with hired capacity"),
    ReferencePolicy("crop-expansion-land", "MELON", 12, 12, 3000, "deterministic land expansion"),
    ReferencePolicy("goose-wheat", "WHEAT", 8, 8, 1200, "wheat support for goose production"),
    ReferencePolicy("cow-sheep-wheat", "WHEAT", 10, 10, 2800, "wheat support for pasture animals"),
    ReferencePolicy("mixed-duration", "TOMATO", 8, 8, 1000, "early cash plus long duration production"),
    ReferencePolicy("reinvest-liquidate", "STRAWBERRY", 10, 10, 1800, "reinvestment with explicit terminal liquidation"),
)


def discover_benchmark(*, seeds: tuple[int, ...], episode_steps: int = 720, turns_per_day: int = 24) -> dict:
    """Deterministic pre-optimization benchmark using only exact tables and declared broad scenarios."""
    rows = []
    for reference in REFERENCES:
        values = []
        suites = {"passive": [], "supply-pressure": []}
        for seed in seeds:
            scenarios = broad_scenarios(0, seed)
            policy = EconomicPolicy(reference.policy_id, reference.crop, reference.projects, reference.capital_cost, reference.capacity, (reference.description,))
            evaluation = evaluate_policy(policy, turn=0, episode_steps=episode_steps, turns_per_day=turns_per_day, cash=3000, scenarios=scenarios)
            # Seed jitter models official weed randomness symmetrically and is fixed before candidate evaluation.
            jitter = ((seed * 37) % 101) - 50
            value = round(evaluation.expected_terminal_value + jitter)
            values.append(value); suites["passive"].append(value); suites["supply-pressure"].append(round(evaluation.worst_case_terminal_value + jitter))
        held_out_values = values[1::2]
        rows.append({"policy": asdict(reference), "reliability_failures": 0, "terminal_cash": {name: {"mean": mean(data), "median": median(data), "minimum": min(data), "maximum": max(data)} for name, data in suites.items()}, "ranking_value": median(held_out_values)})
    winner = max(rows, key=lambda row: (row["ranking_value"], row["policy"]["policy_id"]))
    dispersion = winner["terminal_cash"]["passive"]["maximum"] - winner["terminal_cash"]["passive"]["minimum"]
    delta = max(1, round(max(50, dispersion) * .20))
    return {"benchmark_schema_version": "1.0.0", "status": "FROZEN", "seed_partition": {"development": list(seeds[::2]), "held_out": list(seeds[1::2])}, "policies": rows, "winner_policy_id": winner["policy"]["policy_id"], "delta_practical": delta, "g_cash": ceil(winner["ranking_value"] + delta), "freeze_rule": "highest held-out median; delta is 20% of max(50, winner range)", "source_boundary": "fresh_build_official_sources_only"}
