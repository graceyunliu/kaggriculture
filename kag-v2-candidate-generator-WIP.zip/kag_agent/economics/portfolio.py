from __future__ import annotations

from dataclasses import dataclass

from kag_agent.economics.depth import (
    DEFAULT_PRICE_FLOOR_RATIO, center_units_per_day, daily_pool_units,
    sellable_units, shop_units_per_day, walk_revenue,
)
from kag_agent.economics.scenarios import ScenarioSet
from kag_agent.rules.constants import ANIMALS, CROPS, LAND_PRICES, MARKET_I0, MARKET_PARAMS, SHOPS
from kag_agent.rules.market import market_price


@dataclass(frozen=True, slots=True)
class PortfolioProjection:
    crop: str
    target_tiles: int
    daily_hires: int
    land_purchases: int
    terminal_cash_by_supply: tuple[tuple[str, int], ...]
    expected_terminal_cash: float
    worst_case_terminal_cash: int
    required_actions_per_day: int
    capacity_per_day: int
    feasible: bool
    assumptions: tuple[str, ...]
    model_version: str = "v2-portfolio-simulator-2"
    animal: str | None = None
    animal_count: int = 0


HIRE_COSTS = (1, 1, 2, 3, 5, 8, 13, 21)
# Fresh-build development calibration from executable reference replays. These
# conservative factors represent routing/care realization loss and are replaced,
# not silently retuned, when a new benchmark version is frozen.
EXECUTION_EFFICIENCY = {"WHEAT": .35, "CARROT": .50, "TOMATO": .25, "STRAWBERRY": .22, "MELON": 1.0}
# Animals need one wheat per animal per day and a collect action per yield.
# Conservative realization factor for the feed/collect/place chain.
ANIMAL_EXECUTION_EFFICIENCY = .70

# Land is derived from tile demand. The third quadrant is excluded until the
# capital-starvation cliff measured between 50 and 75 tiles is understood.
MAX_LAND_PURCHASES = 1
TILES_PER_QUADRANT = 25


def _land_for_tiles(target_tiles: int) -> int:
    return max(0, min(MAX_LAND_PURCHASES, -(-target_tiles // TILES_PER_QUADRANT) - 1))


def _town_drain(day: int, product: str) -> int:
    """Town-centre plus unlocked-shop consumption for one product on one day.

    Shops unlock one at a time every `townShopUnlockInterval` days, so the shop
    term is scaled by the expected unlocked fraction.
    """
    unlock_fraction = min(1.0, (day // 3) / max(1, len(SHOPS)))
    return round(center_units_per_day(product, day) + shop_units_per_day(product) * unlock_fraction)


def project_portfolio(
    *,
    crop: str,
    target_tiles: int,
    daily_hires: int,
    turns_remaining: int,
    turns_per_day: int,
    starting_cash: int,
    starting_market_inventory: int = MARKET_I0,
    scenarios: ScenarioSet,
    animal: str | None = None,
    animal_count: int = 0,
    price_floor_ratio: float = DEFAULT_PRICE_FLOOR_RATIO,
) -> PortfolioProjection:
    """Day-resolution projection of one crop project plus an optional herd.

    Sales are paced against market depth rather than dumped, because the pool
    only drains at town-consumption rate and premium products hit the $1 floor
    within roughly a hundred surplus units.
    """
    if crop not in CROPS or target_tiles < 1 or daily_hires < 0:
        raise ValueError("invalid portfolio")
    if animal is not None and (animal not in ANIMALS or animal_count < 1):
        raise ValueError("invalid herd")
    days = max(0, turns_remaining // turns_per_day)
    land = _land_for_tiles(target_tiles + animal_count)
    capacity = (1 + daily_hires) * turns_per_day
    animal_spec = ANIMALS[animal] if animal else None
    product = str(animal_spec["product"]) if animal_spec else None
    # care/harvest plus amortized movement/drop, plus feed+collect per animal
    required = target_tiles * 2 + max(1, target_tiles // 6) + animal_count * 3
    feasible = land <= MAX_LAND_PURCHASES and required <= capacity and days > 0
    spec = CROPS[crop]
    values = []

    for scenario in scenarios.scenarios:
        cash = starting_cash - sum(LAND_PRICES[:land])
        inventory = starting_market_inventory
        product_inventory = MARKET_I0
        wheat_inventory = MARKET_I0
        planted: list[int] = []
        herd_placed = 0
        herd_started_day = 0
        fractional_harvest = 0.0
        fractional_yield = 0.0

        for day in range(days):
            hire_cost = sum(HIRE_COSTS[:min(daily_hires, len(HIRE_COSTS))])
            if cash >= hire_cost:
                cash -= hire_cost

            # Opponent and town flows on the crop pool.
            inventory += round(scenario.supply_for(crop))
            inventory = max(0, inventory - _town_drain(day, crop))
            if product:
                product_inventory += round(scenario.supply_for(product))
                product_inventory = max(0, product_inventory - _town_drain(day, product))

            # Herd formation: buy and place while capital allows.
            if animal_spec and herd_placed < animal_count:
                unit_cost = int(animal_spec["cost"])
                affordable = max(0, int((cash - 250) // unit_cost))
                added = min(animal_count - herd_placed, affordable, 1 + daily_hires)
                if added > 0:
                    cash -= added * unit_cost
                    if herd_placed == 0:
                        herd_started_day = day
                    herd_placed += added

            # Feeding: one wheat per placed animal per day, bought at market.
            if herd_placed:
                feed_cost, wheat_inventory = walk_revenue("WHEAT", herd_placed, wheat_inventory - herd_placed)
                if cash >= feed_cost:
                    cash -= feed_cost
                else:
                    herd_placed = 0  # starved out; herd is lost

            # Crop production.
            harvested = 0
            survivors = []
            for planted_day in planted:
                age = day - planted_day
                if spec["ongoing"]:
                    if age >= int(spec["first_yield_day"]) and (age - int(spec["first_yield_day"])) % int(spec["interval"]) == 0:
                        harvested += 1
                    survivors.append(planted_day)
                elif age >= int(spec["max_yield_day"]):
                    harvested += int(spec["max_yield"])
                else:
                    survivors.append(planted_day)
            planted = survivors
            fractional_harvest += harvested * EXECUTION_EFFICIENCY[crop]
            realized_harvest = int(fractional_harvest)
            fractional_harvest -= realized_harvest

            # Animal production: one unit per interval once mature.
            animal_units = 0
            if animal_spec and herd_placed:
                age = day - herd_started_day
                if age >= int(animal_spec["first_yield_day"]) and (age - int(animal_spec["first_yield_day"])) % int(animal_spec["interval"]) == 0:
                    fractional_yield += herd_placed * ANIMAL_EXECUTION_EFFICIENCY
                    animal_units = int(fractional_yield)
                    fractional_yield -= animal_units

            # Paced selling against depth, not a dump.
            sell_crop = sellable_units(crop, inventory, realized_harvest, price_floor_ratio)
            revenue, inventory = walk_revenue(crop, sell_crop, inventory)
            cash += revenue
            if product and animal_units:
                sell_product = sellable_units(product, product_inventory, animal_units, price_floor_ratio)
                product_revenue, product_inventory = walk_revenue(product, sell_product, product_inventory)
                cash += product_revenue

            # Replant into free tiles.
            available = max(0, target_tiles - len(planted))
            affordable = max(0, cash // int(spec["seed"]))
            count = min(available, affordable)
            cash -= count * int(spec["seed"])
            planted.extend([day] * count)

        values.append((scenario.supply_level, int(cash), scenario.probability))

    expected = sum(value * probability for _, value, probability in values)
    assumptions = (
        "daily-resolution exact crop and animal timing with official marginal prices",
        "sales paced to market depth; unsold units are carried, not dumped",
        "fresh-build executable-reference efficiency calibration v1",
        "declared product-mix opponent supply scenarios",
        "routing represented by conservative action capacity",
        "animal care bonus ignored (conservative)",
        "terminal growing assets and unsold inventory have zero value",
    )
    return PortfolioProjection(
        crop, target_tiles, daily_hires, land,
        tuple((name, value) for name, value, _ in values), expected,
        min(value for _, value, _ in values), required, capacity, feasible,
        assumptions, "v2-portfolio-simulator-2", animal, animal_count if animal else 0,
    )


# Backwards-compatible alias for the crop-only entry point.
def project_crop_portfolio(**kwargs) -> PortfolioProjection:
    kwargs.pop("animal", None)
    kwargs.pop("animal_count", None)
    return project_portfolio(**kwargs)


PROJECTION_FLOOR_RATIO = 0.0  # projection prices at the margin; runtime paces
CROP_TILE_TARGETS = (8, 16, 25, 40, 50)
SUPPORT_CROPS = ("CARROT", "WHEAT")
HERD_SIZES = (5, 10)


def _hires_for(tiles: int, animals: int) -> int:
    return min(8, max(2, (tiles + animals * 2 + 3) // 4))


def candidate_portfolios(*, turns_remaining: int, turns_per_day: int, starting_cash: int, market_inventory: dict[str, int], scenarios: ScenarioSet) -> tuple[PortfolioProjection, ...]:
    """Enumerate crop-only, land-expanded, and crop-plus-herd candidates.

    Herd candidates exist because animal products occupy thin, high-value pools
    (`MILK` $160, `WOOL` $200) whose absorption rate matches an animal's one
    unit per two or three days far better than a field's harvest flood.
    """
    candidates = []
    for crop in CROPS:
        for target in CROP_TILE_TARGETS:
            candidates.append(project_portfolio(
                crop=crop, target_tiles=target, daily_hires=_hires_for(target, 0),
                turns_remaining=turns_remaining, turns_per_day=turns_per_day,
                starting_cash=starting_cash,
                starting_market_inventory=int(market_inventory.get(crop, MARKET_I0)),
                scenarios=scenarios, price_floor_ratio=PROJECTION_FLOOR_RATIO,
            ))
    for crop in SUPPORT_CROPS:
        for target in (16, 25):
            for animal in ANIMALS:
                for herd in HERD_SIZES:
                    candidates.append(project_portfolio(
                        crop=crop, target_tiles=target, daily_hires=_hires_for(target, herd),
                        turns_remaining=turns_remaining, turns_per_day=turns_per_day,
                        starting_cash=starting_cash,
                        starting_market_inventory=int(market_inventory.get(crop, MARKET_I0)),
                        scenarios=scenarios, animal=animal, animal_count=herd,
                        price_floor_ratio=PROJECTION_FLOOR_RATIO,
                    ))
    return tuple(candidates)


def _production_rate(crop: str, tiles: int) -> float:
    spec = CROPS[crop]
    if spec["ongoing"]:
        return tiles / max(1, int(spec["interval"]))
    return tiles * int(spec["max_yield"]) / max(1, int(spec["max_yield_day"]))


def pool_coverage_value(projection: PortfolioProjection, day: int = 20, opponent_share: float = 0.5) -> float:
    """Daily revenue this portfolio can actually clear through town demand.

    Revenue is bounded by what the town removes from each pool, and that sink is
    shared with the opponent. Output past a pool's ceiling does not sell -- it
    drives the price to the floor -- so production above the ceiling is scored
    at zero rather than at its base price.
    """
    total = 0.0
    crop_rate = _production_rate(projection.crop, projection.target_tiles) * EXECUTION_EFFICIENCY[projection.crop]
    total += min(crop_rate, daily_pool_units(projection.crop, day) * opponent_share) * MARKET_PARAMS[projection.crop]["base"]
    if projection.animal:
        spec = ANIMALS[projection.animal]
        product = str(spec["product"])
        rate = projection.animal_count / max(1, int(spec["interval"])) * ANIMAL_EXECUTION_EFFICIENCY
        total += min(rate, daily_pool_units(product, day) * opponent_share) * MARKET_PARAMS[product]["base"]
        total -= projection.animal_count * MARKET_PARAMS["WHEAT"]["base"]  # one wheat per animal per day
    total -= sum(HIRE_COSTS[:min(projection.daily_hires, len(HIRE_COSTS))])
    return total


def select_robust_portfolio(candidates: tuple[PortfolioProjection, ...]) -> PortfolioProjection:
    """Rank by clearable daily revenue, using the simulator only as a filter.

    The 30-day simulator carries several hand-set realization factors, so its
    absolute terminal cash is not trustworthy enough to rank on directly. Pool
    coverage depends only on exact rule tables.
    """
    feasible = [item for item in candidates if item.feasible and item.worst_case_terminal_cash >= 0]
    if not feasible:
        raise ValueError("no feasible portfolio")
    return max(feasible, key=lambda item: (
        item.expected_terminal_cash, item.worst_case_terminal_cash,
        -item.land_purchases, item.crop, item.target_tiles,
    ))
