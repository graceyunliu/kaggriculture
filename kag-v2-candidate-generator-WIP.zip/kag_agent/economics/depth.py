"""Market-depth accounting.

The only sink for market inventory is town consumption, and both players share
it. Premium resources (base > $100) use `above_target > 1`, so a modest glut
drives them to the $1 floor while staples absorb volume. Revenue is therefore
bounded by how much of each product's demand pool we can cover per day, not by
how much we can produce.

These helpers answer one question: given the current inventory of a product,
how many units can be sold before the marginal price falls below an acceptable
fraction of its base price?
"""

from __future__ import annotations

from kag_agent.rules.constants import (
    MARKET_PARAMS, PRODUCTS, SHOPS, TOWN_CENTER_DEMAND_SCHEDULE, TOWN_CENTER_PRODUCTS,
)
from kag_agent.rules.market import market_price

MODEL_VERSION = "v2-market-depth-2"

# Holding a unit only pays if town consumption will pull the price back up.
# Below this fraction of base price a unit is held, but only for products the
# town actually drains.
DEFAULT_PRICE_FLOOR_RATIO = 0.35

# Absolute per-turn ceiling. Prevents a single harvest from walking a thin pool
# down even when every unit still clears the ratio test.
MAX_UNITS_PER_TURN = 24

# Engine-exact town consumption, from `_town_consume`: every
# `townShopSellInterval` turns each unlocked shop takes `2` of a single-product
# shop's item or `1` of each item otherwise; every `townCenterSellInterval`
# turns the centre takes `center_mult` of every product but FERTILIZER.
SHOP_SELL_INTERVAL_TURNS = 4
CENTER_SELL_INTERVAL_TURNS = 12


def base_price(product: str) -> int:
    return int(MARKET_PARAMS[product]["base"])


def shop_units_per_day(product: str, turns_per_day: int = 24, unlocked: tuple[str, ...] | None = None) -> int:
    """Units of `product` the unlocked shops consume per day."""
    names = SHOPS if unlocked is None else {name: SHOPS[name] for name in unlocked if name in SHOPS}
    per_event = sum(2 if len(items) == 1 else 1 for items in names.values() if product in items)
    return per_event * (turns_per_day // SHOP_SELL_INTERVAL_TURNS)


def center_units_per_day(product: str, day: int, turns_per_day: int = 24) -> int:
    if product not in TOWN_CENTER_PRODUCTS:
        return 0
    multiplier = next(value for threshold, value in TOWN_CENTER_DEMAND_SCHEDULE if day >= threshold)
    return multiplier * (turns_per_day // CENTER_SELL_INTERVAL_TURNS)


def daily_pool_units(product: str, day: int = 20, turns_per_day: int = 24, unlocked: tuple[str, ...] | None = None) -> int:
    """Total units per day the town removes from this product's pool.

    This is the real production ceiling. MELON appears in no shop, so its only
    sink is the town centre; producing past that ceiling drives the price to the
    floor no matter how the sales are paced.
    """
    return shop_units_per_day(product, turns_per_day, unlocked) + center_units_per_day(product, day, turns_per_day)


def daily_pool_value(product: str, day: int = 20) -> int:
    return daily_pool_units(product, day) * base_price(product)


def sellable_units(product: str, inventory: int, available: int, floor_ratio: float = DEFAULT_PRICE_FLOOR_RATIO) -> int:
    """Units of `product` worth selling now, walking the price as we go.

    A product with no shop demand never recovers within the season, so holding
    it is strictly worse than selling it: pacing is skipped entirely there.
    """
    if product not in PRODUCTS or available <= 0:
        return 0
    limit = min(int(available), MAX_UNITS_PER_TURN)
    if shop_units_per_day(product) == 0:
        return limit
    floor = max(1.0, floor_ratio * base_price(product))
    allowed = 0
    position = int(inventory)
    while allowed < limit and market_price(product, position) >= floor:
        allowed += 1
        position += 1
    return allowed


def walk_revenue(product: str, quantity: int, inventory: int) -> tuple[int, int]:
    """Exact revenue for selling `quantity` units, plus the resulting inventory."""
    revenue = 0
    position = int(inventory)
    for _ in range(max(0, int(quantity))):
        revenue += market_price(product, position)
        position += 1
    return revenue, position


def daily_absorption(product: str, floor_ratio: float = DEFAULT_PRICE_FLOOR_RATIO) -> int:
    """Units per day this pool absorbs at or above the floor, starting from I0.

    Used by the planner to size a portfolio against the demand pool rather than
    against available tiles.
    """
    return sellable_units(product, int(MARKET_PARAMS[product]["I0"]), MAX_UNITS_PER_TURN, floor_ratio)
