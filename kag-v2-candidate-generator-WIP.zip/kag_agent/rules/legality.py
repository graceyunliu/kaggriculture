from __future__ import annotations

from kag_agent.domain.actions import UnitOp
from kag_agent.domain.observation import NormalizedObservation
from kag_agent.domain.state import UnitState
from kag_agent.rules.geometry import is_shed_adjacent, move
from kag_agent.rules.lifecycle import crop_harvestable


def legal_unit_ops(observation: NormalizedObservation, unit: UnitState) -> frozenset[UnitOp]:
    legal = {UnitOp.PASS}
    for op in (UnitOp.NORTH, UnitOp.SOUTH, UnitOp.EAST, UnitOp.WEST):
        if move(unit.position, op.value, observation.config.board_size) is not None:
            legal.add(op)
    tile = observation.our_farm.tiles[unit.position.y][unit.position.x]
    if tile.kind == "LOCKED":
        return frozenset(legal)
    inventory = unit.inventory or {}
    if is_shed_adjacent(unit.position, observation.config.board_size):
        legal.update((UnitOp.DROP, UnitOp.PICKUP, UnitOp.PLACE))
    if tile.kind == "EMPTY":
        legal.update((UnitOp.PLANT, UnitOp.BUILD_COOP, UnitOp.BUILD_PASTURE))
    if tile.kind in {"WEED", "PLANT", "COOP", "PASTURE"} and "animal" not in tile.data:
        legal.add(UnitOp.DIG)
    if tile.kind == "PLANT":
        if not tile.data.get("watered_today"):
            legal.add(UnitOp.WATER)
        if crop_harvestable(tile.data, observation.day):
            legal.add(UnitOp.HARVEST)
        if inventory.get("FERTILIZER", 0) > 0:
            legal.add(UnitOp.FERTILIZE)
    if "animal" in tile.data:
        if not tile.data.get("fed_today") and inventory.get("WHEAT", 0) > 0:
            legal.add(UnitOp.FEED)
        if tile.data.get("yield_units", 0) > 0:
            legal.add(UnitOp.HARVEST)
        if tile.data.get("fertilizer_available"):
            legal.add(UnitOp.COLLECT_FERTILIZER)
        if not tile.data.get("cared_today"):
            legal.add(UnitOp.CARE)
    return frozenset(legal)

