from __future__ import annotations

import math

from kag_agent.rules.constants import MARKET_PARAMS, PRICE_FLOOR


def _shape(name: str, value: float) -> float:
    value = max(0.0, value)
    return {"linear": lambda x: x, "sq": lambda x: x * x, "sqrt": math.sqrt, "log": math.log1p, "log10": math.log10}.get(name, lambda x: x)(value)


def market_price(item: str, inventory: int, params: dict | None = None) -> int:
    spec = (params or MARKET_PARAMS)[item]
    base, initial, capacity = spec["base"], spec["I0"], spec["T"]
    if inventory < initial:
        shape = spec["below_func"]; amplitude = spec["below_target"] * base / _shape(shape, capacity)
        price = base + amplitude * _shape(shape, initial - inventory)
    else:
        shape = spec["above_func"]; amplitude = spec["above_target"] * base / _shape(shape, capacity)
        price = base - amplitude * _shape(shape, inventory - initial)
    return max(PRICE_FLOOR, int(round(price)))


def fib(index: int) -> int:
    a, b = 1, 1
    for _ in range(index):
        a, b = b, a + b
    return a


def hire_cost(hires_today: int, multiplier: int = 1) -> int:
    return multiplier * fib(hires_today)


def land_cost(unlocked_quadrants: int) -> int | None:
    from kag_agent.rules.constants import LAND_PRICES
    index = unlocked_quadrants - 1
    return LAND_PRICES[index] if 0 <= index < len(LAND_PRICES) else None


def town_center_multiplier(day: int) -> int:
    from kag_agent.rules.constants import TOWN_CENTER_DEMAND_SCHEDULE
    return next(multiplier for threshold, multiplier in TOWN_CENTER_DEMAND_SCHEDULE if day >= threshold)

