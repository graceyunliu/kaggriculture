from __future__ import annotations

from kag_agent.domain.state import Position


MOVES = {"NORTH": (0, -1), "SOUTH": (0, 1), "EAST": (1, 0), "WEST": (-1, 0)}


def shed_access_positions(board_size: int) -> tuple[Position, ...]:
    half = board_size // 2
    return (Position(half - 1, half - 1), Position(half, half - 1), Position(half - 1, half), Position(half, half))


def is_shed_adjacent(position: Position, board_size: int) -> bool:
    return position in shed_access_positions(board_size)


def move(position: Position, operation: str, board_size: int) -> Position | None:
    if operation not in MOVES:
        return None
    dx, dy = MOVES[operation]
    target = Position(position.x + dx, position.y + dy)
    return target if target.on_board(board_size) else None

