from __future__ import annotations

from kag_agent.rules.constants import ANIMALS, CROPS
from copy import deepcopy


def crop_harvestable(tile: dict, day: int) -> bool:
    return tile.get("kind") == "PLANT" and tile.get("yield_units", 0) > 0 and day - tile["planted_day"] >= CROPS[tile["crop"]]["first_yield_day"]


def crop_water_is_useful(tile: dict, day: int) -> bool:
    if tile.get("kind") != "PLANT" or tile.get("watered_today"):
        return False
    spec = CROPS[tile["crop"]]
    if spec["ongoing"]:
        return True
    age = day - tile["planted_day"]
    return (spec["max_yield_day"] + 1) // 2 <= age <= spec["max_yield_day"]


def crop_dies_without_water(tile: dict) -> bool:
    return tile.get("kind") == "PLANT" and not tile.get("watered_today", False) and int(tile.get("consecutive_unwatered", 0)) >= 1


def animal_escapes_without_feed(tile: dict) -> bool:
    return "animal" in tile and not tile.get("fed_today", False) and int(tile.get("consecutive_unfed", 0)) >= 1


def last_profitable_plant_turn(crop: str, episode_steps: int, turns_per_day: int) -> int:
    return max(-1, episode_steps - 1 - CROPS[crop]["first_yield_day"] * turns_per_day)


def refresh_plant(tile: dict, current_day: int, turns_per_day: int) -> dict:
    """Project the official end-of-day refresh for one plant exactly."""
    value = deepcopy(tile)
    watered = bool(value["watered_today"])
    value["consecutive_unwatered"] = 0 if watered else int(value["consecutive_unwatered"]) + 1
    value["watered_today"] = False
    if value["consecutive_unwatered"] >= 2:
        return {"kind": "WEED"}
    spec = CROPS[value["crop"]]
    if not spec["ongoing"]:
        return value
    next_day = current_day + 1
    since_first = next_day - value["planted_day"] - spec["first_yield_day"]
    if since_first < 0 or since_first % spec["interval"]:
        return value
    production_count = since_first // spec["interval"] + 1
    if production_count > spec["max_yield"]:
        return value
    fertilized = watered and value.get("fertilized_until_day", -1) >= current_day
    value["yield_units"] = min(spec["max_yield"], value["yield_units"] + (2 if fertilized else 1))
    if production_count == spec["max_yield"]:
        value["max_lifespan_step"] = (next_day + 1) * turns_per_day
    return value


def decay_plant(tile: dict, step: int) -> dict:
    value = deepcopy(tile)
    lifespan = int(value["max_lifespan_step"])
    if lifespan < 0 or step < lifespan or (step - lifespan) % 2:
        return value
    value["yield_units"] -= 1
    return {"kind": "WEED"} if value["yield_units"] <= 0 else value


def refresh_animal(tile: dict, day: int) -> dict:
    """Project the official end-of-day refresh for one placed animal exactly."""
    value = deepcopy(tile)
    value["consecutive_unfed"] = 0 if value["fed_today"] else int(value["consecutive_unfed"]) + 1
    if value["consecutive_unfed"] >= 2:
        return {"kind": ANIMALS[value["animal"]]["structure"]}
    spec = ANIMALS[value["animal"]]
    next_day = day + 1
    since_first = next_day - value["placed_day"] - spec["first_yield_day"]
    if since_first >= 0 and since_first % spec["interval"] == 0:
        bonus = value.pop("pending_care_bonus", 0) if value["fed_today"] else 0
        value["yield_units"] = min(spec["max_held"], value["yield_units"] + 1 + bonus)
        value["pending_care_bonus"] = 0
    if value["cared_today"] and value["fed_today"]:
        value["pending_care_bonus"] = value.get("pending_care_bonus", 0) + 1
    value["fertilizer_available"] = True
    value["fed_today"] = False
    value["cared_today"] = False
    return value
