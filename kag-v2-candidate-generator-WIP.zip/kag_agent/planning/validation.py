from __future__ import annotations

from kag_agent.domain.actions import ActionEnvelope, MarketOp, MarketOrder, UnitAction, UnitOp, ValidationResult, pass_envelope
from kag_agent.domain.observation import NormalizedObservation
from kag_agent.rules.constants import ANIMALS, CROPS, PRODUCTS
from kag_agent.rules.legality import legal_unit_ops


NO_OPERAND_UNIT = {UnitOp.NORTH, UnitOp.SOUTH, UnitOp.EAST, UnitOp.WEST, UnitOp.PASS, UnitOp.WATER, UnitOp.HARVEST, UnitOp.FERTILIZE, UnitOp.FEED, UnitOp.COLLECT_FERTILIZER, UnitOp.CARE, UnitOp.BUILD_COOP, UnitOp.BUILD_PASTURE, UnitOp.DIG, UnitOp.DROP}
QUANTITY_MARKET = {MarketOp.BUY_SEED, MarketOp.BUY_PRODUCT, MarketOp.BUY_ANIMAL, MarketOp.SELL}


def validate(envelope: ActionEnvelope, observation: NormalizedObservation, check_legality: bool = True) -> ValidationResult:
    reasons = []
    if len(envelope.hands) != len(observation.our_farm.hands): reasons.append("hand_count")
    if len(envelope.market) > observation.config.max_market_orders_per_turn: reasons.append("market_limit")
    units = (observation.our_farm.farmer, *observation.our_farm.hands)
    actions = (envelope.farmer, *envelope.hands)
    plant_counts = {}
    for index, action in enumerate(actions):
        if action.op in NO_OPERAND_UNIT and (action.item is not None or action.quantity is not None): reasons.append(f"unit_operand:{index}")
        if action.op in {UnitOp.PLANT, UnitOp.PICKUP, UnitOp.PLACE} and action.item is None: reasons.append(f"unit_missing_item:{index}")
        if action.quantity is not None and action.quantity <= 0: reasons.append(f"unit_quantity:{index}")
        if check_legality and action.op not in legal_unit_ops(observation, units[index]): reasons.append(f"unit_illegal:{index}:{action.op}")
        if action.op == UnitOp.PLANT:
            plant_counts[action.item] = plant_counts.get(action.item, 0) + 1
    for crop, count in plant_counts.items():
        if crop not in CROPS or count > observation.private.seeds.get(crop, 0): reasons.append(f"seed_conflict:{crop}")
    for index, order in enumerate(envelope.market):
        if order.op in QUANTITY_MARKET and (order.item is None or not isinstance(order.quantity, int) or order.quantity <= 0): reasons.append(f"market_operand:{index}")
        if order.op in {MarketOp.HIRE, MarketOp.BUY_LAND} and (order.item is not None or order.quantity is not None): reasons.append(f"market_forbidden_operand:{index}")
        if order.op == MarketOp.BUY_SEED and order.item not in CROPS: reasons.append(f"market_item:{index}")
        if order.op == MarketOp.BUY_ANIMAL and order.item not in ANIMALS: reasons.append(f"market_item:{index}")
        if order.op == MarketOp.BUY_PRODUCT and order.item not in {"WHEAT", "FERTILIZER"}: reasons.append(f"market_item:{index}")
        if order.op == MarketOp.SELL and order.item not in PRODUCTS: reasons.append(f"market_item:{index}")
    return ValidationResult(not reasons, tuple(reasons))


def maintenance_fallback(observation: NormalizedObservation) -> ActionEnvelope:
    actions = []
    for unit in (observation.our_farm.farmer, *observation.our_farm.hands):
        tile = observation.our_farm.tiles[unit.position.y][unit.position.x]
        if tile.kind == "PLANT" and not tile.data.get("watered_today") and int(tile.data.get("consecutive_unwatered", 0)) >= 1:
            actions.append(UnitAction(UnitOp.WATER))
        elif "animal" in tile.data and not tile.data.get("fed_today") and int(tile.data.get("consecutive_unfed", 0)) >= 1 and (unit.inventory or {}).get("WHEAT", 0) > 0:
            actions.append(UnitAction(UnitOp.FEED))
        else:
            actions.append(UnitAction(UnitOp.PASS))
    market = tuple(
        MarketOrder(MarketOp.SELL, item, int(quantity))
        for item, quantity in sorted(observation.private.shed.items()) if item in PRODUCTS and int(quantity) > 0
    )[:observation.config.max_market_orders_per_turn]
    return ActionEnvelope(actions[0], tuple(actions[1:]), market)


def serialize(envelope: ActionEnvelope) -> dict[str, list]:
    def unit(action):
        value = [action.op.value]
        if action.item is not None: value.append(action.item)
        if action.quantity is not None: value.append(action.quantity)
        return value
    def market(order):
        value = [order.op.value]
        if order.item is not None: value.append(order.item)
        if order.quantity is not None: value.append(order.quantity)
        return value
    return {"farmer": unit(envelope.farmer), "hands": [unit(item) for item in envelope.hands], "market": [market(item) for item in envelope.market]}
