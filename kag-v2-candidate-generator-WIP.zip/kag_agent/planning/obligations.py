from __future__ import annotations

from kag_agent.domain.planning import Obligation, ObligationKind
from kag_agent.rules.lifecycle import animal_escapes_without_feed, crop_dies_without_water, crop_harvestable, crop_water_is_useful
from kag_agent.state.derive import DerivedGameState


def asset_id(player: int, x: int, y: int, kind: str, created_turn: int = 0) -> str:
    return f"p{player}/tile-{x}-{y}/created-{created_turn}/{kind}"


def build_obligations(state: DerivedGameState) -> tuple[Obligation, ...]:
    observation = state.observation
    end_of_day = observation.turn + (observation.config.turns_per_day - observation.hour - 1)
    obligations = []
    for row in observation.our_farm.tiles:
        for tile in row:
            data = tile.data
            source = asset_id(observation.player_id, tile.position.x, tile.position.y, tile.kind, int(data.get("planted_day", data.get("placed_day", 0))) * observation.config.turns_per_day)
            hard = tile.kind == "PLANT" and crop_dies_without_water(data)
            if tile.kind == "PLANT" and not data.get("watered_today") and (hard or crop_water_is_useful(data, observation.day)):
                obligations.append(Obligation(f"{source}/WATER/deadline-{end_of_day}", ObligationKind.WATER, tile.position, observation.turn, end_of_day, 1, max(1, int(data.get("yield_units", 0))), 1, (), hard, source))
            if tile.kind == "PLANT" and crop_harvestable(data, observation.day):
                deadline = min(observation.config.episode_steps - 2, int(data.get("max_lifespan_step", observation.config.episode_steps - 2)))
                obligations.append(Obligation(f"{source}/HARVEST/deadline-{deadline}", ObligationKind.HARVEST, tile.position, observation.turn, deadline, 1, int(data.get("yield_units", 0)), int(data.get("yield_units", 0)), (), deadline - observation.turn <= observation.config.turns_per_day, source))
            if "animal" in data and animal_escapes_without_feed(data):
                obligations.append(Obligation(f"{source}/FEED/deadline-{end_of_day}", ObligationKind.FEED, tile.position, observation.turn, end_of_day, 1, 1, 0, (), True, source))
            if "animal" in data and int(data.get("yield_units", 0)) > 0:
                obligations.append(Obligation(f"{source}/HARVEST/deadline-{observation.config.episode_steps - 2}", ObligationKind.HARVEST, tile.position, observation.turn, observation.config.episode_steps - 2, 1, int(data["yield_units"]), int(data["yield_units"]), (), False, source))
    if any(value > 0 for value in observation.private.shed.values()):
        deadline = observation.config.episode_steps - 2
        obligations.append(Obligation(f"p{observation.player_id}/shed/LIQUIDATE/deadline-{deadline}", ObligationKind.LIQUIDATE, "MARKET", observation.turn, deadline, 0, sum(observation.private.shed.values()), sum(observation.private.shed.values()), (), observation.turn >= deadline - 1, None))
    return tuple(sorted(obligations, key=lambda item: (not item.hard, item.deadline_turn, -item.failure_terminal_value, item.obligation_id)))
