from __future__ import annotations


from kag_agent.domain.actions import ActionEnvelope, MarketOrder, MarketOp, UnitAction, UnitOp, pass_envelope
from kag_agent.domain.planning import Obligation, ObligationKind, PlannedTask, ScheduleResult
from kag_agent.domain.state import UnitState
from kag_agent.planning.routing import next_move
from kag_agent.rules.legality import legal_unit_ops
from kag_agent.state.derive import DerivedGameState


KIND_TO_OP = {ObligationKind.WATER: UnitOp.WATER, ObligationKind.FEED: UnitOp.FEED, ObligationKind.HARVEST: UnitOp.HARVEST, ObligationKind.COLLECT_FERTILIZER: UnitOp.COLLECT_FERTILIZER}


def _can_perform(unit: UnitState, operation: UnitOp) -> bool:
    """Carry prerequisites the target tile cannot express.

    FEED consumes one WHEAT from the acting unit's inventory. Dispatching a
    unit with no wheat produces a silent no-op, and the animal then escapes on
    its second unfed day, so the requirement is enforced at assignment time.
    """
    if operation is UnitOp.FEED:
        return int((unit.inventory or {}).get("WHEAT", 0)) > 0
    return True


def _action_for_target(state: DerivedGameState, unit: UnitState, target, operation: UnitOp, item: str | None = None, quantity: int | None = None) -> UnitAction:
    if unit.position == target and operation in legal_unit_ops(state.observation, unit):
        return UnitAction(operation, item, quantity)
    movement = next_move(unit.position, target, state.observation.config.board_size)
    return UnitAction(movement) if movement is not None else UnitAction(UnitOp.PASS)


def schedule(state: DerivedGameState, obligations: tuple[Obligation, ...], policy_tasks: tuple[PlannedTask, ...]) -> ScheduleResult:
    units = (state.observation.our_farm.farmer, *state.observation.our_farm.hands)
    actions = [UnitAction(UnitOp.PASS) for _ in units]
    completed = []; deferred = []; used_targets = set()
    candidates = []
    for obligation in obligations:
        if obligation.kind in KIND_TO_OP and not isinstance(obligation.target, str):
            affinity = units[(obligation.target.y * state.observation.config.board_size + obligation.target.x) % len(units)].unit_id if len(units) > 1 else None
            candidates.append((0 if obligation.hard else 1, obligation.deadline_turn, -obligation.failure_terminal_value, obligation.obligation_id, obligation.target, KIND_TO_OP[obligation.kind], None, affinity, None))
    for task in policy_tasks:
        if isinstance(task.operation, UnitOp) and not isinstance(task.target, str):
            candidates.append((2, task.deadline_turn, -task.expected_terminal_value, task.task_id, task.target, task.operation, task.item, task.unit_id, task.quantity))
    candidates = [item if len(item) == 9 else (*item, None, None) for item in candidates]
    candidates.sort(key=lambda item: item[:4])
    unassigned = set(range(len(units)))
    remaining = list(candidates)
    while remaining and unassigned:
        rank = remaining[0][:3]
        duplicates = [candidate for candidate in remaining if candidate[:3] == rank and candidate[4] in used_targets]
        deferred.extend(candidate[3] for candidate in duplicates)
        remaining = [candidate for candidate in remaining if candidate not in duplicates]
        group = [candidate for candidate in remaining if candidate[:3] == rank and candidate[4] not in used_targets]
        if not group:
            remaining = [candidate for candidate in remaining if candidate[:3] != rank]
            continue
        pairs = []
        for candidate in group:
            required_unit_id = candidate[7]
            for index in unassigned:
                if required_unit_id is not None and units[index].unit_id != required_unit_id:
                    continue
                if not _can_perform(units[index], candidate[5]):
                    continue
                pairs.append((units[index].position.manhattan(candidate[4]), candidate[3], units[index].unit_id, candidate, index))
        if not pairs:
            deferred.extend(candidate[3] for candidate in group)
            remaining = [candidate for candidate in remaining if candidate not in group]
            continue
        _, task_id, _, candidate, index = min(pairs, key=lambda value: value[:3])
        _, _, _, _, target, operation, item, _, quantity = candidate
        actions[index] = _action_for_target(state, units[index], target, operation, item, quantity)
        unassigned.remove(index); used_targets.add(target); remaining.remove(candidate)
        (completed if units[index].position == target else deferred).append(task_id)
    deferred.extend(candidate[3] for candidate in remaining if candidate[3] not in deferred)
    farmer = actions[0]
    hands = tuple(actions[1:])
    return ScheduleResult(ActionEnvelope(farmer, hands, ()), tuple(completed), tuple(deferred))
