from __future__ import annotations

from dataclasses import dataclass

from kag_agent.config import fingerprint
from kag_agent.domain.actions import MarketOrder, MarketOp, UnitOp
from kag_agent.domain.planning import PlannedTask
from kag_agent.rules.constants import ANIMALS, CROPS, LAND_PRICES, PRODUCTS
from kag_agent.rules.lifecycle import crop_harvestable, crop_water_is_useful, last_profitable_plant_turn
from kag_agent.state.derive import DerivedGameState
from kag_agent.planning.routing import nearest_shed_access
from kag_agent.economics.evaluator import EconomicPolicy, evaluate_policies, select_best
from kag_agent.economics.scenarios import broad_scenarios
from kag_agent.economics.depth import sellable_units
from kag_agent.economics.portfolio import candidate_portfolios, select_robust_portfolio

# Sell without pacing once the shed is this full, because the end-of-day
# inventory drop discards anything past `shedCapacity`.
SHED_PRESSURE_RATIO = 0.75
# Buy the next quadrant once this share of usable tiles is already committed.
LAND_COMMIT_RATIO = 0.80


@dataclass(frozen=True, slots=True)
class PolicyIntent:
    policy_id: str
    phase: str
    crop: str
    reserve_cash: int
    forecast_terminal_cash: int
    model_version: str = "v1-fixed-baseline"
    target_assets: int = 1
    daily_hires: int = 0
    land_purchase_limit: int = 0
    animal: str | None = None
    animal_target: int = 0
    crop_targets: tuple[tuple[str, int], ...] = ()


def select_policy(state: DerivedGameState) -> PolicyIntent:
    phase = "LIQUIDATE" if state.turns_remaining <= state.observation.config.turns_per_day else "OPERATE"
    content = {"phase": phase, "crop": "CARROT", "reserve": 100, "model": "v1-fixed-baseline"}
    return PolicyIntent(f"policy-{fingerprint(content)[:20]}", phase, "CARROT", 100, state.observation.our_farm.money)


def select_policy_v2(state: DerivedGameState) -> PolicyIntent:
    """Select a bounded, capacity-feasible crop project for the remaining horizon."""
    if state.turns_remaining <= state.observation.config.turns_per_day:
        return select_policy(state)
    obs = state.observation
    scenarios = broad_scenarios(obs.turn)
    projections = candidate_portfolios(turns_remaining=state.turns_remaining, turns_per_day=obs.config.turns_per_day, starting_cash=obs.our_farm.money, market_inventory=obs.market_inventory, scenarios=scenarios)
    try:
        chosen = select_robust_portfolio(projections)
    except ValueError:
        return select_policy(state)
    crop = chosen.crop
    content = {
        "phase": "ECONOMIC", "crop": crop, "reserve": 250, "model": "v2-economic-4",
        "scenario": "broad-lmh", "tiles": chosen.target_tiles, "land": chosen.land_purchases,
        "animal": chosen.animal, "herd": chosen.animal_count,
    }
    # The candidate set now spans crop-only, land-expanded, and crop-plus-herd
    # projections, so the selected shape is evaluated rather than hardcoded.
    return PolicyIntent(
        f"policy-{fingerprint(content)[:20]}", "OPERATE", crop, 250,
        round(chosen.expected_terminal_cash), "v2-economic-4",
        chosen.target_tiles, chosen.daily_hires, chosen.land_purchases,
        chosen.animal, chosen.animal_count, ((crop, chosen.target_tiles),),
    )


def policy_tasks(state: DerivedGameState, policy: PolicyIntent) -> tuple[PlannedTask, ...]:
    if policy.model_version.startswith("v2-"):
        return _v2_policy_tasks(state, policy)
    obs = state.observation; unit = obs.our_farm.farmer; tile = obs.our_farm.tiles[unit.position.y][unit.position.x]
    tasks = []
    if sum((unit.inventory or {}).values()) > 0:
        tasks.append(PlannedTask("drop-inventory", nearest_shed_access(unit.position, obs.config.board_size), UnitOp.DROP, None, None, obs.config.episode_steps - 2, sum((unit.inventory or {}).values()), hard=policy.phase == "LIQUIDATE"))
    elif tile.kind == "WEED":
        tasks.append(PlannedTask("dig-current", unit.position, UnitOp.DIG, None, None, obs.turn, 1))
    elif tile.kind == "EMPTY" and obs.private.seeds.get(policy.crop, 0) > 0 and obs.turn <= last_profitable_plant_turn(policy.crop, obs.config.episode_steps, obs.config.turns_per_day):
        tasks.append(PlannedTask("plant-current", unit.position, UnitOp.PLANT, policy.crop, None, obs.turn, 1))
    elif tile.kind == "PLANT":
        if crop_harvestable(tile.data, obs.day) and (obs.day - int(tile.data["planted_day"]) >= CROPS[tile.data["crop"]]["max_yield_day"] or policy.phase == "LIQUIDATE"):
            tasks.append(PlannedTask("harvest-current", unit.position, UnitOp.HARVEST, None, None, obs.turn, int(tile.data.get("yield_units", 0))))
        elif crop_water_is_useful(tile.data, obs.day):
            tasks.append(PlannedTask("water-current", unit.position, UnitOp.WATER, None, None, obs.turn + obs.config.turns_per_day - obs.hour - 1, 1))
    return tuple(tasks)


def _v2_policy_tasks(state: DerivedGameState, policy: PolicyIntent) -> tuple[PlannedTask, ...]:
    obs = state.observation
    units = (obs.our_farm.farmer, *obs.our_farm.hands)
    tasks: list[PlannedTask] = []
    animal_spec = ANIMALS.get(policy.animal) if policy.animal else None
    if animal_spec:
        structure = str(animal_spec["structure"])
        structures = [tile for row in obs.our_farm.tiles for tile in row if tile.kind == structure]
        open_structures = [tile for tile in structures if "animal" not in tile.data]
        animals = [tile for tile in structures if tile.data.get("animal") == policy.animal]
        # Placing and feeding have precedence over field expansion.
        for unit in units:
            inventory = unit.inventory or {}
            if inventory.get(policy.animal, 0) > 0 and open_structures:
                target = min(open_structures, key=lambda tile: (unit.position.manhattan(tile.position), tile.position.y, tile.position.x))
                tasks.append(PlannedTask(f"place-{policy.animal}-{unit.unit_id}", target.position, UnitOp.PLACE, policy.animal, None, obs.turn + 8, 500, unit_id=unit.unit_id))
                open_structures.remove(target)
            elif inventory.get("WHEAT", 0) > 0:
                hungry = [tile for tile in animals if not tile.data.get("fed_today")]
                if hungry:
                    target = min(hungry, key=lambda tile: (unit.position.manhattan(tile.position), tile.position.y, tile.position.x))
                    tasks.append(PlannedTask(f"feed-{target.position.x}-{target.position.y}-{unit.unit_id}", target.position, UnitOp.FEED, None, None, obs.turn + obs.config.turns_per_day - obs.hour - 1, 250, unit_id=unit.unit_id))
                    animals.remove(target)
        if tasks:
            return tuple(tasks)
        shed_animal = int(obs.private.shed.get(policy.animal, 0))
        shed_wheat = int(obs.private.shed.get("WHEAT", 0))
        for unit in units:
            target = nearest_shed_access(unit.position, obs.config.board_size)
            if shed_animal > 0 and open_structures:
                tasks.append(PlannedTask(f"pickup-{policy.animal}-{unit.unit_id}", target, UnitOp.PICKUP, policy.animal, 1, obs.turn + 8, 400, unit_id=unit.unit_id)); shed_animal -= 1
            elif shed_wheat > 0 and any(not tile.data.get("fed_today") for tile in animals):
                tasks.append(PlannedTask(f"pickup-wheat-{unit.unit_id}", target, UnitOp.PICKUP, "WHEAT", min(4, shed_wheat), obs.turn + 8, 300, unit_id=unit.unit_id)); shed_wheat -= min(4, shed_wheat)
        if tasks:
            return tuple(tasks)
    for unit in units:
        if sum((unit.inventory or {}).values()) > 0:
            target = nearest_shed_access(unit.position, obs.config.board_size)
            tasks.append(PlannedTask(f"drop-{unit.unit_id}", target, UnitOp.DROP, None, None, obs.config.episode_steps - 2, sum((unit.inventory or {}).values()), hard=policy.phase == "LIQUIDATE", unit_id=unit.unit_id))
    if tasks:
        return tuple(tasks)
    targets = dict(policy.crop_targets or ((policy.crop, policy.target_assets),))
    live_by_crop = {crop: sum(tile.kind == "PLANT" and tile.data.get("crop") == crop for row in obs.our_farm.tiles for tile in row) for crop in targets}
    available_seeds = {crop: int(obs.private.seeds.get(crop, 0)) for crop in targets}
    live_assets = sum(tile.kind in {"PLANT", "COOP", "PASTURE"} for row in obs.our_farm.tiles for tile in row)
    expansion_slots = max(0, policy.target_assets - live_assets)
    open_tiles = [tile for row in obs.our_farm.tiles for tile in row if tile.kind in {"EMPTY", "WEED"}]
    open_tiles.sort(key=lambda tile: (min(unit.position.manhattan(tile.position) for unit in units), tile.position.y, tile.position.x))
    for tile in open_tiles[:min(len(units), expansion_slots)]:
        if tile.kind == "WEED":
            tasks.append(PlannedTask(f"dig-{tile.position.x}-{tile.position.y}", tile.position, UnitOp.DIG, None, None, obs.turn, 1))
        elif animal_spec and len([value for row in obs.our_farm.tiles for value in row if value.kind == animal_spec["structure"]]) < policy.animal_target:
            operation = UnitOp.BUILD_COOP if animal_spec["structure"] == "COOP" else UnitOp.BUILD_PASTURE
            tasks.append(PlannedTask(f"build-{tile.position.x}-{tile.position.y}", tile.position, operation, None, None, obs.turn + 8, 300))
        else:
            choices = [crop for crop, target in targets.items() if live_by_crop[crop] < target and available_seeds[crop] > 0 and obs.turn <= last_profitable_plant_turn(crop, obs.config.episode_steps, obs.config.turns_per_day)]
            if choices:
                crop = max(choices, key=lambda value: (targets[value] - live_by_crop[value], value))
                tasks.append(PlannedTask(f"plant-{tile.position.x}-{tile.position.y}", tile.position, UnitOp.PLANT, crop, None, obs.turn, 1))
                available_seeds[crop] -= 1; live_by_crop[crop] += 1
    return tuple(tasks)


def _sell_orders(state: DerivedGameState, policy: PolicyIntent) -> list[MarketOrder]:
    """Pace sales against market depth instead of dumping the shed every turn.

    Town consumption is the only inventory sink and both players share it, so a
    unit sold below the price floor is worth more held for a later turn. Two
    conditions override pacing: terminal liquidation, and shed pressure, where
    an unsold unit risks being discarded at the daily inventory drop.
    """
    obs = state.observation
    held = {item: int(obs.private.shed.get(item, 0)) for item in PRODUCTS}
    held = {item: quantity for item, quantity in held.items() if quantity > 0}
    if not held:
        return []
    total_held = sum(held.values())
    liquidating = policy.phase == "LIQUIDATE" or state.turns_remaining <= obs.config.turns_per_day
    pressured = total_held >= SHED_PRESSURE_RATIO * obs.config.shed_capacity
    orders = []
    for item, quantity in sorted(held.items(), key=lambda pair: -pair[1]):
        if liquidating or pressured:
            allowed = quantity
        else:
            allowed = sellable_units(item, int(obs.market_inventory.get(item, 0)), quantity)
        if allowed > 0:
            orders.append(MarketOrder(MarketOp.SELL, item, allowed))
    return orders


def market_orders(state: DerivedGameState, policy: PolicyIntent) -> tuple[MarketOrder, ...]:
    obs = state.observation; orders = []
    # Hiring is contested for market-order slots and a full crew costs about $54
    # for the day, so it is queued before discretionary sales and purchases.
    if policy.model_version.startswith("v2-") and obs.hour == 0 and policy.daily_hires > 0:
        hire_costs = (1, 1, 2, 3, 5, 8, 13, 21)
        affordable = min(policy.daily_hires, len(hire_costs))
        while affordable > 0 and obs.our_farm.money <= sum(hire_costs[:affordable]):
            affordable -= 1
        orders.extend(MarketOrder(MarketOp.HIRE) for _ in range(affordable))
    orders.extend(_sell_orders(state, policy))
    if policy.animal:
        animal_count = sum(tile.data.get("animal") == policy.animal for row in obs.our_farm.tiles for tile in row)
        held_animals = int(obs.private.shed.get(policy.animal, 0)) + sum(int((unit.inventory or {}).get(policy.animal, 0)) for unit in (obs.our_farm.farmer, *obs.our_farm.hands))
        missing = max(0, policy.animal_target - animal_count - held_animals)
        animal_cost = int(ANIMALS[policy.animal]["cost"])
        affordable_animals = max(0, (obs.our_farm.money - policy.reserve_cash) // animal_cost)
        if missing and affordable_animals:
            orders.append(MarketOrder(MarketOp.BUY_ANIMAL, policy.animal, min(missing, affordable_animals)))
        wheat_need = max(0, animal_count * 2 - int(obs.private.shed.get("WHEAT", 0)) - sum(int((unit.inventory or {}).get("WHEAT", 0)) for unit in (obs.our_farm.farmer, *obs.our_farm.hands)))
        if wheat_need and obs.our_farm.money > policy.reserve_cash + wheat_need * int(obs.market_prices.get("WHEAT", 25)):
            orders.append(MarketOrder(MarketOp.BUY_PRODUCT, "WHEAT", wheat_need))
    if policy.phase == "OPERATE":
        live_assets = sum(tile.kind in {"PLANT", "COOP", "PASTURE"} for row in obs.our_farm.tiles for tile in row)
        cash_after_seeds = obs.our_farm.money
        for crop, target in (policy.crop_targets or ((policy.crop, policy.target_assets),)):
            if obs.turn > last_profitable_plant_turn(crop, obs.config.episode_steps, obs.config.turns_per_day): continue
            live_crop = sum(tile.kind == "PLANT" and tile.data.get("crop") == crop for row in obs.our_farm.tiles for tile in row)
            desired = max(0, target - live_crop - int(obs.private.seeds.get(crop, 0))); seed_cost = int(CROPS[crop]["seed"]); affordable = max(0, (cash_after_seeds - policy.reserve_cash) // seed_cost)
            if desired > 0 and affordable > 0:
                quantity = min(desired, affordable); orders.append(MarketOrder(MarketOp.BUY_SEED, crop, quantity)); cash_after_seeds -= quantity * seed_cost
        # Hiring is queued ahead of sales at the top of this function.
        # Land is bought once the unlocked field is nearly committed and the
        # next quadrant is affordable, rather than on a fixed asset count.
        usable_tiles = sum(tile.kind != "LOCKED" for row in obs.our_farm.tiles for tile in row)
        next_land_price = LAND_PRICES[min(len(obs.our_farm.unlocked_quadrants) - 1, len(LAND_PRICES) - 1)]
        wants_more_room = policy.target_assets + policy.animal_target > usable_tiles
        if (policy.model_version.startswith("v2-") and policy.land_purchase_limit > 0
                and len(obs.our_farm.unlocked_quadrants) - 1 < policy.land_purchase_limit
                and wants_more_room and live_assets >= LAND_COMMIT_RATIO * usable_tiles
                and obs.our_farm.money > policy.reserve_cash + next_land_price):
            orders.append(MarketOrder(MarketOp.BUY_LAND))
    return tuple(orders[:obs.config.max_market_orders_per_turn])
