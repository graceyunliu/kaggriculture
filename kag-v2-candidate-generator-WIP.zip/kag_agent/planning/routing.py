from __future__ import annotations

from collections import deque

from kag_agent.domain.actions import UnitOp
from kag_agent.domain.state import Position
from kag_agent.rules.geometry import MOVES, shed_access_positions


ORDER = (UnitOp.NORTH, UnitOp.EAST, UnitOp.SOUTH, UnitOp.WEST)


def distance(start: Position, target: Position) -> int:
    return start.manhattan(target)


def next_move(start: Position, target: Position, board_size: int) -> UnitOp | None:
    if start == target:
        return None
    for op in ORDER:
        dx, dy = MOVES[op.value]
        candidate = Position(start.x + dx, start.y + dy)
        if candidate.on_board(board_size) and candidate.manhattan(target) < start.manhattan(target):
            return op
    return None


def nearest_shed_access(start: Position, board_size: int) -> Position:
    return min(shed_access_positions(board_size), key=lambda target: (distance(start, target), target.y, target.x))

