# O33_FERT_DENIAL4: O26 with the daily opportunistic fertilizer buy cap raised 3 -> 4.
# Removing these purchases hurt both own money and opponent suppression; this tests
# the smallest increase in the locally supported direction.
# O26_CARROT_SIZING: O25_STRAW_HIREGATE with the seed allocator's carrot yield assumption corrected 4.0 -> 3.0 units/planting (measured 3.0 on both farms). Effect: carrots mostly drop out of the plan (34 -> 12 plantings), the freed labour goes to wheat (64 -> 90 plantings, wheat purchases 260 -> 203), labour+land 11.3k -> 8.5k. Fixed shops vs O25: own +1.6k/+1.4k (t2.6/4.6), margin +0.8k/+0.2k/+1.5k (real tapes >= 0 on all three seed sets, clone negative). Wheat units 5.0 -> 3.9 (true) is -2k own: do not apply.
# O25_STRAW_HIREGATE: O24_STRAW_SIZING + H_GATE144 (refuse hires priced above 144 on the daily fibonacci curve; other session's confirmed +1.3k own gain on O16).
# O24_STRAW_SIZING: O22_MELON_MORNING with the seed allocator's strawberry yield assumption corrected from 4.5 to 7.5 units per planting (tools/allocation_matrix.py: tapes get 7.5 u/planting from 33 plantings; O16 planted 47 for the same ~250 units). Fewer plantings -> less seed, less labour, higher realised strawberry price. Own-money panel vs O22 +4.7-5.5k (t8-10); 9.0 +3.3k, 12.0 +1.7k, 20.0 -0.9k.
# O22_MELON_MORNING: O16_ORCH_ON_O15 + melon late-fert (O20: fertilize MELON at age 7-8 -> 6 units by age 9-10) + melon morning: on days 9-14 until h8, units not on an animal route harvest ready (6-unit) melon tiles first and carry them straight to the shed, so the crop sells into the fresh day-10 melon price pool ahead of the tapes' 60-unit dump (tapes realise $231/melon, O16 $171; tools/sale_timeline.py).
# Fixed shops vs O16, 4 tapes + clone: margin +1,233 (t3.4, s11-30) / +899 (t2.4, s31-50) / +2,502 (t6.5, s51-70); OWN money +372 (t1.0) / +1,258 (t3.2) / +1,798 (t4.2). h12 or harvest-at-5-units variants: null/negative (displace animal routes).
# O20_MELON_FIRST: O16_ORCH_ON_O15 + melon late-fert (B4_01 patch) so all melons reach 6 units by age 9-10 and sell on day 10 at the top of the melon price curve (tools/sale_timeline.py: tapes realise $231/melon, O16 $171 because 30+ units sit in hands until the nightly auto-drop and sell at the d11 h0 dump).
# O16_ORCH_ON_O15: O15_SALE_PRIORITY.py + X1 global crop orchestrator (per-turn cost matrix over free units x open crop tasks, flat priorities, commitment bonus 0.75).
# O15_SALE_PRIORITY: O12 plus state-based scheduling of existing SELL orders.
# Sale priority = approximate local price sensitivity * batch quantity squared.
# No recorded opponent turns or opponent identity rules.
# O12_EVENING_DEPOSIT (was briefly named O10; renamed because O10_O9_MELON_LATEFERT exists): O9 + evening deposit (idle units from h18, ALL units carrying >=3 from h20) with same-turn sells.
# ---- O9 header follows ----
# O9_O8_ENDGAME: O8_PURE_ANIMAL_THROTTLE (the Sep 9 frontier: O4 + animal_claim throttle <4 / <2)
#   + the O5 end-of-game conversion fixes below. Diff vs O8 = exactly the O5 changes; diff vs O5 = the
#   two animal_claim threshold numbers. Built to check the endgame gain ports onto the new frontier.
# ---- O5_ENDGAME header follows ----
# O5_ENDGAME: O4 + end-of-game conversion fixes (Sep 9). Diff against O4_PRODUCTIVE_SERVICE.py.
#   1. Same-turn deposit sells: unit actions are dispatched BEFORE the market orders are built, and
#      product a unit DROPs this turn is added to the sellable shed count. The engine applies unit
#      actions before _process_market, so the SELL lands the same turn. O4 sold from the previous
#      turn's shed snapshot, so goods dropped at the final acting hour (day 29 h22) were never sold.
#   2. Deadline return: on day 29 any unit carrying >=1 unit of product heads home when
#      hour + shed_dist >= 22 and DROPs on arrival (game's last processed action is day 29 h22;
#      the end-of-day auto-drop never runs on day 29, so carried cargo is worth $0).
#   3. Final-day work filter: on day 29 only work that can still turn into money is scheduled --
#      HARVEST (and WATER of a non-ongoing crop inside its yield window, which raises yield_units
#      immediately) -- and only if the unit can do it and still reach the shed by h22. Planting,
#      digging, fertilizing and watering ongoing crops are dead on day 29 (their payoff is at an
#      end-of-day refresh that never happens).
# Everything else is byte-identical to O4.
# O4: original live-state productive-service research candidate.
# Shared stock accounting; production-aware husbandry; event-triggered reinvestment.
# No recorded action schedule or opponent identity switch.
# evolve/chassis.py -- frozen copy of candidates/K.py with typed mutation blocks.
# source sha256 c38b582a1380. Rebuild: python3 evolve/blocks.py build
"""K — knob-parameterized V3.12 chassis for discovery search (Sep 2026).

Identical to candidates/V3_12.py except every mutation surface is a KNOBS entry, so
variants are generated by rewriting the KNOBS line only (see gen_variants.py).

Knobs (default = V3.12 behaviour):
  melon_floor   150   sell MELON only at/above this price (0 = sell on arrival)
  harvest_min   2     ongoing crops: harvest when yield_units >= this (1 = every yield)
  opening       "v312" | "frontier"   day-0 orders (frontier = 2c/2s/12 melon/7 wheat/5 hires/5 feed)
  wheat_tiles   0     keep this many WHEAT tiles planted (seeds+plants) through day 24
  wheat_stock   0     hold this much WHEAT in the shed above feed needs until day 27 (sell later, higher)
  min_hands     3
  load_per_hand 20
  geese         0     GOOSE to buy on day 1 (EGG income) — 0 disables
"""
import math
import sys

KNOBS = {'melon_floor': 0, 'harvest_min': 1, 'opening': 'frontier', 'wheat_tiles': 0, 'wheat_stock': 0, 'min_hands': 3, 'load_per_hand': 20, 'geese': 0, 'open_melons': 10, 'open_wheat': 7, 'open_cows': 2, 'open_sheep': 2, 'early_hire_days': 3, 'feed_spare_poor': 0, 'fert_keep': 0, 'fert_buy': 4, 'fert_carry': 2, 'demand_share': 0.55, 'max_animals': 17, 'wheat_per_animal': 0.0, 'wheat_cap': 22, 'wheat_water_tier': 0, 'wheat_sell_price': 30, 'wheat_hold_days': 0, 'sell_hourly': 0, 'drop_min': 0, 'drop_radius': 0, 'capital_hour2': -1, 'melon_rush': 0, 'straw_delay': 0, 'hands_early': 0, 'setup_capital_share': 0.25, 'labor_reserve_buffer': 92}
# ---- O5 end-of-game knobs
EG = {"same_turn_sell": 3,   # 2 = day 29 only (default), 1 = all game (tested: wash, see header), 0 = off (O4 behaviour)
      "deadline_return": 1,  # day-29 go-home-by-h22 rule for any carried product
      "work_filter": 1,      # day-29 dead-work filter + return-feasibility check
      "evening_deposit": 18,
      "evening_force": 20,    # O10b: from this hour ALL units (not just idle ones) carrying >= evening_force_min head home (0 = off)
      "evening_force_min": 3,  # O10: from this hour, an IDLE unit carrying product walks to the shed and DROPs (0 = off)
      "all_shed_tiles": 0,   # 1 = route shed trips to any of the 4 access tiles, not just unlocked ones
      "last_hour": 22}       # last hour whose actions the engine processes (episodeSteps 720 -> DONE at step 718)

BOARD = 10
SHED_TILES = [(4, 4), (5, 4), (4, 5), (5, 5)]
CROPS = {
    "WHEAT":      {"seed": 10,  "first": 2,  "max_day": 4,  "interval": 0, "max_yield": 6, "ongoing": False},
    "CARROT":     {"seed": 20,  "first": 2,  "max_day": 3,  "interval": 0, "max_yield": 4, "ongoing": False},
    "TOMATO":     {"seed": 50,  "first": 8,  "max_day": 8,  "interval": 1, "max_yield": 4, "ongoing": True},
    "STRAWBERRY": {"seed": 100, "first": 10, "max_day": 10, "interval": 2, "max_yield": 4, "ongoing": True},
    "MELON":      {"seed": 80,  "first": 10, "max_day": 12, "interval": 0, "max_yield": 6, "ongoing": False},
}
ANIMALS = {"COW": 400, "SHEEP": 500, "GOOSE": 300}
PRODUCTS = ["MILK", "WOOL", "STRAWBERRY", "FERTILIZER", "MELON", "TOMATO", "CARROT", "EGG", "WHEAT"]
LAND_PRICES = [1000, 2000, 4000]
LAND_DEADLINE = {2: 14, 3: 17, 4: 18}      # quads-after-purchase -> last day
MAX_ORDERS = 10

MAX_ANIMALS = 20
MAX_SHEEP = 14
I0 = 10000
SHOPS = {"BAKERY": ["EGG", "WHEAT"], "PIZZA_SHOP": ["MILK", "TOMATO", "WHEAT"], "BRUNCH_SPOT": ["EGG", "WHEAT", "STRAWBERRY"],
         "YARN_STORE": ["WOOL"], "ICE_CREAM_SHOP": ["STRAWBERRY", "MILK", "WHEAT"], "PET_CAFE": ["CARROT"],
         "SMOOTHIE_SHOP": ["STRAWBERRY", "MILK"], "FARMERS_MARKET": ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY"]}
PRODUCT_OF = {"COW": "MILK", "SHEEP": "WOOL"}
RATE = {"COW": 1.5, "SHEEP": 1.33}           # units/day with daily FEED+CARE (engine: bonus accrues per cared day)
FIRST_YIELD = {"COW": 8, "SHEEP": 6}
DEMAND_SHARE = 0.5                            # my share of daily town demand (two sellers)
OPP_GROWTH = 1.4# opponent's visible supply is assumed to grow
CFG = {"center_interval": 24, "shop_interval": 4, "turns_per_day": 24}
MAX_HANDS = 14
LOAD_ANIMAL, LOAD_CROP_TASK, LOAD_SETUP = 6, 3, 8
ROUTE_LEN = 3
CROP_SWEEP_LEN = 6
CROP_SWEEP_RADIUS = 5
FERT_RADIUS = 3
SPREAD_W = 1.25
SPREAD_CAP = 3
STRAW_CUTOFF = 19
MELON_WAVE_DAYS = ((1, 10),)
MELON_MAX_TILES = 38
MELON_UNITS_PER_TILE = 6.0
MELON_PRICE_CUSHION = 100
OPENING_MELONS = 14
STRAW_UNITS = 7.5   # O24: expected sellable units per strawberry planting used by the seed allocator (was 4.5; measured 5.5-7.5 -> the farm over-planted strawberries by ~40%)
CROP_SPECS = {
    "STRAWBERRY": {"seed": 100, "units": STRAW_UNITS, "first": 10, "cycle": 18, "cutoff": 17, "base": 120, "min_val": 12},
    "MELON":      {"seed": 80,  "units": 6.0, "first": 10, "cycle": 12, "cutoff": 16, "base": 250, "min_val": 12, "cushion": 100},
    "WHEAT":      {"seed": 10,  "units": 5.0, "first": 2,  "cycle": 5,  "cutoff": 24, "base": 25,  "min_val": 12},
    "CARROT":     {"seed": 20,  "units": 3.0, "first": 2,  "cycle": 4,  "cutoff": 25, "base": 35,  "min_val": 12},
    "TOMATO":     {"seed": 50,  "units": 5.0, "first": 8,  "cycle": 12, "cutoff": 20, "base": 60,  "min_val": 12},
}     # units above I0 before MELON drops from $250 toward $150 (sq curve)
HERD_LAST_DAY = 17
NEAR_RADIUS = 2

# ---- per-episode state (hands are re-indexed daily; everything below is reset at day change)
S = {"day": -1, "routes": {}, "crop": {}, "sweep": {}, "setup": {}, "claimed_sites": set(), "animal_claim": set(),
     "hires_target": 0, "wheat_budget": 0}


def _fib(n):
    a, b = 1, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def _dist(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def _step(pos, tgt):
    x, y = pos
    tx, ty = tgt
    if x < tx: return "EAST"
    if x > tx: return "WEST"
    if y < ty: return "SOUTH"
    if y > ty: return "NORTH"
    return None


def _shed_dist(pos):
    return min(_dist(pos, t) for t in SHED_TILES)


def _home_dist(pos, sheds):
    """Distance to the nearest shed-access tile the dispatcher actually routes to."""
    return min(_dist(pos, t) for t in sheds) if sheds else _shed_dist(pos)


def _day29_task_ok(tp, kind, t, day):
    """O5 final-day work filter: can this tile task still turn into money on day 29?"""
    if kind == "harvest":
        return True
    if kind in ("urgent", "water", "wwater", "slack"):
        c = CROPS.get(t.get("crop")) if isinstance(t, dict) else None
        if not c or c["ongoing"]:
            return False          # ongoing-crop yield accrues at an end-of-day refresh that never comes
        age = day - t.get("planted_day", day)
        ws = (c["max_day"] + 1) // 2
        return ws <= age <= c["max_day"] and t.get("yield_units", 0) < c["max_yield"]  # WATER raises yield now
    return False                  # plant / weeds / fert: payoff is after the game ends


def _water_needed(t, day):
    cu = t.get("consecutive_unwatered", 0)
    if cu >= 1:
        return "urgent"
    c = CROPS.get(t.get("crop"))
    if not c:
        return None
    pd = t.get("planted_day", day)
    age = day - pd
    if c["ongoing"]:
        step_i = max(1, c["interval"])
        dsf = (day + 1) - pd - c["first"]
        if dsf < 0 or dsf % step_i != 0:
            return None
        if dsf // step_i + 1 > c["max_yield"]:
            return None
        return "water" if t.get("fertilized_until_day", -1) >= day else None
    ws = (c["max_day"] + 1) // 2
    if ws <= age <= c["max_day"] and t.get("yield_units", 0) < c["max_yield"]:
        return "water"
    return None


def _harvest_ready(t, day):
    c = CROPS.get(t.get("crop"))
    if not c:
        return False
    yu = t.get("yield_units", 0)
    age = day - t.get("planted_day", day)
    if yu <= 0:
        return False
    if c["ongoing"]:
        return yu >= KNOBS["harvest_min"] or day >= 18
    if KNOBS["melon_rush"] and t.get("crop") == "MELON" and age >= c["first"] and yu >= 5:
        return True
    return yu >= c["max_yield"] or age >= c["max_day"] or day >= 29


def _fert_eligible(t, day):
    c = CROPS.get(t.get("crop"))
    if not c or day > 26:
        return False
    age = day - t.get("planted_day", day)
    if not c["ongoing"]:
        if t.get("crop") != "MELON":
            return False
        # O20: fertilize melons late in the yield window (age 7-8) -> 6 units by age 9-10 -> the whole crop is
        # harvested on day 10 and sold into the fresh $270 melon pool before/with the tapes' 60-unit dump
        return (7 <= age <= 8 and t.get("yield_units", 0) < c["max_yield"]
                and t.get("fertilized_until_day", -1) < day)
    step_i = max(1, c["interval"])
    done = 0 if age < c["first"] else (age - c["first"]) // step_i + 1
    return done < c["max_yield"] and age >= c["first"] - 1 and t.get("fertilized_until_day", -1) < day


def perceive(obs):
    p = obs["player"]
    me = obs["farms"][p]
    day = obs["day"]
    tiles = me["tiles"]
    v = {"animals": [], "empty_pastures": [], "empty": [], "weeds": [], "crops": [], "shed_tiles": [],
         "unlocked": 0}
    for y in range(BOARD):
        for x in range(BOARD):
            t = tiles[y][x]
            if t == "LOCKED":
                continue
            v["unlocked"] += 1
            if t is None:
                v["empty"].append((x, y))
            elif isinstance(t, dict):
                k = t.get("kind")
                if "animal" in t:
                    v["animals"].append(((x, y), t))
                elif k in ("PASTURE", "COOP"):
                    v["empty_pastures"].append((x, y))
                elif k == "WEED":
                    v["weeds"].append((x, y))
                elif k == "PLANT":
                    v["crops"].append(((x, y), t))
    # The engine accepts DROP/PICKUP from any of the four shed-access tiles, locked or not (shed ops
    # resolve before the LOCKED guard, and movement onto LOCKED tiles is legal). O4 only routed to unlocked ones.
    v["shed_tiles"] = list(SHED_TILES) if EG["all_shed_tiles"] else [t for t in SHED_TILES if tiles[t[1]][t[0]] != "LOCKED"]
    v["urgent"] = [pos for pos, t in v["crops"] if not t.get("watered_today") and _water_needed(t, day) == "urgent"]
    v["water"] = [pos for pos, t in v["crops"] if not t.get("watered_today") and _water_needed(t, day) == "water"]
    v["wwater"] = []
    if KNOBS["wheat_water_tier"]:
        v["wwater"] = [pos for pos in v["water"] if tiles[pos[1]][pos[0]].get("crop") == "WHEAT"]
        v["water"] = [pos for pos in v["water"] if pos not in v["wwater"]]
    v["harvest"] = [pos for pos, t in v["crops"] if _harvest_ready(t, day)]
    v["fert"] = [pos for pos, t in v["crops"] if _fert_eligible(t, day)]
    v["slack"] = [pos for pos, t in v["crops"] if not t.get("watered_today") and _water_needed(t, day) is None
                  and CROPS.get(t.get("crop"), {}).get("ongoing")]
    v["tiles"] = tiles
    return v


# ======================================================================
# ECONOMY
# ======================================================================

# ===== EVOLVE-BLOCK: hiring =====
HIRE_MAX_MARGINAL = 144   # H_GATE144 (other session, AGE-360): refuse any hire whose own fibonacci price exceeds this


def _hire_plan(target, have, hires_today, cash):
    """Return number of HIRE orders affordable now toward `target` hands."""
    n = 0
    spent = 0
    while have + n < target:
        c = _fib(hires_today + n)
        if spent + c > cash:
            break
        if c > HIRE_MAX_MARGINAL:
            break
        spent += c
        n += 1
    return n, spent


def _load_model(v, seeds_planned, n_animals_total, n_setup, day):
    load = LOAD_ANIMAL * n_animals_total
    load += LOAD_CROP_TASK * (len(v["urgent"]) + len(v["water"]) + len(v.get("wwater", [])) + len(v["harvest"]) + len(v["weeds"]) + seeds_planned)
    load += LOAD_SETUP * n_setup
    tgt = int(math.ceil(load / KNOBS["load_per_hand"]))
    floor = KNOBS["hands_early"] if (KNOBS["hands_early"] and day <= 10) else KNOBS["min_hands"]
    tgt = max(floor, min(MAX_HANDS, tgt))
    if day >= 29:
        tgt = min(tgt, 6)
    return tgt
# ===== END-BLOCK: hiring =====


MAX_SHOP_INSTANCES = 8
UNLOCK_INTERVAL = 3


# ===== EVOLVE-BLOCK: demand =====
def _instances(obs, item):
    """Unlocked shop instances buying `item` (duplicates count; single-product shops draw double)."""
    n = 0.0
    for name in obs.get("town", {}).get("unlocked_shops", []) or []:
        prods = SHOPS.get(name, [])
        if item in prods:
            n += 2 if len(prods) == 1 else 1
    return n


def _daily_demand(obs, item, day, sell_start=None):
    shops = obs.get("town", {}).get("unlocked_shops", []) or []
    per_day = CFG["turns_per_day"] / max(1, CFG["shop_interval"])
    if sell_start is None:
        sell_start = day
    mid = (sell_start + 29) / 2.0
    slots_by_mid = min(MAX_SHOP_INSTANCES, int(mid // UNLOCK_INTERVAL))
    future = max(0, slots_by_mid - len(shops))
    d = _instances(obs, item) * per_day
    exp_per_slot = sum((2 if len(p) == 1 else 1) for p in SHOPS.values() if item in p) / len(SHOPS)
    d += future * exp_per_slot * per_day
    d += CFG["turns_per_day"] / max(1, CFG["center_interval"])
    return d


def _demand_room(obs, v, species, day, my_count, opp_count):
    item = PRODUCT_OF[species]
    inv = obs["market"]["inventory"].get(item, I0)
    reservoir = max(0.0, I0 - inv)
    T = max(1, 29 - day)
    T_new = max(0, T - FIRST_YIELD[species] - 1)
    if T_new <= 0:
        return 0
    sustainable_rate = KNOBS["demand_share"] * _daily_demand(obs, item, day, day + FIRST_YIELD[species]) + reservoir / T
    n_max = int(sustainable_rate // RATE[species])
    return max(0, n_max - my_count)
# ===== END-BLOCK: demand =====


STRAW_UNITS_PER_TILE = 4.0


# ===== EVOLVE-BLOCK: economy =====
def economy(obs, v, pending_drop=None):
    p = obs["player"]
    me = obs["farms"][p]
    day, hour = obs["day"], obs["hour"]
    shed = obs["private"]["shed"]
    if pending_drop:
        # O5: product being DROPped by this turn's unit actions is in the shed by the time the
        # market processes, so it is sellable now.
        shed = dict(shed)
        for k_, n_ in pending_drop.items():
            shed[k_] = shed.get(k_, 0) + n_
    seeds = obs["private"]["seeds"]
    prices = obs["market"]["prices"]
    cash = me["money"]
    quads = len(me["unlocked_quadrants"])
    previous = S.get("capital_cash", cash)
    S["capital_cash"] = cash
    if S.get("capital_event_day") != day:
        S["capital_event_day"] = day
        S["capital_events"] = 0
    event = (2 <= hour <= 12 and day >= 1 and day <= 20 and
             cash >= previous + 100 and S.get("capital_events",0) < 3)
    if event: S["capital_events"] = S.get("capital_events",0)+1
    orders = []
    n_hands = len(me["hands"])
    inv = obs["private"].get("inventories") or []
    carried_animals = sum(i.get(a, 0) for i in inv for a in ANIMALS)
    shed_animals = sum(shed.get(a, 0) for a in ANIMALS)
    n_active = len(v["animals"])
    n_total = n_active + shed_animals + carried_animals

    due_feed=sum(_feed_useful(t,day) for q,t in v["animals"])
    due_feed+=shed_animals+carried_animals
    # Buy today's actual obligations, preserving the existing small buffer.
    # ---- sells (every hour on days >= 28, otherwise hour 0)
    shed_load = sum(n for k, n in shed.items() if k not in ANIMALS and n > 0)
    revenue_est = 0.0
    fert_want = 0
    if day <= 26 and (KNOBS["fert_keep"] > 0 or KNOBS["fert_buy"] > 0):
        fert_want = min(KNOBS["fert_keep"] + KNOBS["fert_buy"], len(v["fert"]))
    if True:
        for item in ("MILK", "WOOL", "STRAWBERRY", "FERTILIZER", "TOMATO", "CARROT", "EGG"):
            n = shed.get(item, 0)
            if item == "FERTILIZER" and day <= 26:
                n = max(0, n - min(KNOBS["fert_keep"], fert_want))
            if n > 0:
                orders.append(["SELL", item, int(n)])
                revenue_est += n * prices.get(item, 0) * 0.85
        n = shed.get("MELON", 0)
        if n > 0 and (prices.get("MELON", 0) >= KNOBS["melon_floor"] or day >= 27 or shed_load > 75):
            orders.append(["SELL", "MELON", int(n)])
            revenue_est += n * prices.get("MELON", 0) * 0.7
        w = shed.get("WHEAT", 0)
        if day >= 29:
            if w > 0:
                orders.append(["SELL", "WHEAT", int(w)])
        elif prices.get("WHEAT", 0) >= (KNOBS["wheat_sell_price"] if day < 27 else 30):
            hold = KNOBS["wheat_stock"] if day < 27 else 0
            reserve_feed = (n_total + 3) + (n_total * KNOBS["wheat_hold_days"] if day < 27 else 0)
            surplus = int(w - reserve_feed - hold)
            if shed_load > 80:
                surplus = int(w - (n_total + 3))
            if surplus > 0:
                orders.append(["SELL", "WHEAT", surplus])
                revenue_est += surplus * prices.get("WHEAT", 0) * 0.9
    capital_hour = hour if event else (0 if day == 0 else 1)          # V3.10: capital decisions on exact post-sale cash at hour 1
    if hour != capital_hour and not (KNOBS["capital_hour2"] >= 0 and hour == KNOBS["capital_hour2"] and day >= 1):
        if hour == 0:
            spare = 3 if cash + revenue_est >= 300 else KNOBS["feed_spare_poor"]
            feed_need = max(0, due_feed + spare - shed.get("WHEAT", 0)) if day < 29 else 0
            wheat_cost = feed_need * prices.get("WHEAT", 40) * 1.15
            seeds_on_hand = sum(seeds.get(c, 0) for c in CROP_SPECS)
            target = _load_model(v, seeds_on_hand, n_total, shed_animals + carried_animals, day)
            S["hires_target"] = target
            if day <= KNOBS["early_hire_days"]:
                # labor first: hires cost fib dollars; feed is bought with whatever is left
                n, spent = _hire_plan(target, n_hands, me["hires_today"], max(0.0, cash + revenue_est))
                orders += [["HIRE"]] * max(0, min(n, MAX_ORDERS - len(orders)))
                affordable = int(max(0.0, cash + revenue_est - spent) // (prices.get("WHEAT", 40) * 1.15))
                feed_need = min(feed_need, affordable)
                if feed_need > 0:
                    orders.append(["BUY_PRODUCT", "WHEAT", int(feed_need)])
            else:
                if feed_need > 0:
                    orders.append(["BUY_PRODUCT", "WHEAT", int(feed_need)])
                n, _ = _hire_plan(target, n_hands, me["hires_today"], max(0.0, cash + revenue_est - wheat_cost - 50))
                orders += [["HIRE"]] * max(0, min(n, MAX_ORDERS - len(orders)))
        elif hour <= 2 and day < 30:
            need = S["hires_target"] - n_hands
            if need > 0:
                n, _ = _hire_plan(S["hires_target"], n_hands, me["hires_today"], max(0.0, cash - 50))
                orders += [["HIRE"]] * min(n, MAX_ORDERS - len(orders))
        return orders[:MAX_ORDERS]

    # ---- frontier opening: the whole $3,000 at hour 0 of day 0 (exactly 10 orders)
    if day == 0 and KNOBS["opening"] == "frontier" and n_total == 0:
        S["hires_target"] = 5
        oc, osh, om, ow = KNOBS["open_cows"], KNOBS["open_sheep"], KNOBS["open_melons"], KNOBS["open_wheat"]
        o = [["HIRE"]] * 5
        if oc: o.append(["BUY_ANIMAL", "COW", oc])
        if osh: o.append(["BUY_ANIMAL", "SHEEP", osh])
        if om: o.append(["BUY_SEED", "MELON", om])
        if ow: o.append(["BUY_SEED", "WHEAT", ow])
        o.append(["BUY_PRODUCT", "WHEAT", min(5, oc + osh + 1)])
        return o[:MAX_ORDERS]

    budget = cash + revenue_est
    wheat_price = prices.get("WHEAT", 40)
    feed_need = 0
    if day < 29:
        feed_need = max(0, due_feed + 3 - shed.get("WHEAT", 0))
    wheat_cost = feed_need * wheat_price * 1.15
    seeds_on_hand = sum(seeds.get(c, 0) for c in CROP_SPECS)
    target = _load_model(v, seeds_on_hand, n_total, shed_animals + carried_animals, day)
    _, labor_cost_today = _hire_plan(target, n_hands, me["hires_today"], 10 ** 9)
    reserve = wheat_cost + labor_cost_today + 100
    free = budget - reserve

    empty_count = len(v["empty"]) + len(v["empty_pastures"])
    land_wanted = 0

    # ---- herd
    pending_place = shed_animals + carried_animals
    if day == 0 and n_total == 0:
        orders.append(["BUY_ANIMAL", "COW", 1])
        orders.append(["BUY_ANIMAL", "SHEEP", 1])
        free -= 900
        pending_place = 2
        n_total = 2
    elif 1 <= day <= 21 and pending_place <= 3 and n_total < KNOBS["max_animals"]:
        opp = obs["farms"][1 - p]
        opp_counts = {"COW": 0, "SHEEP": 0}
        for row in opp["tiles"]:
            for t in row:
                if isinstance(t, dict) and t.get("animal") in opp_counts:
                    opp_counts[t["animal"]] += 1
        my_counts = {"COW": shed.get("COW", 0), "SHEEP": shed.get("SHEEP", 0), "GOOSE": shed.get("GOOSE", 0)}
        for _pos, t in v["animals"]:
            if t.get("animal") in my_counts:
                my_counts[t["animal"]] += 1
        for i_ in inv:
            for sp in my_counts:
                my_counts[sp] += i_.get(sp, 0)
        _, labor_tomorrow = _hire_plan(target, 0, 0, 10 ** 9)
        income_tomorrow = n_active * prices.get("FERTILIZER", 50) * 0.8
        for i_ in inv:
            for k_, n_ in i_.items():
                if k_ in ("MILK", "WOOL", "STRAWBERRY", "MELON", "EGG", "FERTILIZER"):
                    income_tomorrow += n_ * prices.get(k_, 0) * 0.8
        if KNOBS["geese"] > 0 and day <= 3 and my_counts["GOOSE"] < KNOBS["geese"]:
            k = min(KNOBS["geese"] - my_counts["GOOSE"], int(free // ANIMALS["GOOSE"]))
            if k > 0:
                orders.append(["BUY_ANIMAL", "GOOSE", int(k)])
                free -= ANIMALS["GOOSE"] * k
                n_total += k
                pending_place += k
        for sp in ("SHEEP", "COW"):
            if day > HERD_LAST_DAY and sp == "COW":
                continue
            room = _demand_room(obs, v, sp, day, my_counts[sp], opp_counts[sp])
            if sp == "SHEEP":
                yarn = _instances(obs, "WOOL")
                if yarn == 0:
                    room = min(room, 2 - my_counts[sp])
                elif prices.get("WOOL", 0) >= 1.05 * 200 and day >= 8:
                    room = max(room, 2)
                room = min(room, MAX_SHEEP - my_counts[sp])
            else:
                if _instances(obs, "MILK") == 0 and day >= 9:
                    room = min(room, 4 - my_counts[sp])
            k = min(6, room, KNOBS["max_animals"] - n_total, int(free // ANIMALS[sp]), empty_count - 4)
            while k > 0 and _load_model(v, seeds_on_hand, n_total + k, pending_place + k, day) > MAX_HANDS:
                k -= 1
            while k > 0:
                cash_after = free - ANIMALS[sp] * k + reserve - wheat_cost - labor_cost_today
                need_tomorrow = labor_tomorrow + (n_total + k) * wheat_price - income_tomorrow
                if cash_after >= need_tomorrow:
                    break
                k -= 1
            if k > 0:
                orders.append(["BUY_ANIMAL", sp, int(k)])
                free -= ANIMALS[sp] * k
                n_total += k
                pending_place += k
                my_counts[sp] += k

    # ---- seeds
    if day == 0:
        orders.append(["BUY_SEED", "MELON", OPENING_MELONS])
        free -= 80 * OPENING_MELONS
    else:
        opp = obs["farms"][1 - p]
        committed = {c: 0.0 for c in CROP_SPECS}
        wheat_tiles_now = 0
        for _pos, t in v["crops"]:
            c = t.get("crop")
            if c in committed:
                committed[c] += CROP_SPECS[c]["units"]
            if c == "WHEAT":
                wheat_tiles_now += 1
        for c in committed:
            committed[c] += seeds.get(c, 0) * CROP_SPECS[c]["units"]
        space = empty_count - pending_place - sum(seeds.get(c, 0) for c in CROP_SPECS)
        seed_orders = {}
        n_seed_orders = 0
        excluded = set()
        # ---- wheat tile floor (feed self-supply + late sale)
        wheat_target = max(KNOBS["wheat_tiles"], int(round(KNOBS["wheat_per_animal"] * n_total)))
        wheat_target = min(wheat_target, KNOBS["wheat_cap"])
        if wheat_target > 0 and day <= 24:
            deficit = wheat_target - wheat_tiles_now - seeds.get("WHEAT", 0)
            k = min(deficit, space, int(free // 10))
            if k > 0:
                seed_orders["WHEAT"] = k
                free -= 10 * k
                seeds_on_hand += k
                space -= k
                committed["WHEAT"] += k * CROP_SPECS["WHEAT"]["units"]
                n_seed_orders += 1
                excluded.add("WHEAT")
        while space > 0 and n_seed_orders < 4:
            best = None
            for c, sp_ in CROP_SPECS.items():
                if c in excluded or day > sp_["cutoff"] or day < sp_.get("start", 0):
                    continue
                if c == "STRAWBERRY" and day < KNOBS["straw_delay"]:
                    continue
                T_sell = max(0, 29 - day - sp_["first"])
                if T_sell <= 0:
                    continue
                inv_c = obs["market"]["inventory"].get(c, I0)
                cushion_left = max(0.0, sp_.get("cushion", 0) - max(0.0, inv_c - I0))
                pool = DEMAND_SHARE * (max(0.0, I0 - inv_c) + cushion_left + _daily_demand(obs, c, day, day + sp_["first"]) * (29 - day))
                room_units = pool - committed[c] - seed_orders.get(c, 0) * sp_["units"]
                if room_units < sp_["units"] * 0.5:
                    continue
                price = min(prices.get(c, sp_["base"]), sp_["base"] * 2.0)
                val = min(sp_["units"], room_units) * price / sp_["cycle"]
                if val < sp_["min_val"]:
                    continue
                if best is None or val > best[0]:
                    best = (val, c, room_units)
            if best is None:
                break
            _val, c, room_units = best
            k = min(space, int(room_units // CROP_SPECS[c]["units"]), int(free // CROP_SPECS[c]["seed"]), 20)
            while k > 0 and _load_model(v, seeds_on_hand + k, n_total, pending_place, day) >= MAX_HANDS:
                k -= 1
            if k <= 0:
                excluded.add(c)
                continue
            excluded.add(c)
            seed_orders[c] = seed_orders.get(c, 0) + k
            free -= CROP_SPECS[c]["seed"] * k
            seeds_on_hand += k
            space -= k
            n_seed_orders += 1
            if c == "STRAWBERRY" and room_units // CROP_SPECS[c]["units"] > k + 4:
                land_wanted = int(room_units // CROP_SPECS[c]["units"]) - k
        for c, k in seed_orders.items():
            orders.append(["BUY_SEED", c, int(k)])

    # ---- land
    if quads < 4 and 1 <= day <= LAND_DEADLINE[quads + 1] and empty_count - pending_place < 8 and (land_wanted > 0 or pending_place > empty_count - 2):
        price = LAND_PRICES[quads - 1]
        if quads == 3 and not (day <= 14 and land_wanted >= 12):
            price = float("inf")
        if free >= price:
            orders.append(["BUY_LAND"])
            free -= price

    # ---- wheat feed
    if day < 29:
        feed_need = max(0, due_feed + 3 - shed.get("WHEAT", 0) - sum(int(o[2]) for o in orders if o[0] == "BUY_PRODUCT"))
    if feed_need > 0:
        orders.append(["BUY_PRODUCT", "WHEAT", int(feed_need)])

    # ---- fertilizer to apply on ongoing crops (3-day boost doubles the next yields)
    if KNOBS["fert_buy"] > 0 and day <= 26 and len(v["fert"]) > 0:
        fp = prices.get("FERTILIZER", 100)
        eligible = len(v["fert"])
        have = shed.get("FERTILIZER", 0)
        k = min(KNOBS["fert_buy"], max(0, eligible - have), int(max(0.0, free - 50) // max(1, fp)))
        if k > 0 and fp <= 0.6 * prices.get("STRAWBERRY", 120):
            orders.append(["BUY_PRODUCT", "FERTILIZER", int(k)])
            free -= fp * k

    # ---- hires
    target = _load_model(v, seeds_on_hand, n_total, pending_place, day)
    S["hires_target"] = target
    n, _ = _hire_plan(target, n_hands, me["hires_today"], max(0.0, cash + revenue_est - wheat_cost))
    slots = MAX_ORDERS - len(orders)
    orders += [["HIRE"]] * max(0, min(n, slots))
    return orders[:MAX_ORDERS]




# ===== END-BLOCK: economy =====


# ======================================================================
# DISPATCH (unchanged from V3.12)
# ======================================================================

def _nearest(pos, cands):
    best, bd = None, 10 ** 9
    for c in cands:
        d = _dist(pos, c)
        if d < bd:
            best, bd = c, d
    return best



def _next_animal_yield(t,day):
    first,interval,cap={"COW":(8,2,6),"SHEEP":(6,3,6),"GOOSE":(4,1,4)}[t["animal"]]
    due=t["placed_day"]+first
    while due<=day:due+=interval
    return due,interval,cap

def _care_useful(t,day):
    if t.get("cared_today",False):return False
    due,interval,cap=_next_animal_yield(t,day)
    # Tonight's production consumes the old bonus before adding today's care.
    if due==day+1:
        return due+interval<=29
    if due>29:return False
    if t.get("pending_care_bonus",0)>=cap-1:return False
    if True and due-day>cap:return False
    return True

def _feed_useful(t,day):
    if t.get("fed_today",False) or day>=29:return False
    due,interval,cap=_next_animal_yield(t,day)
    return t.get("consecutive_unfed",0)>=1 or due==day+1 or _care_useful(t,day)

def _animal_pending(t, day):
    if day >= 29:
        return t.get("fertilizer_available", False) or t.get("yield_units", 0) > 0
    need_feed = _feed_useful(t,day)
    need_care = _care_useful(t,day)
    return need_feed or need_care or t.get("fertilizer_available", False) or t.get("yield_units", 0) > 0




# ===== EVOLVE-BLOCK: animal_routing =====
def _build_route(i, pos, v, day, shed, carry, unlocked_shed, hour=0):
    claimed = set()
    for r in S["routes"].values():
        claimed.update(r["stops"])
    cands = [(p2, t) for p2, t in v["animals"] if p2 not in claimed and _animal_pending(t, day)]
    if EG["work_filter"] and day == 29:
        # O5: only animals we can reach, harvest, and still carry home to the shed by the last hour
        cands = [(p2, t) for p2, t in cands if hour + _dist(pos, p2) + 1 + _home_dist(p2, unlocked_shed) <= EG["last_hour"]]
    if not cands and hour >= 14:
        best = None
        for j, r in S["routes"].items():
            if j == i or len(r["stops"]) < 2:
                continue
            tp = r["stops"][-1]
            t = v["tiles"][tp[1]][tp[0]]
            needs_wheat = day < 29 and _feed_useful(t,day) and carry.get("WHEAT", 0) == 0
            if needs_wheat:
                continue
            gain = _dist(v["positions"][j], tp) - _dist(pos, tp)
            if gain >= 3 and (best is None or gain > best[0]):
                best = (gain, j)
        if best is not None:
            tp = S["routes"][best[1]]["stops"].pop()
            cands = [(tp, v["tiles"][tp[1]][tp[0]])]
    if not cands:
        return None
    stops = []
    cur = pos
    pool = dict(cands)
    while pool and len(stops) < ROUTE_LEN:
        nxt = _nearest(cur, list(pool.keys()))
        stops.append(nxt)
        cur = nxt
        del pool[nxt]
    unfed = sum(1 for s_ in stops if _feed_useful(v["tiles"][s_[1]][s_[0]],day)) if day < 29 else 0
    need = max(0, unfed - carry.get("WHEAT", 0))
    pickup = min(need, S["wheat_budget"]) if unlocked_shed else 0
    S["wheat_budget"] -= pickup
    return {"stops": stops, "pickup": pickup}




def _route_step(i, pos, v, day, hour, shed, carry, unlocked_shed):
    r = S["routes"][i]
    tiles = v["tiles"]
    if r["pickup"] > 0:
        if pos in unlocked_shed:
            n = min(r["pickup"], shed.get("WHEAT", 0))
            r["pickup"] = 0
            if n > 0:
                return ["PICKUP", "WHEAT", int(n)]
            if hour <= 1:
                r["pickup"] = 1
                return ["PASS"]
        else:
            return [_step(pos, _nearest(pos, unlocked_shed))]
    while r["stops"]:
        tgt = r["stops"][0]
        t = tiles[tgt[1]][tgt[0]]
        if not (isinstance(t, dict) and "animal" in t):
            r["stops"].pop(0)
            continue
        if pos != tgt:
            return [_step(pos, tgt)]
        if day < 29 and _feed_useful(t,day) and carry.get("WHEAT", 0) > 0:
            return ["FEED"]
        if day < 29 and _feed_useful(t,day) and carry.get("WHEAT", 0) == 0 and S["wheat_budget"] > 0 and hour < 21 and not r.get("refilled"):
            unfed = sum(1 for s_ in r["stops"] if _feed_useful(tiles[s_[1]][s_[0]],day))
            r["pickup"] = min(unfed, S["wheat_budget"]); S["wheat_budget"] -= r["pickup"]; r["refilled"] = True
            return [_step(pos, _nearest(pos, unlocked_shed))] if pos not in unlocked_shed else ["PICKUP", "WHEAT", int(r["pickup"])]
        if _care_useful(t,day):
            return ["CARE"]
        if t.get("fertilizer_available", False):
            return ["COLLECT_FERTILIZER"]
        if t.get("yield_units", 0) > 0:
            return ["HARVEST"]
        r["stops"].pop(0)
    del S["routes"][i]
    return None


# ===== END-BLOCK: animal_routing =====


# ===== EVOLVE-BLOCK: siting =====
def _pick_site(v, species=None):
    if v["empty_pastures"]:
        c = [s_ for s_ in v["empty_pastures"] if s_ not in S["claimed_sites"]]
        if c:
            return min(c, key=_shed_dist)
    c = [s_ for s_ in v["empty"] if s_ not in S["claimed_sites"] and s_ not in SHED_TILES]
    if not c:
        return None
    return min(c, key=lambda s_: (_shed_dist(s_), s_))


def _setup_step(i, pos, v, carry):
    sp = next((a for a in ANIMALS if carry.get(a, 0) > 0), None)
    if sp is None:
        S["setup"].pop(i, None)
        return None
    site = S["setup"].get(i)
    tiles = v["tiles"]
    want_kind = "COOP" if sp == "GOOSE" else "PASTURE"
    if site is not None:
        t = tiles[site[1]][site[0]]
        ok = t is None or (isinstance(t, dict) and t.get("kind") == want_kind and "animal" not in t)
        if not ok:
            S["claimed_sites"].discard(site)
            site = None
    if site is None:
        if sp == "GOOSE":
            c = [s_ for s_ in v["empty"] if s_ not in S["claimed_sites"] and s_ not in SHED_TILES]
            site = min(c, key=lambda s_: (_shed_dist(s_), s_)) if c else None
        else:
            site = _pick_site(v)
        if site is None:
            return ["PASS"]
        S["setup"][i] = site
        S["claimed_sites"].add(site)
    if pos != site:
        return [_step(pos, site)]
    t = tiles[site[1]][site[0]]
    if t is None:
        return ["BUILD_COOP"] if sp == "GOOSE" else ["BUILD_PASTURE"]
    return ["PLACE", sp]
# ===== END-BLOCK: siting =====


# ===== EVOLVE-BLOCK: crop_admission =====
def _crop_pools(v, seeds_left, day):
    n_seeds = sum(seeds_left.get(c, 0) for c in CROP_SPECS)
    plant = [q for q in sorted(v["empty"], key=lambda q: (_shed_dist(q), q)) if q not in S["claimed_sites"] and q not in S.get("pending_sites",set())][:n_seeds]
    pools = {"urgent": list(v["urgent"]), "wwater": list(v["wwater"]), "harvest": list(v["harvest"]), "water": list(v["water"]),
             "fert": list(v["fert"]), "plant": plant, "weeds": list(v["weeds"]), "slack": list(v["slack"])}
    if EG["work_filter"] and day == 29:
        for k in pools:
            pools[k] = [tp for tp in pools[k] if _day29_task_ok(tp, k, v["tiles"][tp[1]][tp[0]], day)]
    return pools




def _plant_choice(pos, seeds_left):
    near = _shed_dist(pos) <= NEAR_RADIUS
    order = ["STRAWBERRY", "TOMATO", "MELON", "CARROT", "WHEAT"] if near else ["MELON", "WHEAT", "CARROT", "STRAWBERRY", "TOMATO"]
    for c in order:
        if seeds_left.get(c, 0) > 0:
            return c
    return None


def _task_valid(tp, kind, v, day, hour, carry, seeds_left):
    t = v["tiles"][tp[1]][tp[0]]
    if EG["work_filter"] and day == 29 and not _day29_task_ok(tp, kind, t, day):
        return False
    if kind in ("urgent", "water", "slack", "wwater"):
        return isinstance(t, dict) and t.get("kind") == "PLANT" and not t.get("watered_today")
    if kind == "harvest":
        return isinstance(t, dict) and t.get("kind") == "PLANT" and t.get("yield_units", 0) > 0
    if kind == "fert":
        return carry.get("FERTILIZER", 0) > 0 and isinstance(t, dict) and _fert_eligible(t, day)
    if kind == "plant":
        return tp not in S["claimed_sites"] and tp not in S.get("pending_sites",set()) and t is None and _plant_choice(tp, seeds_left) is not None and hour < 22
    if kind == "weeds":
        return isinstance(t, dict) and t.get("kind") == "WEED"
    return False


# ===== END-BLOCK: crop_admission =====


# ===== EVOLVE-BLOCK: sweep =====
def _build_sweep(i, pos, v, day, hour, carry, pools, seeds_left):
    tiers = ["urgent", "wwater", "harvest", "water"]
    if carry.get("FERTILIZER", 0) > 0:
        tiers = ["urgent", "fert", "wwater", "harvest", "water"]
    if hour < 22:
        tiers.append("plant")
    tiers.append("weeds")
    if hour >= 14:
        tiers.append("slack")
    first = None
    for kind in tiers:
        if pools[kind]:
            tp = _nearest(pos, pools[kind])
            first = (tp, kind)
            for pool in pools.values():
                if tp in pool:pool.remove(tp)
            break
    if first is None:
        return None
    sweep = [first]
    cur = first[0]
    if first[1] == "urgent" and pools["urgent"]:
        tiers = ["urgent", "harvest"]
    while len(sweep) < CROP_SWEEP_LEN:
        best = None
        for kind in tiers:
            for tp in pools[kind]:
                d = _dist(cur, tp)
                if d <= CROP_SWEEP_RADIUS and (best is None or d < best[0]):
                    best = (d, tp, kind)
        if best is None:
            break
        _d, tp, kind = best
        for pool in pools.values():
            if tp in pool:pool.remove(tp)
        sweep.append((tp, kind))
        cur = tp
    return sweep




def _steal_task(i, pos, v, day, hour, carry, pools, seeds_left):
    remaining = 23 - hour
    best = None
    for j, sw in list(S["sweep"].items()):
        if j == i or not sw:
            continue
        eta = 0
        cur = v["positions"][j]
        for idx, (tp, kind) in enumerate(sw):
            eta += _dist(cur, tp) + 1
            cur = tp
            if kind == "urgent" and eta > remaining:
                mine = _dist(pos, tp) + 1
                if mine <= remaining and (best is None or mine < best[0]):
                    best = (mine, j, idx)
    if best is not None:
        _m, j, idx = best
        tp, kind = S["sweep"][j].pop(idx)
        S["sweep"][i] = [(tp, kind)]
        return _crop_step(i, pos, v, day, hour, carry, pools, seeds_left)
    best = None
    for j, sw in S["sweep"].items():
        if j == i or len(sw) < 2:
            continue
        for idx in range(len(sw) - 1, 0, -1):
            tp, kind = sw[idx]
            mine = _dist(pos, tp) + 1
            if mine > remaining:
                continue
            key = (0 if kind == "urgent" else 1, mine, -len(sw))
            if best is None or key < best[0]:
                best = (key, j, idx)
    if best is not None:
        _k, j, idx = best
        task = S["sweep"][j].pop(idx)
        S["sweep"][i] = [task]
        return _crop_step(i, pos, v, day, hour, carry, pools, seeds_left)
    return None



# ===== ORCHESTRATOR (global assignment of crop tasks) =====
ORCH_PRIO = {"urgent": 0.0, "harvest": 0.5, "wwater": 0.5, "fert": 0.5, "plant": 1.0, "water": 1.0, "weeds": 1.5, "slack": 6.0}
ORCH_COMMIT = 0.75
MELON_MORNING = 1            # O22
MELON_MORNING_LAST_HOUR = 8 # O22
MELON_MORNING_MIN_YIELD = 6   # O22: a 5-unit melon sold at the top of the pool beats a 6-unit one sold into the dump      # bonus for keeping the task a unit is already heading to (prevents swap oscillation)
ORCH_SLACK_HOUR = 14


def _orchestrate(v, pools, positions, day, hour, inv, seeds_left, busy):
    """Assign at most one crop task per free unit by global min-cost matching. Returns {unit: (tp, kind)}."""
    prev = S.get("assign", {})
    tasks = []
    for kind, lst in pools.items():
        if kind == "slack" and hour < ORCH_SLACK_HOUR:
            continue
        for tp in lst:
            tasks.append((tp, kind))
    free = [j for j in range(len(positions)) if j not in busy]
    if not free or not tasks:
        return {}
    # units already standing on a tile with an open task keep it (chain in progress)
    pairs = []
    for j in free:
        pj = positions[j]
        carry = inv[j] if j < len(inv) else {}
        for ti, (tp, kind) in enumerate(tasks):
            if kind == "fert" and carry.get("FERTILIZER", 0) <= 0:
                continue
            if kind == "plant" and not any(seeds_left.get(c, 0) > 0 for c in CROP_SPECS):
                continue
            d = _dist(pj, tp)
            if d + 1 > 24 - hour:
                continue
            cost = d + ORCH_PRIO[kind]
            if prev.get(j, (None, None))[0] == tp:
                cost -= ORCH_COMMIT
            pairs.append((cost, j, ti))
    pairs.sort()
    assigned = {}; used_t = set()
    for cost, j, ti in pairs:
        if j in assigned or ti in used_t:
            continue
        assigned[j] = tasks[ti]; used_t.add(ti)
        if len(assigned) == len(free):
            break
    return assigned

def _crop_step(i, pos, v, day, hour, carry, pools, seeds_left):
    sweep = S["sweep"].get(i)
    if not sweep:
        sweep = _build_sweep(i, pos, v, day, hour, carry, pools, seeds_left)
        if not sweep:
            S["sweep"].pop(i, None)
            # idle hand with empty pools: take work from another unit's sweep instead of passing
            return _steal_task(i, pos, v, day, hour, carry, pools, seeds_left)
        S["sweep"][i] = sweep
    while sweep:
        tp, kind = sweep[0]
        if not _task_valid(tp, kind, v, day, hour, carry, seeds_left):
            sweep.pop(0)
            continue
        if EG["work_filter"] and day == 29:
            # O5: the task only pays if we can finish it AND carry the product to the shed by the last hour
            t_ = v["tiles"][tp[1]][tp[0]]
            acts = 1 if kind == "harvest" else 2   # water(+1 yield) then harvest
            if kind == "harvest" and isinstance(t_, dict) and not t_.get("watered_today") and _day29_task_ok(tp, "water", t_, day):
                acts = 2
            if hour + _dist(pos, tp) + acts + _home_dist(tp, S.get("home") or SHED_TILES) > EG["last_hour"]:
                sweep.pop(0)
                continue
        if pos != tp:
            if _dist(pos, tp) + 1 > 24 - hour:
                sweep.pop(0)  # unreachable before end of day: don't march toward it
                continue
            return [_step(pos, tp)]
        t=v["tiles"][tp[1]][tp[0]]
        c=CROPS.get(t.get("crop"),{}) if isinstance(t,dict) else {}
        age=day-t.get("planted_day",day) if isinstance(t,dict) else 0
        if kind=="harvest" and c and not c["ongoing"] and not t.get("watered_today") and (c["max_day"]+1)//2<=age<=c["max_day"] and t.get("yield_units",0)<c["max_yield"]:
            return ["WATER"]
        sweep.pop(0)
        if kind in ("urgent", "water", "slack", "wwater"):
            if c and age>=c["first"]:
                extra=2 if t.get("fertilized_until_day",-1)>=day else 1
                if _harvest_ready(t,day) or (not c["ongoing"] and t.get("yield_units",0)+extra>=c["max_yield"]):
                    sweep.insert(0,(tp,"harvest"))
            return ["WATER"]
        if kind == "harvest":
            # replant-on-harvest (expert pattern H->P->W): if the tile empties, plant and water it
            # before walking on. _task_valid drops the entry if the crop is ongoing and still standing.
            if hour < 22 and _plant_choice(tp, seeds_left) is not None:
                sweep.insert(0, (tp, "plant"))
            return ["HARVEST"]
        if kind == "fert":
            predicted=dict(t);predicted["fertilized_until_day"]=day+2
            if not t.get("watered_today") and _water_needed(predicted,day) is not None:
                sweep.insert(0,(tp,"water"))
            return ["FERTILIZE"]
        if kind == "weeds":
            if hour < 22 and _plant_choice(tp, seeds_left) is not None:
                sweep.insert(0, (tp, "plant"))  # expert pattern D->P->W
            return ["DIG"]
        if kind == "plant":
            c = _plant_choice(tp, seeds_left)
            seeds_left[c] -= 1
            sweep.insert(0, (tp, "urgent"))
            return ["PLANT", c]
    S["sweep"].pop(i, None)
    if any(pools[k] for k in pools):
        return _crop_step(i, pos, v, day, hour, carry, pools, seeds_left)
    return _steal_task(i, pos, v, day, hour, carry, pools, seeds_left)




# ===== END-BLOCK: sweep =====


# ===== EVOLVE-BLOCK: dispatch =====
def _unit_action(i, pos, carry, obs, v, pools, seeds_left, shed, unlocked_shed):
    day, hour = obs["day"], obs["hour"]
    if any(carry.get(a, 0) > 0 for a in ANIMALS):
        op = _setup_step(i, pos, v, carry)
        if op is not None:
            return op
    prod_carried = sum(carry.get(k, 0) for k in PRODUCTS if k != "WHEAT")
    # O22 melon morning: on the days the melon crop comes in, ready melon tiles are the crew's first job of the day and
    # the melons go straight back to the shed (the melon price pool is emptied by whoever sells first; tapes harvest
    # 60 units by h9 and sell at $217-260, our units used to trickle them in all day and dump 30 at the d11 h0 price).
    if MELON_MORNING and 9 <= day <= 14 and hour <= MELON_MORNING_LAST_HOUR and i not in S["routes"]:
        mc = S.setdefault("melon_claim", {})
        if mc.get("day") != day:
            mc.clear(); mc["day"] = day
        if carry.get("MELON", 0) >= 4 or (carry.get("MELON", 0) > 0 and not any(
                _t.get("crop") == "MELON" and (_harvest_ready(_t, day) or _t.get("yield_units", 0) >= MELON_MORNING_MIN_YIELD)
                for q, _t in v["crops"])):
            if pos in unlocked_shed:
                return ["DROP"]
            return [_step(pos, _nearest(pos, unlocked_shed))]
        tp = mc.get(i)
        if tp is not None:
            tt = v["tiles"][tp[1]][tp[0]]
            if not (isinstance(tt, dict) and tt.get("crop") == "MELON" and tt.get("yield_units", 0) > 0):
                mc.pop(i, None); tp = None
        if tp is None:
            taken = {q for j, q in mc.items() if j != "day"}
            ready = [q for q, _t in v["crops"] if q not in taken and isinstance(v["tiles"][q[1]][q[0]], dict)
                     and v["tiles"][q[1]][q[0]].get("crop") == "MELON" and (_harvest_ready(v["tiles"][q[1]][q[0]], day) or v["tiles"][q[1]][q[0]].get("yield_units", 0) >= MELON_MORNING_MIN_YIELD)]
            if ready:
                tp = _nearest(pos, ready); mc[i] = tp
        if tp is not None:
            if pos == tp:
                mc.pop(i, None)
                return ["HARVEST"]
            return [_step(pos, tp)]
    if EG["deadline_return"] and day == 29:
        # O5: anything still carried after the last processed hour is worth $0 -- get it home in time.
        cargo = sum(n for k, n in carry.items() if k not in ANIMALS and n > 0)
        if cargo > 0:
            hd = _home_dist(pos, unlocked_shed)
            if hour + hd >= EG["last_hour"]:
                if hd == 0:
                    return ["DROP"]
                return [_step(pos, _nearest(pos, unlocked_shed))]
    if EG["evening_force"] and day < 29 and hour >= EG["evening_force"] and i not in S["routes"]:
        cargo = sum(n for k, n in carry.items() if k not in ANIMALS and n > 0)
        if cargo >= EG["evening_force_min"]:
            hd = _home_dist(pos, unlocked_shed)
            if hd == 0:
                return ["DROP"]
            if hour + hd <= 23:
                return [_step(pos, _nearest(pos, unlocked_shed))]
    if day >= 28 and prod_carried >= (3 if day == 29 else 6) and i not in S["routes"]:
        if pos in unlocked_shed:
            return ["DROP"]
        if day == 29 and hour >= 20:
            return [_step(pos, _nearest(pos, unlocked_shed))]
        if day == 29 or hour >= 18:
            return [_step(pos, _nearest(pos, unlocked_shed))]
    # 2a. melon rush: carried melons go straight to the shed to sell into the day-10 price
    if KNOBS["melon_rush"] and 10 <= day <= 14 and carry.get("MELON", 0) >= 4 and carry.get("WHEAT", 0) == 0 and i not in S["routes"]:
        if pos in unlocked_shed:
            return ["DROP"]
        return [_step(pos, _nearest(pos, unlocked_shed))]
    # 2b. intraday deposit: carrying products (no feed wheat, no animals) near/at the shed -> DROP
    if KNOBS["drop_min"] > 0 and prod_carried >= KNOBS["drop_min"] and carry.get("WHEAT", 0) == 0 \
            and i not in S["routes"] and day < 28 and hour >= 1:
        shed_room = 100 - sum(n for k, n in shed.items() if n > 0)
        if shed_room >= prod_carried:
            if pos in unlocked_shed:
                return ["DROP"]
            if KNOBS["drop_radius"] > 0 and _shed_dist(pos) <= KNOBS["drop_radius"]:
                return [_step(pos, _nearest(pos, unlocked_shed))]
    if i in S["routes"]:
        op = _route_step(i, pos, v, day, hour, shed, carry, unlocked_shed)
        if op is not None:
            return op
    # A completed animal route can release its proceeds before the next
    # crop tour. Its matching capital event spends only observed sale cash.
    if (day < 28 and hour < 18 and i not in S["routes"] and
            carry.get("WHEAT",0)==0 and prod_carried>=3 and _shed_dist(pos)<=2):
        if pos in unlocked_shed: return ["DROP"]
        return [_step(pos,_nearest(pos,unlocked_shed))]
    shed_animals = [(a, n) for a, n in shed.items() if a in ANIMALS and n > 0]
    if shed_animals and (i in S["animal_claim"] or len(S["animal_claim"]) < 4) and hour >= 1 and day < 27:
        if pos in unlocked_shed:
            S["animal_claim"].add(i)
            return ["PICKUP", shed_animals[0][0], 1]
        if i in S["animal_claim"] or len(S["animal_claim"]) < 2:
            S["animal_claim"].add(i)
            return [_step(pos, _nearest(pos, unlocked_shed))]
    S["animal_claim"].discard(i)
    # 4b. fertilizer pickup for the crop sweep (hands spawn on shed tiles; hour >= 1 so morning orders landed)
    if (KNOBS["fert_keep"] > 0 or KNOBS["fert_buy"] > 0) and day <= 26 and hour >= 1 and pos in unlocked_shed \
            and carry.get("FERTILIZER", 0) == 0 and pools["fert"] and shed.get("FERTILIZER", 0) > 0 \
            and S.get("fert_taken", 0) < len(v["fert"]):
        n = min(KNOBS["fert_carry"], shed.get("FERTILIZER", 0), len(v["fert"]) - S.get("fert_taken", 0))
        if n > 0:
            S["fert_taken"] = S.get("fert_taken", 0) + n
            return ["PICKUP", "FERTILIZER", int(n)]
    r = None if hour == 0 else _build_route(i, pos, v, day, shed, carry, unlocked_shed, hour)
    if r is not None:
        S["routes"][i] = r
        S["sweep"].pop(i, None)
        op = _route_step(i, pos, v, day, hour, shed, carry, unlocked_shed)
        if op is not None:
            return op
    op = _crop_step(i, pos, v, day, hour, carry, pools, seeds_left)
    if op is not None:
        return op
    # O10 evening deposit: this unit has nothing left to do today. If it is carrying product, walk it to
    # the shed and DROP so it is sold tonight instead of riding the end-of-day auto-drop, which discards
    # everything above the 100-item shed cap (measured: ~5 units/game lost, up to 60+ on melon/wheat days).
    if EG["evening_deposit"] and hour >= EG["evening_deposit"] and day < 29:
        cargo = sum(n for k, n in carry.items() if k not in ANIMALS and n > 0)
        if cargo > 0:
            hd = _home_dist(pos, unlocked_shed)
            if hd == 0:
                return ["DROP"]
            if hour + hd <= 23:
                return [_step(pos, _nearest(pos, unlocked_shed))]
    return ["PASS"]


# ===== END-BLOCK: dispatch =====



def _sale_pressure(item,stock):
    d=stock-10000
    if item=="MILK":return 256/122 if 0<=d<76 else 96/(2*math.sqrt(122*max(1,-d))) if d<0 else 0
    if item=="STRAWBERRY":return 1.92 if 0<=d<62 else 84/(2*math.sqrt(100*max(1,-d))) if d<0 else 0
    if item=="WOOL":return 1280*d/105**2 if 0<d<59 else 40/(math.log(106)*(1-d)) if d<=0 else 0
    if item=="MELON":return 1800*d/300**2 if 0<d<158 else 50/(math.log(301)*(1-d)) if d<=0 else 0
    return 0

def _prioritize_sales(orders,obs):
    slots=[i for i,o in enumerate(orders) if o[0]=="SELL"]
    sales=[orders[i] for i in slots]
    inventory=obs["market"]["inventory"]
    sales.sort(key=lambda o:_sale_pressure(o[1],inventory.get(o[1],10000))*o[2]**2,reverse=True)
    for i,o in zip(slots,sales):orders[i]=o
    return orders

def _agent(obs):
    p = obs["player"]
    me = obs["farms"][p]
    day, hour = obs["day"], obs["hour"]
    if S["day"] != day:
        S.update({"day": day, "routes": {}, "crop": {}, "sweep": {}, "setup": {}, "claimed_sites": set(), "animal_claim": set(), "fert_taken": 0})
    v = perceive(obs)
    shed = dict(obs["private"]["shed"])
    seeds_left = dict(obs["private"]["seeds"])
    inv = obs["private"].get("inventories") or []
    unlocked_shed = v["shed_tiles"]
    S["home"] = unlocked_shed
    reserved = sum(r.get("pickup", 0) for r in S["routes"].values())
    S["wheat_budget"] = max(0, shed.get("WHEAT", 0) - reserved)
    # Reserve space for all owned, unplaced livestock before crop claims.
    waiting=sum(shed.get(sp,0)+sum(c.get(sp,0) for c in inv) for sp in ANIMALS)
    available=[q for q in v["empty_pastures"]+v["empty"] if q not in SHED_TILES]
    S["pending_sites"]=set(sorted(available,key=lambda q:(_shed_dist(q),q))[:waiting])
    for j,bag in enumerate(inv):
        if any(bag.get(sp,0)>0 for sp in ANIMALS):
            here=tuple(me["farmer"]) if j==0 else tuple(me["hands"][j-1])
            _setup_step(j,here,v,bag)
    pools = _crop_pools(v, seeds_left, day)
    for sw in S["sweep"].values():
        for tp, kind in sw:
            for pool in pools.values():
                if tp in pool:pool.remove(tp)
    n_units = 1 + len(me["hands"])
    for d in (S["routes"], S["crop"], S["sweep"], S["setup"]):
        for j in [j for j in d if j >= n_units]:
            d.pop(j, None)
    positions = [tuple(me["farmer"])] + [tuple(h) for h in me["hands"]]
    v["positions"] = positions
    busy = set(S["routes"].keys())
    for j, bag in enumerate(inv):
        if any(bag.get(sp, 0) > 0 for sp in ANIMALS):
            busy.add(j)
    # rebuild the pools fresh (the sweep-based removal above is no longer the source of truth)
    pools = _crop_pools(v, seeds_left, day)
    S["assign"] = _orchestrate(v, pools, positions, day, hour, inv, seeds_left, busy)
    for j, (tp, kind) in S["assign"].items():
        sw = S["sweep"].get(j)
        if not sw or sw[0][0] != tp:
            S["sweep"][j] = [(tp, kind)]
        for pool in pools.values():
            if tp in pool: pool.remove(tp)
    ops = []
    for i, pos in enumerate(positions):
        carry = inv[i] if i < len(inv) else {}
        op=_unit_action(i,pos,carry,obs,v,pools,seeds_left,shed,unlocked_shed)
        ops.append(op)
        if op and op[0]=="PICKUP" and pos in unlocked_shed:
            shed[op[1]]=max(0,shed.get(op[1],0)-int(op[2]))
    # O5: market orders are built AFTER dispatch so this turn's DROPs count as sellable stock
    # (engine order: unit actions, then market). SELL of more than the shed holds is a harmless no-op.
    pending = {}
    if EG["same_turn_sell"] == 1 or (EG["same_turn_sell"] == 2 and day == 29) or \
            (EG["same_turn_sell"] == 3 and (day == 29 or (EG["evening_deposit"] and hour >= EG["evening_deposit"]))):
        for i, pos in enumerate(positions):
            if ops[i] and ops[i][0] == "DROP" and pos in SHED_TILES:
                carry = inv[i] if i < len(inv) else {}
                for k, n in carry.items():
                    if k not in ANIMALS and n > 0:
                        pending[k] = pending.get(k, 0) + n
    market = _prioritize_sales(economy(obs, v, pending or None),obs)
    return {"farmer": ops[0], "hands": ops[1:], "market": market}










def agent(obs, configuration=None):
    try:
        if configuration is not None:
            g = lambda k, d: (configuration.get(k, d) if isinstance(configuration, dict) else getattr(configuration, k, d))
            CFG["center_interval"] = int(g("townCenterSellInterval", 24)); CFG["shop_interval"] = int(g("townShopSellInterval", 4))
            CFG["turns_per_day"] = int(g("turnsPerDay", 24))
        return _agent(obs)
    except Exception as exc:  # crash guard
        import traceback
        print(f"GUARD swallowed exception: {exc!r}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        return {"farmer": ["PASS"], "hands": [], "market": []}
