"""V3_13_WEED_AND_FEED — V3_12 plus two execution-layer fixes (Sep 8), own code, no copied tapes.

Design (see experiments/V3_9_LABOR_MODEL/contract.json) for the inherited labor/capital model.

New this candidate (both target the documented execution gap in RULES.md -- winners do ~2x the
work per hand-turn we do, largely from wasted movement, not undersized capacity):

1. Weed priority: a WEED tile blocks planting until dug, so a tile sitting weeded is a 100% loss
   of that tile's capacity, worse than a merely-unwatered crop. The old sweep tier order checked
   "weeds" dead last (after plant, before only "slack"), so a weeded tile could sit unreclaimed
   for many turns. Moved "weeds" ahead of "harvest"/"water" in _build_sweep's tier order.
   Dev (10 seeds) vs opp_scenario_v14 clone: +12,354/game (t=5.68, 10-0) on the weed fix alone
   (candidates/W1.py), essentially a no-op in self-play (-240, not significant) -- the win only
   shows up against a real opponent, meaning the old code really was leaving weeded tiles idle
   long enough for a real opponent (which doesn't have this bug) to pull ahead.

2. Alternate-day feed/care: an animal only escapes after 2 CONSECUTIVE unfed days, and base
   production (ANIMALS[x]["interval"]) is NOT gated by feeding at all -- only the CARE bonus is,
   and it accrues even on a skipped day as long as the animal is fed+cared on the next visit.
   The old _animal_pending() fed and cared every animal every single day regardless. Tapes at the
   top of the ladder deliberately skip feeding on non-production days (see RULES.md "measured
   execution gap"). Skip feed+care whenever consecutive_unfed==0 (i.e. it was fed yesterday, so
   today is safe) -- frees a route visit every other day per animal with zero escape risk.

Combined (candidates/W3.py, this file) validated vs V3_12 itself and the real clone opponent:
  - dev (10 seeds) vs V3_12 self:            +4,298/game  (t=2.46,  9-1)
  - dev (10 seeds) vs opp_scenario_v14 clone: +14,406/game (t=4.99,  9-1)
  - held-out (20 seeds) vs clone:             +13,467/game (t=8.49, 20-0)
  - held-out (20 seeds) vs V3_12 self:        +1,481/game  (t=1.31, 10-10, not significant --
    mirror matches are noisier than real-opponent matches, same pattern seen with M2/M4)
  - spot-checked at dev seeds vs opp_frontier_v12 (+19,571 vs V3_12's +14,550), opp_soil_v25
    (-3,128 vs V3_12's -8,147, less bad), tape_andreytikhomirov (-28,758 vs V3_12's -41,106,
    less bad) -- consistently better or equal everywhere tested except tape_antigone
    (-33,186 vs V3_12's -31,746, a negligible -1,440 on an opponent both lose to decisively
    already). No agent errors on any test.
"""
import math
import sys

BOARD = 10
SHED_TILES = [(4, 4), (5, 4), (4, 5), (5, 5)]
CROPS = {
    "WHEAT":      {"seed": 10,  "first": 2,  "max_day": 4,  "interval": 0, "max_yield": 6, "ongoing": False},
    "CARROT":     {"seed": 20,  "first": 2,  "max_day": 3,  "interval": 0, "max_yield": 4, "ongoing": False},
    "TOMATO":     {"seed": 50,  "first": 8,  "max_day": 8,  "interval": 1, "max_yield": 4, "ongoing": True},
    "STRAWBERRY": {"seed": 100, "first": 10, "max_day": 10, "interval": 2, "max_yield": 4, "ongoing": True},
    "MELON":      {"seed": 80,  "first": 10, "max_day": 12, "interval": 0, "max_yield": 6, "ongoing": False},
}
ANIMALS = {"COW": 400, "SHEEP": 500, "GOOSE": 300}
PRODUCTS = ["MILK", "WOOL", "STRAWBERRY", "FERTILIZER", "MELON", "TOMATO", "CARROT", "EGG", "WHEAT"]
LAND_PRICES = [1000, 2000, 4000]
LAND_DEADLINE = {2: 14, 3: 17, 4: 18}      # quads-after-purchase -> last day
MAX_ORDERS = 10

MAX_ANIMALS = 20
MAX_SHEEP = 12
I0 = 10000
SHOPS = {"BAKERY": ["EGG", "WHEAT"], "PIZZA_SHOP": ["MILK", "TOMATO", "WHEAT"], "BRUNCH_SPOT": ["EGG", "WHEAT", "STRAWBERRY"],
         "YARN_STORE": ["WOOL"], "ICE_CREAM_SHOP": ["STRAWBERRY", "MILK", "WHEAT"], "PET_CAFE": ["CARROT"],
         "SMOOTHIE_SHOP": ["STRAWBERRY", "MILK"], "FARMERS_MARKET": ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY"]}
PRODUCT_OF = {"COW": "MILK", "SHEEP": "WOOL"}
RATE = {"COW": 1.5, "SHEEP": 1.33}           # units/day with daily FEED+CARE (engine: bonus accrues per cared day)
FIRST_YIELD = {"COW": 8, "SHEEP": 6}
DEMAND_SHARE = 0.5                            # my share of daily town demand (two sellers)
OPP_GROWTH = 1.3                              # opponent's visible supply is assumed to grow
CFG = {"center_interval": 24, "shop_interval": 4, "turns_per_day": 24}
MAX_HANDS = 13
MIN_HANDS = 3
LOAD_PER_HAND = 20
LOAD_ANIMAL, LOAD_CROP_TASK, LOAD_SETUP = 6, 3, 8
ROUTE_LEN = 3
CROP_SWEEP_LEN = 6
CROP_SWEEP_RADIUS = 4
STRAW_CUTOFF = 17
MELON_WAVE_DAYS = ((1, 10),)
MELON_MAX_TILES = 40
MELON_UNITS_PER_TILE = 6.0
MELON_PRICE_CUSHION = 100
OPENING_MELONS = 10
CROP_SPECS = {
    "STRAWBERRY": {"seed": 100, "units": 4.5, "first": 10, "cycle": 18, "cutoff": 17, "base": 120, "min_val": 12},
    "MELON":      {"seed": 80,  "units": 6.0, "first": 10, "cycle": 12, "cutoff": 16, "base": 250, "min_val": 12, "cushion": 100},
    "WHEAT":      {"seed": 10,  "units": 5.0, "first": 2,  "cycle": 5,  "cutoff": 24, "base": 25,  "min_val": 12},
    "CARROT":     {"seed": 20,  "units": 4.0, "first": 2,  "cycle": 4,  "cutoff": 25, "base": 35,  "min_val": 12},
    "TOMATO":     {"seed": 50,  "units": 5.0, "first": 8,  "cycle": 12, "cutoff": 20, "base": 60,  "min_val": 12},
}     # units above I0 before MELON drops from $250 toward $150 (sq curve)
MELON_SELL_PRICE = 150
HERD_LAST_DAY = 19
NEAR_RADIUS = 3

# ---- per-episode state (hands are re-indexed daily; everything below is reset at day change)
S = {"day": -1, "routes": {}, "crop": {}, "sweep": {}, "setup": {}, "claimed_sites": set(), "animal_claim": set(),
     "hires_target": 0, "wheat_budget": 0}


def _fib(n):
    a, b = 1, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def _dist(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def _step(pos, tgt):
    x, y = pos
    tx, ty = tgt
    if x < tx: return "EAST"
    if x > tx: return "WEST"
    if y < ty: return "SOUTH"
    if y > ty: return "NORTH"
    return None


def _shed_dist(pos):
    return min(_dist(pos, t) for t in SHED_TILES)


def _water_needed(t, day):
    cu = t.get("consecutive_unwatered", 0)
    if cu >= 1:
        return "urgent"
    c = CROPS.get(t.get("crop"))
    if not c:
        return None
    pd = t.get("planted_day", day)
    age = day - pd
    if c["ongoing"]:
        step_i = max(1, c["interval"])
        dsf = (day + 1) - pd - c["first"]
        if dsf < 0 or dsf % step_i != 0:
            return None
        if dsf // step_i + 1 > c["max_yield"]:
            return None
        return "water" if t.get("fertilized_until_day", -1) >= day else None
    ws = (c["max_day"] + 1) // 2
    if ws <= age <= c["max_day"] and t.get("yield_units", 0) < c["max_yield"]:
        return "water"
    return None


def _harvest_ready(t, day):
    c = CROPS.get(t.get("crop"))
    if not c:
        return False
    yu = t.get("yield_units", 0)
    age = day - t.get("planted_day", day)
    if yu <= 0:
        return False
    if c["ongoing"]:
        return yu >= 2 or day >= 18          # V3.11: from day 18 harvest every unit so late sales are not batched
    return yu >= c["max_yield"] or age >= c["max_day"] or day >= 29


def _fert_eligible(t, day):
    c = CROPS.get(t.get("crop"))
    if not c or not c["ongoing"] or day > 26:
        return False
    age = day - t.get("planted_day", day)
    step_i = max(1, c["interval"])
    done = 0 if age < c["first"] else (age - c["first"]) // step_i + 1
    return done < c["max_yield"] and age >= c["first"] - 1 and t.get("fertilized_until_day", -1) < day


def perceive(obs):
    p = obs["player"]
    me = obs["farms"][p]
    day = obs["day"]
    tiles = me["tiles"]
    v = {"animals": [], "empty_pastures": [], "empty": [], "weeds": [], "crops": [], "shed_tiles": [],
         "unlocked": 0}
    for y in range(BOARD):
        for x in range(BOARD):
            t = tiles[y][x]
            if t == "LOCKED":
                continue
            v["unlocked"] += 1
            if t is None:
                v["empty"].append((x, y))
            elif isinstance(t, dict):
                k = t.get("kind")
                if "animal" in t:
                    v["animals"].append(((x, y), t))
                elif k in ("PASTURE", "COOP"):
                    v["empty_pastures"].append((x, y))
                elif k == "WEED":
                    v["weeds"].append((x, y))
                elif k == "PLANT":
                    v["crops"].append(((x, y), t))
    v["shed_tiles"] = [t for t in SHED_TILES if tiles[t[1]][t[0]] != "LOCKED"]
    v["urgent"] = [pos for pos, t in v["crops"] if not t.get("watered_today") and _water_needed(t, day) == "urgent"]
    v["water"] = [pos for pos, t in v["crops"] if not t.get("watered_today") and _water_needed(t, day) == "water"]
    v["harvest"] = [pos for pos, t in v["crops"] if _harvest_ready(t, day)]
    v["fert"] = [pos for pos, t in v["crops"] if _fert_eligible(t, day)]
    # slack watering: crops that do not need water today but would gain a one-day survival buffer
    v["slack"] = [pos for pos, t in v["crops"] if not t.get("watered_today") and _water_needed(t, day) is None
                  and CROPS.get(t.get("crop"), {}).get("ongoing")]
    v["tiles"] = tiles
    return v


# ======================================================================
# ECONOMY
# ======================================================================

def _hire_plan(target, have, hires_today, cash):
    """Return number of HIRE orders affordable now toward `target` hands."""
    n = 0
    spent = 0
    while have + n < target:
        c = _fib(hires_today + n)
        if spent + c > cash:
            break
        spent += c
        n += 1
    return n, spent


def _load_model(v, seeds_planned, n_animals_total, n_setup, day):
    load = LOAD_ANIMAL * n_animals_total
    load += LOAD_CROP_TASK * (len(v["urgent"]) + len(v["water"]) + len(v["harvest"]) + len(v["weeds"]) + seeds_planned)
    load += LOAD_SETUP * n_setup
    tgt = int(math.ceil(load / LOAD_PER_HAND))
    tgt = max(MIN_HANDS, min(MAX_HANDS, tgt))
    if day >= 29:
        tgt = min(tgt, 6)
    return tgt


MAX_SHOP_INSTANCES = 8
UNLOCK_INTERVAL = 3


def _instances(obs, item):
    """Unlocked shop instances buying `item` (duplicates count; single-product shops draw double)."""
    n = 0.0
    for name in obs.get("town", {}).get("unlocked_shops", []) or []:
        prods = SHOPS.get(name, [])
        if item in prods:
            n += 2 if len(prods) == 1 else 1
    return n


def _daily_demand(obs, item, day, sell_start=None):
    """Expected town consumption of `item` per day over [sell_start, 29] under the live engine:
    shops are drawn WITH replacement (8 instances, one every 3 days, duplicates consume independently),
    and the town center takes a flat 1 unit per interval."""
    shops = obs.get("town", {}).get("unlocked_shops", []) or []
    per_day = CFG["turns_per_day"] / max(1, CFG["shop_interval"])
    if sell_start is None:
        sell_start = day
    mid = (sell_start + 29) / 2.0
    slots_by_mid = min(MAX_SHOP_INSTANCES, int(mid // UNLOCK_INTERVAL))
    future = max(0, slots_by_mid - len(shops))
    d = _instances(obs, item) * per_day
    exp_per_slot = sum((2 if len(p) == 1 else 1) for p in SHOPS.values() if item in p) / len(SHOPS)
    d += future * exp_per_slot * per_day
    d += CFG["turns_per_day"] / max(1, CFG["center_interval"])
    return d


def _demand_room(obs, v, species, day, my_count, opp_count):
    """Additional animals of `species` whose output keeps MY daily supply within my share of daily
    demand plus the current scarcity reservoir spread over the remaining days."""
    item = PRODUCT_OF[species]
    inv = obs["market"]["inventory"].get(item, I0)
    reservoir = max(0.0, I0 - inv)
    T = max(1, 29 - day)
    T_new = max(0, T - FIRST_YIELD[species] - 1)
    if T_new <= 0:
        return 0
    sustainable_rate = DEMAND_SHARE * _daily_demand(obs, item, day, day + FIRST_YIELD[species]) + reservoir / T
    n_max = int(sustainable_rate // RATE[species])
    return max(0, n_max - my_count)


STRAW_UNITS_PER_TILE = 4.0


def _strawberry_room(obs, v, day, my_tiles, my_seeds, opp_tiles):
    """Additional STRAWBERRY tiles whose output keeps my supply within my share of demand over the window."""
    inv = obs["market"]["inventory"].get("STRAWBERRY", I0)
    T = max(1, 29 - day)
    T_sell = max(0, T - 10)
    if T_sell <= 0:
        return 0
    pool = DEMAND_SHARE * (max(0.0, I0 - inv) + _daily_demand(obs, "STRAWBERRY", day, day + 10) * T)
    room_units = pool - (my_tiles + my_seeds) * STRAW_UNITS_PER_TILE
    return int(max(0, room_units) // STRAW_UNITS_PER_TILE)


def _melon_room(obs, day, my_tiles, my_seeds):
    """Additional MELON tiles the shared pool absorbs at >= ~$150: reservoir + price cushion + center demand."""
    inv = obs["market"]["inventory"].get("MELON", I0)
    T = max(1, 29 - day)
    if T - 12 <= 0:
        return 0
    pool = DEMAND_SHARE * (max(0.0, I0 - inv) + MELON_PRICE_CUSHION + _daily_demand(obs, "MELON", day, day + 12) * T)
    room_units = pool - (my_tiles + my_seeds) * MELON_UNITS_PER_TILE
    return int(max(0, room_units) // MELON_UNITS_PER_TILE)


def economy(obs, v):
    p = obs["player"]
    me = obs["farms"][p]
    day, hour = obs["day"], obs["hour"]
    shed = obs["private"]["shed"]
    seeds = obs["private"]["seeds"]
    prices = obs["market"]["prices"]
    cash = me["money"]
    quads = len(me["unlocked_quadrants"])
    orders = []
    n_hands = len(me["hands"])
    inv = obs["private"].get("inventories") or []
    carried_animals = sum(i.get(a, 0) for i in inv for a in ANIMALS)
    shed_animals = sum(shed.get(a, 0) for a in ANIMALS)
    n_active = len(v["animals"])
    n_total = n_active + shed_animals + carried_animals

    # ---- sells (every hour on days >= 28, otherwise hour 0)
    shed_load = sum(n for k, n in shed.items() if k not in ANIMALS and n > 0)
    revenue_est = 0.0
    if hour == 0 or day >= 28:
        for item in ("MILK", "WOOL", "STRAWBERRY", "FERTILIZER", "TOMATO", "CARROT", "EGG"):
            n = shed.get(item, 0)
            if n > 0:
                orders.append(["SELL", item, int(n)])
                revenue_est += n * prices.get(item, 0) * 0.85
        n = shed.get("MELON", 0)
        if n > 0 and (prices.get("MELON", 0) >= MELON_SELL_PRICE or day >= 27 or shed_load > 75):
            orders.append(["SELL", "MELON", int(n)])
            revenue_est += n * prices.get("MELON", 0) * 0.7
        w = shed.get("WHEAT", 0)
        if day >= 29:
            if w > 0:
                orders.append(["SELL", "WHEAT", int(w)])
        elif prices.get("WHEAT", 0) >= 30:
            surplus = int(w - (n_total + 3))
            if surplus > 0:
                orders.append(["SELL", "WHEAT", surplus])
                revenue_est += surplus * prices.get("WHEAT", 0) * 0.9
    capital_hour = 0 if day == 0 else 1          # V3.10: capital decisions on exact post-sale cash at hour 1
    EARLY_HIRE_DAYS = 5   # ported from C1 (Sep 8): hire-before-feed while the herd/labor base is still small
    if hour != capital_hour:
        if hour == 0:
            feed_need = max(0, n_total + 3 - shed.get("WHEAT", 0)) if day < 29 else 0
            wheat_cost = feed_need * prices.get("WHEAT", 40) * 1.15
            seeds_on_hand = sum(seeds.get(c, 0) for c in CROP_SPECS)
            target = _load_model(v, seeds_on_hand, n_total, shed_animals + carried_animals, day)
            S["hires_target"] = target
            if day <= EARLY_HIRE_DAYS:
                # labor first: hires cost fib dollars; feed is bought with whatever cash is left
                n, spent = _hire_plan(target, n_hands, me["hires_today"], max(0.0, cash + revenue_est))
                orders += [["HIRE"]] * max(0, min(n, MAX_ORDERS - len(orders)))
                affordable = int(max(0.0, cash + revenue_est - spent) // (prices.get("WHEAT", 40) * 1.15))
                feed_need = min(feed_need, affordable)
                if feed_need > 0:
                    orders.append(["BUY_PRODUCT", "WHEAT", int(feed_need)])
            else:
                if feed_need > 0:
                    orders.append(["BUY_PRODUCT", "WHEAT", int(feed_need)])
                n, _ = _hire_plan(target, n_hands, me["hires_today"], max(0.0, cash + revenue_est - wheat_cost - 50))
                orders += [["HIRE"]] * max(0, min(n, MAX_ORDERS - len(orders)))
        elif hour <= 2 and day < 30:
            need = S["hires_target"] - n_hands
            if need > 0:
                n, _ = _hire_plan(S["hires_target"], n_hands, me["hires_today"], max(0.0, cash - 50))
                orders += [["HIRE"]] * min(n, MAX_ORDERS - len(orders))
        return orders[:MAX_ORDERS]

    # ---- C1's "frontier" opening, ported onto V3_13's dispatcher (Sep 8): the whole $3,000 at
    # hour 0 of day 0 in one shot (5 HIRE, 2 COW, 2 SHEEP, 8 MELON seed, 7 WHEAT seed, 5 WHEAT feed)
    # instead of V3_12's staged 1c/1s day-0 + gradual hiring. RULES.md documents this as C1's own
    # +$4.8k held-out edge over V3_12; porting it here tests whether it stacks with the weed/feed fix.
    if day == 0 and n_total == 0:
        o = [["HIRE"]] * 5
        o.append(["BUY_ANIMAL", "COW", 2])
        o.append(["BUY_ANIMAL", "SHEEP", 2])
        o.append(["BUY_SEED", "MELON", 8])
        o.append(["BUY_SEED", "WHEAT", 7])
        o.append(["BUY_PRODUCT", "WHEAT", 5])
        return o[:MAX_ORDERS]

    budget = cash + revenue_est
    wheat_price = prices.get("WHEAT", 40)
    # ---- feed for today (+2 spare), reserved first
    feed_need = 0
    if day < 29:
        feed_need = max(0, n_total + 3 - shed.get("WHEAT", 0))
    wheat_cost = feed_need * wheat_price * 1.15
    # ---- labor target for today
    seeds_on_hand = sum(seeds.get(c, 0) for c in CROP_SPECS)
    target = _load_model(v, seeds_on_hand, n_total, shed_animals + carried_animals, day)
    _, labor_cost_today = _hire_plan(target, n_hands, me["hires_today"], 10 ** 9)
    reserve = wheat_cost + labor_cost_today + 100
    free = budget - reserve

    empty_count = len(v["empty"]) + len(v["empty_pastures"])
    land_wanted = 0          # set by the seed block when demand room exceeds space

    # ---- herd
    pending_place = shed_animals + carried_animals
    if day == 0 and n_total == 0:
        orders.append(["BUY_ANIMAL", "COW", 1])
        orders.append(["BUY_ANIMAL", "SHEEP", 1])
        free -= 900
        pending_place = 2
        n_total = 2
    elif 1 <= day <= 21 and pending_place <= 3 and n_total < MAX_ANIMALS:
        opp = obs["farms"][1 - p]
        opp_counts = {"COW": 0, "SHEEP": 0}
        for row in opp["tiles"]:
            for t in row:
                if isinstance(t, dict) and t.get("animal") in opp_counts:
                    opp_counts[t["animal"]] += 1
        my_counts = {"COW": shed.get("COW", 0), "SHEEP": shed.get("SHEEP", 0)}
        for _pos, t in v["animals"]:
            if t.get("animal") in my_counts:
                my_counts[t["animal"]] += 1
        for i_ in inv:
            for sp in my_counts:
                my_counts[sp] += i_.get(sp, 0)
        # V3.11 trap guard: income certain to arrive tomorrow morning vs tomorrow's feed + labor
        _, labor_tomorrow = _hire_plan(target, 0, 0, 10 ** 9)
        income_tomorrow = n_active * prices.get("FERTILIZER", 50) * 0.8
        for i_ in inv:
            for k_, n_ in i_.items():
                if k_ in ("MILK", "WOOL", "STRAWBERRY", "MELON", "EGG", "FERTILIZER"):
                    income_tomorrow += n_ * prices.get(k_, 0) * 0.8
        for sp in ("SHEEP", "COW"):
            if day > HERD_LAST_DAY and sp == "COW":
                continue
            room = _demand_room(obs, v, sp, day, my_counts[sp], opp_counts[sp])
            if sp == "SHEEP":
                yarn = _instances(obs, "WOOL")
                if yarn == 0:
                    room = min(room, 2 - my_counts[sp])      # wool has only the town center until a yarn store is drawn
                elif prices.get("WOOL", 0) >= 1.05 * 200 and day >= 8:
                    room = max(room, 2)
                room = min(room, MAX_SHEEP - my_counts[sp])
            else:
                if _instances(obs, "MILK") == 0 and day >= 9:
                    room = min(room, 4 - my_counts[sp])
            k = min(6, room, MAX_ANIMALS - n_total, int(free // ANIMALS[sp]), empty_count - 4)
            while k > 0 and _load_model(v, seeds_on_hand, n_total + k, pending_place + k, day) > MAX_HANDS:
                k -= 1
            while k > 0:
                cash_after = free - ANIMALS[sp] * k + reserve - wheat_cost - labor_cost_today   # cash left after this purchase
                need_tomorrow = labor_tomorrow + (n_total + k) * wheat_price - income_tomorrow
                if cash_after >= need_tomorrow:
                    break
                k -= 1
            if k > 0:
                orders.append(["BUY_ANIMAL", sp, int(k)])
                free -= ANIMALS[sp] * k
                n_total += k
                pending_place += k
                my_counts[sp] += k

    # ---- seeds: V3.12 generalized crop allocator over every crop pool
    if day == 0:
        orders.append(["BUY_SEED", "MELON", OPENING_MELONS])
        free -= 80 * OPENING_MELONS
    else:
        opp = obs["farms"][1 - p]
        committed = {c: 0.0 for c in CROP_SPECS}
        for _pos, t in v["crops"]:
            c = t.get("crop")
            if c in committed:
                committed[c] += CROP_SPECS[c]["units"] - t.get("yield_units", 0) * 0
        for c in committed:
            committed[c] += seeds.get(c, 0) * CROP_SPECS[c]["units"]
        opp_committed = {c: 0.0 for c in CROP_SPECS}
        for row in opp["tiles"]:
            for t in row:
                if isinstance(t, dict) and t.get("crop") in opp_committed:
                    opp_committed[t["crop"]] += CROP_SPECS[t["crop"]]["units"]
        space = empty_count - pending_place - sum(seeds.get(c, 0) for c in CROP_SPECS)
        seed_orders = {}
        n_seed_orders = 0
        excluded = set()
        while space > 0 and n_seed_orders < 4:
            best = None
            for c, sp_ in CROP_SPECS.items():
                if c in excluded or day > sp_["cutoff"] or day < sp_.get("start", 0):
                    continue
                T_sell = max(0, 29 - day - sp_["first"])
                if T_sell <= 0:
                    continue
                inv_c = obs["market"]["inventory"].get(c, I0)
                cushion_left = max(0.0, sp_.get("cushion", 0) - max(0.0, inv_c - I0))   # one-time pool, consumed by both players' sales
                pool = DEMAND_SHARE * (max(0.0, I0 - inv_c) + cushion_left + _daily_demand(obs, c, day, day + sp_["first"]) * (29 - day))
                room_units = pool - committed[c] - seed_orders.get(c, 0) * sp_["units"]
                if room_units < sp_["units"] * 0.5:
                    continue
                price = min(prices.get(c, sp_["base"]), sp_["base"] * 2.0)
                val = min(sp_["units"], room_units) * price / sp_["cycle"]      # $ per tile-day
                if val < sp_["min_val"]:
                    continue
                if best is None or val > best[0]:
                    best = (val, c, room_units)
            if best is None:
                break
            _val, c, room_units = best
            k = min(space, int(room_units // CROP_SPECS[c]["units"]), int(free // CROP_SPECS[c]["seed"]), 20)
            while k > 0 and _load_model(v, seeds_on_hand + k, n_total, pending_place, day) >= MAX_HANDS:
                k -= 1
            if k <= 0:
                excluded.add(c)
                continue
            excluded.add(c)
            seed_orders[c] = seed_orders.get(c, 0) + k
            free -= CROP_SPECS[c]["seed"] * k
            seeds_on_hand += k
            space -= k
            n_seed_orders += 1
            if c == "STRAWBERRY" and room_units // CROP_SPECS[c]["units"] > k + 4:
                land_wanted = int(room_units // CROP_SPECS[c]["units"]) - k
        for c, k in seed_orders.items():
            orders.append(["BUY_SEED", c, int(k)])

    # ---- land: only when demand room exceeds space (or animals await sites), at saturation
    if quads < 4 and 1 <= day <= LAND_DEADLINE[quads + 1] and empty_count - pending_place < 8 and (land_wanted > 0 or pending_place > empty_count - 2):
        price = LAND_PRICES[quads - 1]
        if quads == 3 and not (day <= 14 and land_wanted >= 12):
            price = float("inf")             # the $4,000 quadrant must be justified by a large, early demand gap
        if free >= price:
            orders.append(["BUY_LAND"])
            free -= price

    # ---- wheat (recomputed for animals bought this morning; day>=1 already bought base feed at hour 0)
    if day < 29:
        feed_need = max(0, n_total + 3 - shed.get("WHEAT", 0) - sum(int(o[2]) for o in orders if o[0] == "BUY_PRODUCT"))
    if feed_need > 0:
        orders.append(["BUY_PRODUCT", "WHEAT", int(feed_need)])

    # ---- hires (fill remaining slots; hours 1-2 finish) -- target recomputed after purchases
    target = _load_model(v, seeds_on_hand, n_total, pending_place, day)
    S["hires_target"] = target
    n, _ = _hire_plan(target, n_hands, me["hires_today"], max(0.0, cash + revenue_est - wheat_cost))
    slots = MAX_ORDERS - len(orders)
    orders += [["HIRE"]] * max(0, min(n, slots))
    return orders[:MAX_ORDERS]


# ======================================================================
# DISPATCH
# ======================================================================

def _nearest(pos, cands):
    best, bd = None, 10 ** 9
    for c in cands:
        d = _dist(pos, c)
        if d < bd:
            best, bd = c, d
    return best


def _animal_pending(t, day):
    if day >= 29:
        return t.get("fertilizer_available", False) or t.get("yield_units", 0) > 0
    # Alternate-day feed/care: an animal only escapes after 2 CONSECUTIVE unfed days, and base
    # production isn't gated by feeding at all (only the care bonus is). If we fed it yesterday
    # (consecutive_unfed == 0), it's safe to skip today -- frees a visit every other day per animal.
    skippable = t.get("consecutive_unfed", 0) == 0
    need_feed = (not t.get("fed_today", False)) and not skippable
    need_care = (not t.get("cared_today", False)) and day < 28 and not skippable
    return need_feed or need_care or t.get("fertilizer_available", False) or t.get("yield_units", 0) > 0


def _build_route(i, pos, v, day, shed, carry, unlocked_shed, hour=0):
    """Assign up to ROUTE_LEN pending, unclaimed pastures to unit i (nearest-neighbour chain)."""
    claimed = set()
    for r in S["routes"].values():
        claimed.update(r["stops"])
    cands = [(p2, t) for p2, t in v["animals"] if p2 not in claimed and _animal_pending(t, day)]
    if not cands and hour >= 14:
        # take the tail stop of another route only if this unit is materially closer to it than the
        # holder and needs no wheat detour (already carrying wheat, or the stop is already fed)
        best = None
        for j, r in S["routes"].items():
            if j == i or len(r["stops"]) < 2:
                continue
            tp = r["stops"][-1]
            t = v["tiles"][tp[1]][tp[0]]
            needs_wheat = day < 29 and not t.get("fed_today", False) and carry.get("WHEAT", 0) == 0
            if needs_wheat:
                continue
            gain = _dist(v["positions"][j], tp) - _dist(pos, tp)
            if gain >= 3 and (best is None or gain > best[0]):
                best = (gain, j)
        if best is not None:
            tp = S["routes"][best[1]]["stops"].pop()
            cands = [(tp, v["tiles"][tp[1]][tp[0]])]
    if not cands:
        return None
    stops = []
    cur = pos
    pool = dict(cands)
    while pool and len(stops) < ROUTE_LEN:
        nxt = _nearest(cur, list(pool.keys()))
        stops.append(nxt)
        cur = nxt
        del pool[nxt]
    unfed = sum(1 for s_ in stops if not v["tiles"][s_[1]][s_[0]].get("fed_today", False)) if day < 29 else 0
    need = max(0, unfed - carry.get("WHEAT", 0))
    pickup = min(need, S["wheat_budget"]) if unlocked_shed else 0
    S["wheat_budget"] -= pickup
    return {"stops": stops, "pickup": pickup}


def _route_step(i, pos, v, day, hour, shed, carry, unlocked_shed):
    r = S["routes"][i]
    tiles = v["tiles"]
    if r["pickup"] > 0:
        if pos in unlocked_shed:
            n = min(r["pickup"], shed.get("WHEAT", 0))
            r["pickup"] = 0
            if n > 0:
                return ["PICKUP", "WHEAT", int(n)]
            # nothing to pick up (order not landed yet): wait one turn at hour<=1, else proceed
            if hour <= 1:
                r["pickup"] = 1
                return ["PASS"]
        else:
            return [_step(pos, _nearest(pos, unlocked_shed))]
    while r["stops"]:
        tgt = r["stops"][0]
        t = tiles[tgt[1]][tgt[0]]
        if not (isinstance(t, dict) and "animal" in t):
            r["stops"].pop(0)
            continue
        if pos != tgt:
            return [_step(pos, tgt)]
        if day < 29 and not t.get("fed_today", False) and carry.get("WHEAT", 0) > 0:
            return ["FEED"]
        if day < 29 and not t.get("fed_today", False) and carry.get("WHEAT", 0) == 0 and S["wheat_budget"] > 0 and hour < 21 and not r.get("refilled"):
            # refill: reserve wheat for every still-unfed stop and go back to the shed
            unfed = sum(1 for s_ in r["stops"] if not tiles[s_[1]][s_[0]].get("fed_today", False))
            r["pickup"] = min(unfed, S["wheat_budget"]); S["wheat_budget"] -= r["pickup"]; r["refilled"] = True
            return [_step(pos, _nearest(pos, unlocked_shed))] if pos not in unlocked_shed else ["PICKUP", "WHEAT", int(r["pickup"])]
        if day < 28 and not t.get("cared_today", False):
            return ["CARE"]
        if t.get("fertilizer_available", False):
            return ["COLLECT_FERTILIZER"]
        if t.get("yield_units", 0) > 0:
            return ["HARVEST"]
        r["stops"].pop(0)
    del S["routes"][i]
    return None


def _pick_site(v):
    if v["empty_pastures"]:
        c = [s_ for s_ in v["empty_pastures"] if s_ not in S["claimed_sites"]]
        if c:
            return min(c, key=_shed_dist)
    c = [s_ for s_ in v["empty"] if s_ not in S["claimed_sites"] and s_ not in SHED_TILES]
    if not c:
        return None
    return min(c, key=lambda s_: (_shed_dist(s_), s_))


def _setup_step(i, pos, v, carry):
    sp = next((a for a in ANIMALS if carry.get(a, 0) > 0), None)
    if sp is None:
        S["setup"].pop(i, None)
        return None
    site = S["setup"].get(i)
    tiles = v["tiles"]
    if site is not None:
        t = tiles[site[1]][site[0]]
        ok = t is None or (isinstance(t, dict) and t.get("kind") == "PASTURE" and "animal" not in t)
        if not ok:
            S["claimed_sites"].discard(site)
            site = None
    if site is None:
        site = _pick_site(v)
        if site is None:
            return ["PASS"]
        S["setup"][i] = site
        S["claimed_sites"].add(site)
    if pos != site:
        return [_step(pos, site)]
    t = tiles[site[1]][site[0]]
    if t is None:
        return ["BUILD_PASTURE"]
    return ["PLACE", sp]


def _crop_pools(v, seeds_left, day):
    n_seeds = sum(seeds_left.get(c, 0) for c in CROP_SPECS)
    plant = [q for q in sorted(v["empty"], key=lambda q: (_shed_dist(q), q)) if q not in S["claimed_sites"]][:n_seeds]
    return {"urgent": list(v["urgent"]), "harvest": list(v["harvest"]), "water": list(v["water"]),
            "fert": list(v["fert"]), "plant": plant, "weeds": list(v["weeds"]), "slack": list(v["slack"])}


def _plant_choice(pos, seeds_left):
    near = _shed_dist(pos) <= NEAR_RADIUS
    order = ["STRAWBERRY", "TOMATO", "MELON", "CARROT", "WHEAT"] if near else ["MELON", "WHEAT", "CARROT", "STRAWBERRY", "TOMATO"]
    for c in order:
        if seeds_left.get(c, 0) > 0:
            return c
    return None


def _task_valid(tp, kind, v, day, hour, carry, seeds_left):
    t = v["tiles"][tp[1]][tp[0]]
    if kind in ("urgent", "water", "slack"):
        return isinstance(t, dict) and t.get("kind") == "PLANT" and not t.get("watered_today")
    if kind == "harvest":
        return isinstance(t, dict) and t.get("kind") == "PLANT" and t.get("yield_units", 0) > 0
    if kind == "fert":
        return carry.get("FERTILIZER", 0) > 0 and isinstance(t, dict) and _fert_eligible(t, day)
    if kind == "plant":
        return t is None and _plant_choice(tp, seeds_left) is not None and hour < 22
    if kind == "weeds":
        return isinstance(t, dict) and t.get("kind") == "WEED"
    return False


def _build_sweep(i, pos, v, day, hour, carry, pools, seeds_left):
    """Persistent crop sweep: start at the nearest task of the highest non-empty tier, then chain
    the nearest remaining task of any tier within CROP_SWEEP_RADIUS of the last stop."""
    tiers = ["urgent", "harvest", "weeds", "water"]
    if carry.get("FERTILIZER", 0) > 0:
        tiers = ["urgent", "fert", "harvest", "weeds", "water"]     # a carried unit is worth more on a crop than sold
    if hour < 22:
        tiers.append("plant")
    if hour >= 14:
        tiers.append("slack")          # only once the day's real work is thinning out
    first = None
    for kind in tiers:
        if pools[kind]:
            tp = _nearest(pos, pools[kind])
            first = (tp, kind)
            pools[kind].remove(tp)
            break
    if first is None:
        return None
    sweep = [first]
    cur = first[0]
    if first[1] == "urgent" and pools["urgent"]:
        tiers = ["urgent", "harvest"]          # survival first: chain only urgent (+harvest en route)
    while len(sweep) < CROP_SWEEP_LEN:
        best = None
        for kind in tiers:
            for tp in pools[kind]:
                d = _dist(cur, tp)
                if d <= CROP_SWEEP_RADIUS and (best is None or d < best[0]):
                    best = (d, tp, kind)
        if best is None:
            break
        _d, tp, kind = best
        pools[kind].remove(tp)
        sweep.append((tp, kind))
        cur = tp
    return sweep


def _crop_step(i, pos, v, day, hour, carry, pools, seeds_left):
    sweep = S["sweep"].get(i)
    if not sweep:
        sweep = _build_sweep(i, pos, v, day, hour, carry, pools, seeds_left)
        if not sweep:
            S["sweep"].pop(i, None)
            return None
        S["sweep"][i] = sweep
    while sweep:
        tp, kind = sweep[0]
        if not _task_valid(tp, kind, v, day, hour, carry, seeds_left):
            sweep.pop(0)
            continue
        if pos != tp:
            return [_step(pos, tp)]
        sweep.pop(0)
        if kind in ("urgent", "water", "slack"):
            return ["WATER"]
        if kind == "harvest":
            return ["HARVEST"]
        if kind == "fert":
            return ["FERTILIZE"]
        if kind == "weeds":
            return ["DIG"]
        if kind == "plant":
            c = _plant_choice(tp, seeds_left)
            seeds_left[c] -= 1
            sweep.insert(0, (tp, "urgent"))       # same-day watering of the new plant
            return ["PLANT", c]
    S["sweep"].pop(i, None)
    if any(pools[k] for k in pools):
        return _crop_step(i, pos, v, day, hour, carry, pools, seeds_left)
    # idle unit: take over an urgent task that its holder cannot reach before day end but this unit can
    remaining = 23 - hour
    best = None
    for j, sw in list(S["sweep"].items()):
        if j == i or not sw:
            continue
        eta = 0
        cur = v["positions"][j]
        for idx, (tp, kind) in enumerate(sw):
            eta += _dist(cur, tp) + 1
            cur = tp
            if kind == "urgent" and eta > remaining:
                mine = _dist(pos, tp) + 1
                if mine <= remaining and (best is None or mine < best[0]):
                    best = (mine, j, idx)
    if best is not None:
        _m, j, idx = best
        tp, kind = S["sweep"][j].pop(idx)
        S["sweep"][i] = [(tp, kind)]
        return _crop_step(i, pos, v, day, hour, carry, pools, seeds_left)
    # idle: steal the tail task (urgent first) of the longest other sweep
    best = None
    for j, sw in S["sweep"].items():
        if j == i or len(sw) < 2:
            continue
        for idx in range(len(sw) - 1, 0, -1):
            if sw[idx][1] == "urgent" and (best is None or len(sw) > len(S["sweep"][best[0]])):
                best = (j, idx)
                break
    if best is None:
        for j, sw in S["sweep"].items():
            if j != i and len(sw) >= 3 and (best is None or len(sw) > len(S["sweep"][best[0]])):
                best = (j, len(sw) - 1)
    if best is not None:
        j, idx = best
        task = S["sweep"][j].pop(idx)
        S["sweep"][i] = [task]
        return _crop_step(i, pos, v, day, hour, carry, pools, seeds_left)
    return None


def _unit_action(i, pos, carry, obs, v, pools, seeds_left, shed, unlocked_shed):
    day, hour = obs["day"], obs["hour"]
    # 1. carrying an animal -> install it
    if any(carry.get(a, 0) > 0 for a in ANIMALS):
        op = _setup_step(i, pos, v, carry)
        if op is not None:
            return op
    # 2. endgame: carried products must reach the shed to be sold
    prod_carried = sum(carry.get(k, 0) for k in PRODUCTS if k != "WHEAT")
    if day >= 28 and prod_carried >= (3 if day == 29 else 6) and i not in S["routes"]:
        if pos in unlocked_shed:
            return ["DROP"]
        if day == 29 and hour >= 20:
            return [_step(pos, _nearest(pos, unlocked_shed))]
        if day == 29 or hour >= 18:
            return [_step(pos, _nearest(pos, unlocked_shed))]
    # 3. continue a pasture route
    if i in S["routes"]:
        op = _route_step(i, pos, v, day, hour, shed, carry, unlocked_shed)
        if op is not None:
            return op
    # 4. animals waiting in the shed -> fetch one (at most 2 fetchers at a time)
    shed_animals = [(a, n) for a, n in shed.items() if a in ANIMALS and n > 0]
    if shed_animals and len(S["animal_claim"]) < 2 and hour >= 1 and day < 27:
        if pos in unlocked_shed:
            S["animal_claim"].add(i)
            return ["PICKUP", shed_animals[0][0], 1]
        if i in S["animal_claim"] or len(S["animal_claim"]) < 1:
            S["animal_claim"].add(i)
            return [_step(pos, _nearest(pos, unlocked_shed))]
    S["animal_claim"].discard(i)
    # 5. new pasture route (not at hour 0: the morning wheat order lands after this turn's actions)
    r = None if hour == 0 else _build_route(i, pos, v, day, shed, carry, unlocked_shed, hour)
    if r is not None:
        S["routes"][i] = r
        S["sweep"].pop(i, None)          # release any crop sweep this unit was holding
        op = _route_step(i, pos, v, day, hour, shed, carry, unlocked_shed)
        if op is not None:
            return op
    # 6. crops
    op = _crop_step(i, pos, v, day, hour, carry, pools, seeds_left)
    if op is not None:
        return op
    # 7. idle
    return ["PASS"]


def _agent(obs):
    p = obs["player"]
    me = obs["farms"][p]
    day, hour = obs["day"], obs["hour"]
    if S["day"] != day:
        S.update({"day": day, "routes": {}, "crop": {}, "sweep": {}, "setup": {}, "claimed_sites": set(), "animal_claim": set()})
    v = perceive(obs)
    shed = obs["private"]["shed"]
    seeds_left = dict(obs["private"]["seeds"])
    inv = obs["private"].get("inventories") or []
    unlocked_shed = v["shed_tiles"]
    market = economy(obs, v)
    reserved = sum(r.get("pickup", 0) for r in S["routes"].values())
    S["wheat_budget"] = max(0, shed.get("WHEAT", 0) - reserved)
    pools = _crop_pools(v, seeds_left, day)
    # remove tiles already targeted by persistent crop assignments
    for sw in S["sweep"].values():
        for tp, kind in sw:
            if kind in pools and tp in pools[kind]:
                pools[kind].remove(tp)
    # hands are re-indexed daily: drop stale unit indices
    n_units = 1 + len(me["hands"])
    for d in (S["routes"], S["crop"], S["sweep"], S["setup"]):
        for j in [j for j in d if j >= n_units]:
            d.pop(j, None)
    positions = [tuple(me["farmer"])] + [tuple(h) for h in me["hands"]]
    v["positions"] = positions
    ops = []
    for i, pos in enumerate(positions):
        carry = inv[i] if i < len(inv) else {}
        ops.append(_unit_action(i, pos, carry, obs, v, pools, seeds_left, shed, unlocked_shed))
    return {"farmer": ops[0], "hands": ops[1:], "market": market}


def agent(obs, configuration=None):
    try:
        if configuration is not None:
            g = lambda k, d: (configuration.get(k, d) if isinstance(configuration, dict) else getattr(configuration, k, d))
            CFG["center_interval"] = int(g("townCenterSellInterval", 24)); CFG["shop_interval"] = int(g("townShopSellInterval", 4))
            CFG["turns_per_day"] = int(g("turnsPerDay", 24))
        return _agent(obs)
    except Exception as exc:  # crash guard
        import traceback
        print(f"GUARD swallowed exception: {exc!r}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        return {"farmer": ["PASS"], "hands": [], "market": []}
